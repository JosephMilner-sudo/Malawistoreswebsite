const socketIO = require("socket.io");
const http = require("http");
const express = require("express");
const cors = require("cors");

require("dotenv").config();

const app = express();
const server = http.createServer(app);

// Set up CORS with default behavior based on environment
const CLIENT_URL = process.env.CLIENT_URL || "*";
const io = socketIO(server, {
  cors: {
    origin: CLIENT_URL,
    methods: ["GET", "POST", "PUT"],
  },
});

// Middleware
app.use(cors());
app.use(express.json());

// Store connected users
let users = [];

// Add user to the online list
const addUser = (userId, socketId) => {
  if (!userId) return; // Prevent adding users without userId
  if (!users.some((user) => user.userId === userId)) {
    users.push({ userId, socketId });
    console.log(`User added: ${userId}`);
  }
};

// Remove user from the list when disconnected
const removeUser = (socketId) => {
  users = users.filter((user) => user.socketId !== socketId);
  console.log(`User removed: ${socketId}`);
};

// Get a specific user by their userId
const getUser = (userId) => users.find((user) => user.userId === userId);

io.on("connection", (socket) => {
  console.log(`User connected: ${socket.id}`);

  // Add user to online list
  socket.on("addUser", (userId) => {
    try {
      addUser(userId, socket.id);
      console.log(`Current users:`, users);
      io.emit("getUsers", users);
    } catch (error) {
      console.error("Error adding user:", error);
    }
  });

  // Join conversation room
  socket.on("joinConversation", (conversationId) => {
    try {
      socket.join(conversationId);
      console.log(`User joined conversation ${conversationId}`);
    } catch (error) {
      console.error("Error joining conversation:", error);
    }
  });

  // Send and receive messages
  socket.on(
    "sendMessage",
    ({ sender, receiverId, text, images, conversationId }) => {
      try {
        if (!sender || !receiverId || !conversationId) return;

        const message = {
          sender,
          receiverId,
          text,
          images,
          conversationId,
          createdAt: Date.now(),
        };

        const user = getUser(receiverId);

        // Send to individual user
        if (user?.socketId) {
          io.to(user.socketId).emit("getMessage", message);
        }

        // Broadcast to conversation room
        io.to(conversationId).emit("newMessage", message);
      } catch (error) {
        console.error("Error sending message:", error);
      }
    }
  );

  // Update last message in conversation
  socket.on(
    "updateLastMessage",
    ({ lastMessage, lastMessageId, conversationId }) => {
      try {
        io.to(conversationId).emit("getLastMessage", {
          lastMessage,
          lastMessageId,
          conversationId,
        });
      } catch (error) {
        console.error("Error updating last message:", error);
      }
    }
  );

  // Disconnect event
  socket.on("disconnect", () => {
    try {
      console.log(`User disconnected: ${socket.id}`);
      removeUser(socket.id);
      io.emit("getUsers", users);
    } catch (error) {
      console.error("Error during disconnect:", error);
    }
  });
});

const PORT = process.env.PORT || 4000;
server.listen(PORT, () => {
  console.log(`Socket server running on port ${PORT}`);
});
