export const toKwacha = (amount) => {
  // Function to format amount as Malawi Kwacha currency
  return `${new Intl.NumberFormat("en-MW", {
    style: "currency",
    currency: "MWK",
  }).format(amount)}`;
};
