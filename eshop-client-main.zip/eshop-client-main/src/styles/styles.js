const styles = {
  custom_container: "w-11/12 hidden sm:block",
  heading:
    "text-[27px] text-center md:text-start font-[600] font-Roboto pb-[20px]",
  section: "w-11/12 mx-auto",
  productTitle: "800px:text-[22px] font-[600] font-Roboto text-[#333]",
  productDiscountPrice: "font-bold text-[14px] text-[#333] font-Roboto",
  price: "font-[500] text-[13px] text-[#d55b45] pl-1 mt-[-4px] line-through",
  shop_name: "pt-2 text-[15px] text-blue-500 pb-2",
  active_indicator: "absolute bottom-[-27%] left-0 h-[3px] w-full bg-[crimson]",
  button:
    "800px:text-md text-sm 800px:px-4 px-2 bg-yellow-600 h-[45px] my-3 flex items-center justify-center rounded-md cursor-pointer text-white font-semibold ",
  cart_button:
    "px-[20px] h-[38px] rounded-[20px] bg-[#f63b60] flex items-center justify-center cursor-pointer",
  cart_button_text: "text-[#fff] text-[16px] font-[600]",
  input:
    "w-full border border-primary px-3 rounded-[5px] py-1.5 text-gray-600 focus:outline-none focus:ring-1 focus:ring-yellow-600 focus:border-yellow-600 mt-1 800px:text-md text-sm ",
  activeStatus:
    "w-[10px] h-[10px] rounded-full absolute top-0 right-1 bg-[#40d132]",
  normalFlex: "flex items-center",
};

export default styles;
