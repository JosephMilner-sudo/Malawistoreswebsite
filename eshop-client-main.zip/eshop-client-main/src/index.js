import React from "react";
import { createRoot } from "react-dom/client"; // Import createRoot from react-dom/client
import "./index.css";
import App from "./App";
import Store from "./redux/store";
import { Provider } from "react-redux";

// Get the root element
const rootElement = document.getElementById("root");

// Create a root using the createRoot API
const root = createRoot(rootElement);

// Render your app with the Provider
root.render(
  <Provider store={Store}>
    <App />
  </Provider>
);
