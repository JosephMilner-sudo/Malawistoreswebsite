import axios from "axios";
import React, { useEffect, useState } from "react";
import { Link, useParams } from "react-router-dom";
import { server } from "../server";
import { MdError } from "react-icons/md";
import { IoIosCheckmarkCircle } from "react-icons/io";
import { FaCartShopping } from "react-icons/fa6";

const Activation = () => {
  const { token } = useParams();
  const [error, setError] = useState(false);

  useEffect(() => {
    if (token) {
      const activateAccount = async () => {
        await axios
          .post(`${server}/user/activation`, { activationToken: token })
          .then((res) => {
            console.log(res.data);
          })
          .catch((err) => {
            console.log(err.response.data.message);
            setError(true);
          });
      };

      activateAccount();
    }
  }, []);

  return (
    <div className="h-screen w-screen bg-gray-50 font-Poppins flex flex-col items-center justify-center gap-8">
      {error ? (
        <div className="gap-3 flex flex-col items-center justify-center">
          <MdError size={100} color="red" className="animate-bounce" />
          <h1 className="text-red-500 800px:text-2xl text-lg font-bold text-center">
            Invalid or Expired token!
          </h1>
        </div>
      ) : (
        <div className="gap-3 flex flex-col items-center justify-center">
          <IoIosCheckmarkCircle
            size={100}
            color="green"
            className="animate-bounce"
          />
          <h1 className="text-green-600 800px:text-2xl text-lg font-bold">
            Account has been created successfully!
          </h1>
        </div>
      )}

      <Link
        to={"/"}
        className="px-8 py-3 border border-green-500  bg-white  shadow-lg fon-medium mt-3 hover:bg-gray-200 rounded-md flex flex-row gap-3   items-center"
      >
        <FaCartShopping size={20} color="green" />
        Go back to Shop
      </Link>
    </div>
  );
};

export default Activation;
