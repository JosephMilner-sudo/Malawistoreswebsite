import React from "react";
import { Footer, Header, UserOrderDetails } from "../components";

const OrderDetailsPage = () => {
  return (
    <div className="font-Poppins">
      <Header />
      <UserOrderDetails />
      <Footer />
    </div>
  );
};

export default OrderDetailsPage;
