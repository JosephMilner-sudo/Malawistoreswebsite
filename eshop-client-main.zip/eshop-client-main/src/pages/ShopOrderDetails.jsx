import React from "react";
import { DashboardHeader, Footer } from "../components";
import OrderDetails from "../components/order/OrderDetails";

const ShopOrderDetails = () => {
  return (
    <div className="font-Poppins">
      <DashboardHeader />
      <OrderDetails />
      <Footer />
    </div>
  );
};

export default ShopOrderDetails;

