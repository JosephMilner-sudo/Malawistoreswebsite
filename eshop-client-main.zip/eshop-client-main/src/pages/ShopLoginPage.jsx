import React, { useEffect } from "react";
import { ShopLogin } from "../components";
import { useSelector } from "react-redux";
import { useNavigate } from "react-router-dom";

const ShopLoginPage = () => {
  const { isAuthenticated, loading } = useSelector((state) => state.shop);
  const navigate = useNavigate();

  useEffect(() => {
    if (isAuthenticated) {
      navigate("/shop/dashboard");
    }
  }, [loading, isAuthenticated]);

  return (
    <div>
      <ShopLogin />
    </div>
  );
};

export default ShopLoginPage;
