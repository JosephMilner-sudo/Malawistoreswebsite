import React, { useEffect, useState } from "react";
import styles from "./../styles/styles";
import {
  ErrorComponent,
  ShopInfo,
  ShopProfileData,
  Spinner,
} from "../components";
import { useDispatch, useSelector } from "react-redux";
import { loadShopPreview } from "../redux/actions/shop";
import { Link, useNavigate, useParams } from "react-router-dom";
import { getAllProductsForShop } from "../redux/actions/product";
import ShopFullDetails from "../components/shop/ShopFullDetails";
import AdminHeader from "../components/layout/admin/AdminHeader";
import { IoMdCheckmark } from "react-icons/io";
import { MdCancel, MdDelete } from "react-icons/md";
import { BiListCheck, BiLock } from "react-icons/bi";
import { CgClose } from "react-icons/cg";
import axios from "axios";
import { server } from "../server";
import { toast } from "react-toastify";

const SellerPage = () => {
  const { shop, shopPreview, previewLoading, shopPreviewError } = useSelector(
    (state) => state.shop
  );
  const [reject, setReject] = useState(false);
  const { products, loading } = useSelector((state) => state.product);
  const { isAuthenticated } = useSelector((state) => state.system);
  const [isOwner, setIsOwner] = useState(false);
  const [comment, setComment] = useState("");
  const [approveLoading, setApproveLoading] = useState(false);
  const dispatch = useDispatch();
  const { shopId } = useParams();
  const [shopData, setShopData] = useState({});
  const [deleteTag, setDeleteTag] = useState(false);
  const navigate = useNavigate();

  useEffect(() => {
    if (shopPreview) {
      setShopData(shopPreview);
    }
  }, [shopPreview]);

  useEffect(() => {
    dispatch(getAllProductsForShop(shopId));
  }, [shopId, dispatch]);

  useEffect(() => {
    dispatch(loadShopPreview(shopId));
  }, [dispatch, shopId]);

  useEffect(() => {
    if (shopPreview && shop) {
      setIsOwner(shopPreview?._id === shop?._id);
    }
  }, [shopPreview, shop]);

  if (shopPreviewError) {
    return <ErrorComponent error={shopPreviewError} />;
  }

  const handleApprove = async (isApproved) => {
    if (!isApproved && comment.length === 0) {
      toast.error("please input a comment");
      return;
    }

    setApproveLoading(true);

    await axios
      .put(
        `${server}/shop/approve`,
        { isApproved, comment, shopId: shopPreview._id },
        { withCredentials: true }
      )
      .then((res) => {
        setApproveLoading(false);
        toast.success("Status updated successful");
        setComment("");
        setShopData(res.data.shop);
        setReject(false);
      })
      .catch((err) => {
        setApproveLoading(false);
        toast.error(err.response ? err.response.data.message : err.message);
      });
  };

  const deleteShop = async () => {
    setApproveLoading(true);

    await axios
      .delete(`${server}/shop/${shopPreview?._id}`, { withCredentials: true })
      .then(() => {
        setDeleteTag(false);
        setApproveLoading(false);
        navigate("/admin-sellers");
      })
      .catch((err) => {
        setApproveLoading(false);
        toast.error(err.response ? err.response.data.message : err.message);
      });
  };

  if (previewLoading) {
    return <Spinner />;
  }

  return (
    <div className="font-Poppins relative">
      {isAuthenticated && <AdminHeader />}

      <div className={`${styles.section} `}>
        {isAuthenticated && (
          <div>
            <div className=" mt-1 py-2 px-5 bg-white flex gap-4 justify-between overflow-auto">
              <Link
                to={"/admin-sellers"}
                className="px-4 py-2 bg-yellow-500 text-white rounded font-[500] flex items-center gap-1"
              >
                <BiListCheck size={20} />
                View Shops
              </Link>
              {!shopData?.isApproved ? (
                <div className="flex gap-2">
                  <button
                    disabled={approveLoading}
                    className="px-4 py-2 bg-green-500 text-white rounded font-[500] flex items-center gap-1"
                    onClick={() => handleApprove(true)}
                  >
                    <IoMdCheckmark size={20} />
                    Approve
                  </button>
                  <button
                    disabled={approveLoading}
                    className="px-4 py-2 bg-red-300 text-white rounded font-[500] flex items-center gap-1"
                    onClick={() => {
                      setReject(true);
                    }}
                  >
                    <MdCancel size={20} />
                    Reject
                  </button>
                </div>
              ) : (
                <button
                  onClick={() => {
                    setReject(true);
                  }}
                  className="px-4 py-2 bg-red-300 text-white rounded font-[500] flex items-center gap-1"
                >
                  <BiLock size={20} />
                  Deactivate
                </button>
              )}

              <button
                className="px-4 py-2 bg-red-500 text-white rounded font-[500] flex items-center gap-1"
                onClick={() => setDeleteTag(true)}
              >
                <MdDelete size={20} />
                Delete
              </button>
            </div>
            <ShopFullDetails shop={shopData} />
          </div>
        )}
        <div className="w-full flex 800px:flex-row flex-col justify-between py-10">
          {!isAuthenticated && (
            <div className="800px:w-[25%]  w-full bg-white rounded-[4px] shadow-sm overflow-y-auto 800px:h-[95vh] 800px:sticky top-10 left-0 z-10">
              <ShopInfo
                isOwner={isOwner}
                shopData={shopData}
                products={products}
              />
            </div>
          )}
          <div
            className={`${
              !isAuthenticated ? "800px:w-[72%]" : "w-full"
            } " 800px:mt-0 mt-10 rounded-[4px] w-full"`}
          >
            <ShopProfileData
              shopId={shopId}
              isOwner={isOwner}
              products={products}
              loading={loading}
            />
          </div>
        </div>
      </div>

      {/* Rejecting Modal */}
      {reject && (
        <div className="absolute w-full h-[100%] bg-black/30 top-0 items-start left-0 flex justify-center">
          <div className="800px:w-[30%] w-[95%] pb-5 pt-3 bg-white mt-[150px] rounded px-4">
            <button
              className="w-full flex justify-end p-1 rounded-full"
              onClick={() => setReject(false)}
            >
              <CgClose size={24} />
            </button>
            <h1 className="text-lg font-[600] w-full border-b">
              Rejecting/De-activating Shop
            </h1>
            <div className="mt-6">
              <h4 className="text-sm font-[400]">
                Reject/De-activate shop with Comment:
              </h4>
              <textarea
                value={comment}
                className={`${styles.input}`}
                onChange={(e) => setComment(e.target.value)}
              />
            </div>
            <button
              disabled={approveLoading}
              onClick={() => handleApprove(false)}
              className="px-4 py-2 bg-red-500 rounded text-white text-sm mt-1"
            >
              Reject/De-activate
            </button>
          </div>
        </div>
      )}

      {/* Delete Modal */}
      {deleteTag && (
        <div className="absolute w-full h-[100%] bg-black/30 top-0 items-start left-0 flex justify-center">
          <div className="800px:w-[30%] w-[95%] pb-5 pt-3 bg-white mt-[150px] rounded px-4">
            <button
              className="w-full flex justify-end p-1 rounded-full"
              onClick={() => setDeleteTag(false)}
            >
              <CgClose size={24} />
            </button>
            <h1 className="text-lg font-[600] w-full border-b text-red-500 animate-pulse">
              Deleting a Shop/Seller !
            </h1>
            <div className="mt-6">
              <h4 className="text-sm font-[400]">
                Are you sure about this delete action?
              </h4>
              <p className="text-sm text-red-400 mt-2">
                Take note that this action is irreversible and destructive!
              </p>
            </div>
            <div className="flex items-center gap-4 mt-4">
              <button
                onClick={() => setDeleteTag(false)}
                className="px-4 py-2 bg-green-500 rounded text-white text-sm mt-1"
              >
                Cancel
              </button>
              <button
                disabled={approveLoading}
                onClick={() => deleteShop()}
                className="px-4 py-2 bg-red-500 rounded text-white text-sm mt-1"
              >
                Delete
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default SellerPage;
