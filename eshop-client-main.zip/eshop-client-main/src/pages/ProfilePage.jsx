import React, { useState } from "react";
import { Header, ProfileContent, ProfileSideBar } from "../components";
import styles from "../styles/styles";

const ProfilePage = () => {
  const [active, setActive] = useState(1);
  return (
    <div className="font-Poppins">
      <Header />

      <div className={`flex py-10 gap-2 relative`}>
        <div className="800px:w-[275px] 800px:sticky absolute 800px:mt-0 mt-[15%] z-10 bg-white z">
          <ProfileSideBar active={active} setActive={setActive} />
        </div>
        <ProfileContent active={active} />
      </div>
    </div>
  );
};

export default ProfilePage;
