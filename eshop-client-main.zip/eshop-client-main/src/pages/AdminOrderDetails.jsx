import React from "react";
import OrderDetailsAdmin from "../components/admin/OrderDetailsAdmin.jsx";
import AdminHeader from "../components/layout/admin/AdminHeader";

const AdminOrderDetails = () => {
  return (
    <div className="font-Poppins">
      <AdminHeader />
      <OrderDetailsAdmin />
    </div>
  );
};

export default AdminOrderDetails;
