import React from "react";
import {
  CreateCoupon,
  DashboardHeader,
  DashboardSidebar,
} from "../components";

const CreateCouponPage = () => {
  return (
    <div className="font-Poppins">
      <DashboardHeader />
      <div className="w-full flex items-center justify-between">
        <div className="800px:w-[300px] w-[90px]">
          <DashboardSidebar activeLink={0} />
        </div>
        <div className="w-full flex justify-center">
          <CreateCoupon />
        </div>
      </div>
    </div>
  );
};


export default CreateCouponPage