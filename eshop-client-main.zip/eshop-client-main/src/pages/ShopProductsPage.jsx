import React, { useState } from "react";
import {
  AllShopProducts,
  DashboardHeader,
  DashboardSidebar,
} from "../components";

const ShopProductsPage = () => {
  const [toggleMenu, setToggleMenu] = useState(false);
  return (
    <div className="font-Poppins">
      <DashboardHeader
        activeLink={3}
        toggleMenu={toggleMenu}
        setToggleMenu={setToggleMenu}
      />
      <div className="w-full flex">
        <div className="800px:w-[300px]">
          <DashboardSidebar
            activeLink={3}
            toggleMenu={toggleMenu}
            setToggleMenu={setToggleMenu}
          />
        </div>
        <div className="w-full flex flex-col pt-4 bg-white">
          <AllShopProducts />
        </div>
      </div>
    </div>
  );
};

export default ShopProductsPage;
