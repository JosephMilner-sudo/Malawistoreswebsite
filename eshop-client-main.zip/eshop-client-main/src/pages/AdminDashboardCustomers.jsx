import React from "react";
import AdminHeader from "../components/layout/admin/AdminHeader";
import AdminSideBar from "../components/layout/admin/AdminSideBar";
import AdminCustomers from "../components/admin/AdminCustomers";

const AdminDashboardCustomers = () => {
  return (
    <div className="font-Poppins">
      <AdminHeader />
      <div className="w-full flex">
        <div className="flex items-start w-full">
          <div className="w-[80px] 800px:w-[330px]">
            <AdminSideBar active={4} />
          </div>
          <AdminCustomers />
        </div>
      </div>
    </div>
  );
};

export default AdminDashboardCustomers;
