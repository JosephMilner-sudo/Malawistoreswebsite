import React from 'react'

const AdminDashboardWithdraw = () => {
  return (
    <div>AdminDashboardWithdraw</div>
  )
}

export default AdminDashboardWithdraw