import React from "react";
import {
  BestDeals,
  Categories,
  Events,
  FeaturedProducts,
  Footer,
  Header,
  Hero,
  Sponsers,
} from "../components";

const HomePage = () => {
  return (
    <div className="font-Poppins">
      <Header activeNavLink={1} />
      <Hero />
      <Categories />
      <BestDeals />
      <FeaturedProducts />
      <Events />
      <Sponsers />
      <Footer />
    </div>
  );
};

export default HomePage;
