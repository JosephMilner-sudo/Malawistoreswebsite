import React from "react";
import { ShopCreate } from "../components";

const ShopCreatePage = () => {
  
  return (
    <div className="font-Poppins">
      <ShopCreate />
    </div>
  );
};

export default ShopCreatePage;
