import React, { useEffect } from "react";
import SystemLogin from "../components/system/SystemLogin";

const SystemLoginPage = () => {
  return (
    <div>
      <SystemLogin />
    </div>
  );
};

export default SystemLoginPage;
