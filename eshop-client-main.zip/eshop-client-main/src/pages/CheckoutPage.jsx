import React, { useEffect } from "react";
import { Checkout, CheckoutSteps, Footer, Header } from "../components";
import { useState } from "react";

const CheckoutPage = () => {
  useEffect(() => {
    window.scrollTo(0, 0);
  }, []);

  const [active, setActive] = useState(1);

  return (
    <div className="font-Poppins">
      <Header />
      <br />
      <CheckoutSteps active={active} setActive={setActive} />
      <Checkout active={active} setActive={setActive} />
      <br />
      <Footer />
    </div>
  );
};

export default CheckoutPage;
