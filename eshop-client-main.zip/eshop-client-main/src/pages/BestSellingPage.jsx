import React, { useEffect, useState } from "react";
import { Footer, Header } from "./../components";
import styles from "../styles/styles";
import {ProductCard} from "../components/";
import { useSelector } from "react-redux";

const BestSellingPage = () => {
  const [data, setData] = useState(null);
  const { allProducts } = useSelector((state) => state.product);

  useEffect(() => {
    if (allProducts) {
      const sortedData = [...allProducts].sort((a, b) => b.soldOut - a.soldOut);
      setData(sortedData);
    }
  }, [allProducts]); // Dependency added to trigger effect when allProducts changes

  return (
    <>
      <div className="font-Poppins">
        <Header activeNavLink={2} />
        <div className="p-2 800px:text-xl text-lg font-bold text-center mt-5 flex items-end justify-center gap-2">
          Top Selling Products
         
          
        </div>
        <br />
        <br />
        <div className={`${styles.section}`}>
          <div className="grid grid-cols-1 gap-[20px] md:grid-cols-2 md:gap-[25px] lg:grid-cols-3 lg:gap-[25px] xl:grid-cols-5 xl:gap-[30px] mb-12">
            {data && data.length > 0 ? (
              data.map((i, index) => <ProductCard data={i} key={index} />)
            ) : (
              <div className="w-full h-[40vh] flex items-center justify-center col-span-1 md:col-span-2 lg:col-span-3 xl:col-span-5">
                <h5 className="text-xl font-[400] ">:Products not found</h5>
              </div>
            )}
          </div>
        </div>
        <Footer />
      </div>
    </>
  );
};

export default BestSellingPage;
