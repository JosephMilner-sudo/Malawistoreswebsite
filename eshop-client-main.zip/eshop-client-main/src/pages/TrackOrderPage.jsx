import React from 'react'
import { Footer, Header } from '../components'
import { OrderTrack } from '../components'

const TrackOrderPage = () => {
  return (
    <div>
        <Header/>
        <OrderTrack />
        <Footer />
    </div>
  )
}

export default TrackOrderPage