import { React, useState } from "react";
import styles from "../styles/styles";
import { Link } from "react-router-dom";
import Logo from "./../assets/images/logo.png";
import axios from "axios";
import { server } from "../server";
import { toast } from "react-toastify";
import { ClipLoader } from "react-spinners";

const AdminForgotPwd = () => {
  const [email, setEmail] = useState("");
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);

    await axios
      .post(`${server}/system/reset-password`, { email })
      .then((res) => {
        setLoading(false);
        toast.success(res.data.message);
      })
      .catch((err) => {
        toast.error(err.response.data.message);
        setLoading(false);
      });
  };

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col lg:px-8 font-Poppins">
      <Link to={"/"} className="self-center">
        <img src={Logo} alt="Logo" className="w-40 h-30" />
      </Link>
      <div className="sm:mx-auto sm:w-full sm:max-w-md md:px-0 px-2">
        <div className="bg-white py-8 px-4 shadow sm:rounded-lg sm:px-10 border border-gray-300">
          <div className="sm:mx-auto sm:w-full sm:max-w-md">
            <h2 className="font-medium 800px:text-2xl text-lg text-gray-900">
              System- Password Reset
            </h2>
          </div>
          <form className="space-y-6 mt-5" onSubmit={handleSubmit}>
            <div>
              <label
                htmlFor="email"
                className="block text-sm font-medium text-gray-700"
              >
                Enter your login Email
              </label>
              <div className="mt-1">
                <input
                  type="email"
                  name="email"
                  autoComplete="email"
                  required
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className={`${styles.input}`}
                />
              </div>
            </div>
            <div>
              <button
                disabled={loading}
                className={`group relative w-full h-[40px] flex justify-center py-2 px-4 border border-transparent text-sm font-medium rounded-md text-white ${
                  loading
                    ? "bg-blue-400 cursor-not-allowed"
                    : "bg-blue-600 hover:bg-blue-700"
                }`}
              >
                {loading ? <ClipLoader size={24} color="white" /> : "Proceed"}
              </button>
            </div>

            <div className={`${styles.normalFlex} w-full`}>
              <Link
                to="/login-system"
                className="text-blue-600 pl-2 animate-pulse text-sm 800px:text-md"
              >
                Back to Login
              </Link>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
};

export default AdminForgotPwd;
