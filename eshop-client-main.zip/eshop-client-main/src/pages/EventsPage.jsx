import React, { useEffect } from "react";
import { Footer, Header } from "./../components";
import EventCard from "../components/route/EventCard";
import { useSelector } from "react-redux";

const EventsPage = () => {
  const { allEvents, loading } = useSelector((state) => state.event);

  useEffect(() => {
    console.log(allEvents);
  }, [allEvents]);
  return (
    <>
      <div className="font-Poppins">
        <Header activeNavLink={4} />
        <h1 className="pl-4 mt-8 text-xl font-semibold text-gray-600">
          Popular Events
        </h1>
        <p className="pl-4 pb-2 text-sm text-gray-600">Great offers for you</p>
        {!loading && allEvents && allEvents?.length > 0 ? (
          allEvents?.map((item, index) => {
            return <EventCard key={index} active={true} data={item} />;
          })
        ) : (
          <div className="w-full h-[50vh] flex items-center justify-center">
            <h4 className="text-lg">:No Events Found</h4>
          </div>
        )}

        <Footer />
      </div>
    </>
  );
};

export default EventsPage;
