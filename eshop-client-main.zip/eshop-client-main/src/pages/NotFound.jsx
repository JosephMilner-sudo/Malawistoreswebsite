import React from "react";
import { Footer, Header } from "../components";
import styles from "../styles/styles";
import { Link } from "react-router-dom";

const NotFound = () => {
  return (
    <div>
      <Header />
      <div
        className={
          "w-full p-8 h-[65vh] flex flex-col gap-4 items-center justify-center "
        }
      >
        <h1 className="text-xl font-[600]">
          <span className="text-red-600 animate-pulse">Oops!</span> Page not
          found
        </h1>
        <Link to={"/products"} className={`${styles.button}`}>
          Shop
        </Link>
      </div>
      <Footer />
    </div>
  );
};

export default NotFound;
