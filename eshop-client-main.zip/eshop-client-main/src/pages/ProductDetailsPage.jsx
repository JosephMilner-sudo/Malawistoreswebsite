import React, { useEffect, useState } from "react";
import { Footer, Header, ProductFullDetails } from "../components";
import { useParams, useSearchParams } from "react-router-dom";
import { useSelector } from "react-redux";

const ProductDetailsPage = () => {
  const [data, setData] = useState({});
  const { id } = useParams();
  const { allProducts } = useSelector((state) => state.product);
  const [searchParams] = useSearchParams();
  const eventTag = searchParams.get("isEvent");
  const { allEvents } = useSelector((state) => state.event);

  useEffect(() => {
    if (eventTag) {
      if (allEvents) {
        const foundProduct = allEvents.find((item) => item._id === id);
        setData(foundProduct || null); // Ensures setData doesn't set undefined
      }
    } else {
      if (allProducts) {
        const foundProduct = allProducts.find((item) => item._id === id);
        setData(foundProduct || null); // Ensures setData doesn't set undefined
      }
    }
  }, [id, allProducts, allEvents]);

  return (
    <div className="font-Poppins">
      <Header activeNavLink={3} />
      {data ? (
        <ProductFullDetails data={data} eventTag={eventTag} />
      ) : (
        <div className="w-full h-[50vh] flex items-center justify-center">
          <h3 className="text-xl font-[500]">:Product not Found</h3>
        </div>
      )}
      <Footer />
    </div>
  );
};

export default ProductDetailsPage;
