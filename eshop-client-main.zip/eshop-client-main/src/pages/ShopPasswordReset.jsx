import axios from "axios";
import React, { useEffect, useState } from "react";
import { Link, useNavigate, useParams } from "react-router-dom";
import { server } from "../server";
import { toast } from "react-toastify";
import { Logo } from "../static/data";
import { ClipLoader } from "react-spinners";
import { AiOutlineEye, AiOutlineEyeInvisible } from "react-icons/ai";
import styles from "../styles/styles";

const ShopPasswordReset = () => {
  const { token } = useParams();
  const [data, setData] = useState(null);
  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [visible, setVisible] = useState(false);
  const [confirmVisible, setConfirmVisible] = useState(false);
  const navigate = useNavigate();
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    const validateToken = async () => {
      try {
        const res = await axios.get(`${server}/shop/validateToken/${token}`);
        setData(res.data.decoded);
      } catch (err) {
        toast.error(err.response.data.message);
        setTimeout(() => {
          navigate("/login-shop");
        }, 1500);
      }
    };

    validateToken();
  }, []);

  const handleSubmit = async (e) => {
    e.preventDefault();

    if (password.length < 6) {
      toast.error("Password must be at least 6 characters long.");
      return;
    }

    if (password !== confirmPassword) {
      toast.error("Passwords do not match.");
      return;
    }

    setLoading(true);

    try {
      await axios.post(`${server}/shop/reset/password/${token}`, {
        newPassword: password,
      });
      setLoading(false);
      toast.success("Password has been reset successfully!");

      setTimeout(() => {
        navigate("/login-shop", { replace: true });
      }, 2000);
    } catch (err) {
      toast.error(err.response.data.message || "Something went wrong!");
      setLoading(false);
      console.log(err);

      setTimeout(() => {
        navigate("/login-shop", { replace: true });
      }, 2000);
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col lg:px-8 font-Poppins">
      <Link to={"/"} className="self-center">
        <img src={Logo} alt="Logo" className="w-40 h-30" />
      </Link>
      <div className="sm:mx-auto sm:w-full sm:max-w-md md:px-0 px-2">
        <div className="bg-white py-8 px-4 shadow sm:rounded-lg sm:px-10 border border-gray-300">
          <div className="sm:mx-auto sm:w-full sm:max-w-md">
            <h2 className="font-medium 800px:text-2xl text-lg text-gray-900">
              Shop - Password Reset
            </h2>
            <p className="mt-2 text-sm text-gray-500">
              Dear {data?.shop?.name}, you are trying to reset your password!
            </p>
          </div>
          <form className="space-y-6 mt-5" onSubmit={handleSubmit}>
            <div>
              <label
                htmlFor="password"
                className="block text-sm font-medium text-gray-700"
              >
                New Password
              </label>
              <div className="mt-1 relative">
                <input
                  type={visible ? "text" : "password"}
                  name="password"
                  autoComplete="new-password"
                  required
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className={`${styles.input}`}
                />
                {visible ? (
                  <AiOutlineEye
                    className="absolute right-2 top-[8px] cursor-pointer"
                    size={24}
                    onClick={() => setVisible(false)}
                  />
                ) : (
                  <AiOutlineEyeInvisible
                    className="absolute right-2 top-[8px] cursor-pointer"
                    size={24}
                    onClick={() => setVisible(true)}
                  />
                )}
              </div>
            </div>

            <div>
              <label
                htmlFor="confirmPassword"
                className="block text-sm font-medium text-gray-700"
              >
                Confirm Password
              </label>
              <div className="mt-1 relative">
                <input
                  type={confirmVisible ? "text" : "password"}
                  name="confirmPassword"
                  autoComplete="new-password"
                  required
                  value={confirmPassword}
                  onChange={(e) => setConfirmPassword(e.target.value)}
                  className={`${styles.input}`}
                />
                {confirmVisible ? (
                  <AiOutlineEye
                    className="absolute right-2 top-[8px] cursor-pointer"
                    size={24}
                    onClick={() => setConfirmVisible(false)}
                  />
                ) : (
                  <AiOutlineEyeInvisible
                    className="absolute right-2 top-[8px] cursor-pointer"
                    size={24}
                    onClick={() => setConfirmVisible(true)}
                  />
                )}
              </div>
            </div>

            <div>
              <button
                disabled={loading}
                className={`group relative w-full h-[40px] flex justify-center py-2 px-4 border border-transparent text-sm font-medium rounded-md text-white ${
                  loading
                    ? "bg-blue-400 cursor-not-allowed"
                    : "bg-blue-600 hover:bg-blue-700"
                }`}
              >
                {loading ? <ClipLoader size={24} color="white" /> : "Reset"}
              </button>
            </div>

            <div className={`${styles.normalFlex} w-full`}>
              <Link
                to="/login-shop"
                className="text-blue-600 pl-2 animate-pulse text-sm 800px:text-md"
              >
                Back to Login
              </Link>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
};

export default ShopPasswordReset;
