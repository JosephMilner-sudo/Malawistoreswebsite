import React, { useState } from "react";
import { CreateEvent, DashboardHeader, DashboardSidebar } from "../components";

const CreateEventPage = () => {
  const [toggleMenu, setToggleMenu] = useState(false);
  return (
    <div className="font-Poppins">
      <DashboardHeader
        activeLink={6}
        toggleMenu={toggleMenu}
        setToggleMenu={setToggleMenu}
      />
      <div className="w-full flex">
        <div className="800px:w-[300px]">
          <DashboardSidebar
            activeLink={6}
            toggleMenu={toggleMenu}
            setToggleMenu={setToggleMenu}
          />
        </div>
        <div className="w-full flex justify-center mt-2">
          <CreateEvent />
        </div>
      </div>
    </div>
  );
};

export default CreateEventPage;
