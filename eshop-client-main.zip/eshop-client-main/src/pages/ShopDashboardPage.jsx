import { useState } from "react";
import {
  DashboardHeader,
  DashboardSidebar,
  DashboardHero,
} from "../components";

const ShopDashboardPage = () => {
  const [toggleMenu, setToggleMenu] = useState(false);
  return (
    <div className="font-Poppins">
      <DashboardHeader
        activeLink={1}
        toggleMenu={toggleMenu}
        setToggleMenu={setToggleMenu}
      />
      <div className="w-full flex">
        <div className="800px:w-[300px]">
          <DashboardSidebar
            activeLink={1}
            toggleMenu={toggleMenu}
            setToggleMenu={setToggleMenu}
          />
        </div>

        <DashboardHero />
      </div>
    </div>
  );
};

export default ShopDashboardPage;
