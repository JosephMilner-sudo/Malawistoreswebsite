import React, { useState } from "react";
import { ShopRefunds, DashboardHeader, DashboardSidebar } from "../components";

const ShopRefundsPage = () => {
   const [toggleMenu, setToggleMenu] = useState(false);
    return (
      <div className="font-Poppins">
        <DashboardHeader
          activeLink={10}
          toggleMenu={toggleMenu}
          setToggleMenu={setToggleMenu}
        />
        <div className="w-full flex">
          <div className="800px:w-[300px]">
            <DashboardSidebar
              activeLink={10}
              toggleMenu={toggleMenu}
              setToggleMenu={setToggleMenu}
            />
        </div>
        <div className="w-full flex bg-white">
          <ShopRefunds />
        </div>
      </div>
    </div>
  );
};

export default ShopRefundsPage;
