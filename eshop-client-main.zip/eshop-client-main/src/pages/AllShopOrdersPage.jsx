import React, { useState } from "react";
import {
  AllShopOrders,
  DashboardHeader,
  DashboardSidebar,
} from "../components";

const AllShopOrdersPage = () => {
  const [toggleMenu, setToggleMenu] = useState(false);
  return (
    <div className="font-Poppins">
      <DashboardHeader
        activeLink={2}
        toggleMenu={toggleMenu}
        setToggleMenu={setToggleMenu}
      />
      <div className="w-full flex">
        <div className="800px:w-[300px]">
          <DashboardSidebar
            activeLink={2}
            toggleMenu={toggleMenu}
            setToggleMenu={setToggleMenu}
          />
        </div>
        <div className="w-full flex flex-col bg-white">
          <AllShopOrders />
        </div>
      </div>
    </div>
  );
};

export default AllShopOrdersPage;
