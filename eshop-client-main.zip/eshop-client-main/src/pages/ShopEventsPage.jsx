import React, { useState } from "react";
import {
  AllShopEvents,
  DashboardHeader,
  DashboardSidebar,
} from "../components";

const ShopEventsPage = () => {
  const [toggleMenu, setToggleMenu] = useState(false);
  return (
    <div className="font-Poppins">
      <DashboardHeader
        activeLink={5}
        toggleMenu={toggleMenu}
        setToggleMenu={setToggleMenu}
      />
      <div className="w-full flex">
        <div className="800px:w-[300px]">
          <DashboardSidebar
            activeLink={5}
            toggleMenu={toggleMenu}
            setToggleMenu={setToggleMenu}
          />
        </div>
        <div className="w-full flex flex-col text-center bg-white">
         
          <AllShopEvents />
        </div>
      </div>
    </div>
  );
};

export default ShopEventsPage;
