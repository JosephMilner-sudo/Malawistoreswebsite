import React from "react";
import SystemCreate from "../components/system/SystemCreate";


const SystemCreatePage = () => {
  
  return (
    <div className="font-Poppins">
      <SystemCreate />
    </div>
  );
};

export default SystemCreatePage;
