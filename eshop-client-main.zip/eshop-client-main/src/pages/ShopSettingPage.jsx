import React, { useState } from "react";
import { DashboardHeader, DashboardSidebar, ShopSettings } from "../components";

const ShopSettingPage = () => {
  const [toggleMenu, setToggleMenu] = useState(false);
  return (
    <div className="font-Poppins">
      <DashboardHeader
        activeLink={11}
        toggleMenu={toggleMenu}
        setToggleMenu={setToggleMenu}
      />
      <div className="w-full flex">
        <div className="800px:w-[300px]">
          <DashboardSidebar
            activeLink={11}
            toggleMenu={toggleMenu}
            setToggleMenu={setToggleMenu}
          />
        </div>
        <div className="w-full flex justify-center">
          <ShopSettings />
        </div>
      </div>
    </div>
  );
};

export default ShopSettingPage;
