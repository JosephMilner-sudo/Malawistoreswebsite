import React, { useEffect, useState } from "react";
import { useSearchParams } from "react-router-dom";
import { Footer, Header, ProductCard } from "./../components";
import styles from "../styles/styles";
import { useSelector } from "react-redux";
import { ClipLoader } from "react-spinners";

const ProductsPage = () => {
  const [searchParams] = useSearchParams();
  const categoryData = searchParams.get("category");
  const [data, setData] = useState([]);
  const { allProducts, loading } = useSelector((state) => state.product);

  useEffect(() => {
    if (allProducts) {
      if (categoryData === null) {
        const d = allProducts ? allProducts : [];
        setData(d);
      } else {
        const d =
          allProducts &&
          allProducts.filter((i) =>
            i.category?.toLowerCase().includes(categoryData.toLowerCase())
          );

        setData(d);
      }
      window.scrollTo(0, 0);
    }
  }, [categoryData, allProducts]);

  return (
    <>
      <div className="font-Poppins">
        <Header activeNavLink={3} />
        <div className="p-2 800px:text-xl text-lg font-bold text-center mt-5 flex items-end justify-center gap-2">
          All Products
          <span className="font-light text-[12pt]">
            {" "}
            {categoryData && <p>"for {categoryData}"</p>}
          </span>
        </div>

        {loading && (
          <div className="w-full flex items-center justify-center">
            <ClipLoader size={100} color="green" />
          </div>
        )}
        <br />
        <br />
        <div className={`${styles.section}`}>
          <div className="grid grid-cols-1 gap-[20px] md:grid-cols-2 md:gap-[25px] lg:grid-cols-4 lg:gap-[25px] xl:grid-cols-5 xl:gap-[30px] mb-12">
            {data &&
              data.map((i, index) => <ProductCard data={i} key={index} />)}
          </div>
          {!loading && data && data.length === 0 ? (
            <div className="w-full h-[40vh] flex items-center justify-center">
              <h5 className="text-xl font-[400] ">:Products not found</h5>
            </div>
          ) : null}
        </div>

        <Footer />
      </div>
    </>
  );
};

export default ProductsPage;
