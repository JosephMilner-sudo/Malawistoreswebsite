import React, { useEffect, useState } from "react";
import { Link, useNavigate, useParams } from "react-router-dom";
import AdminHeader from "../components/layout/admin/AdminHeader";
import axios from "axios";
import { server } from "../server";
import { toast } from "react-toastify";
import { Spinner } from "../components";
import { BiListCheck, BiLock } from "react-icons/bi";
import { IoMdCheckmark } from "react-icons/io";
import { MdDelete } from "react-icons/md";
import CustomerFullDetails from "../components/admin/CustomerFullDetails";
import styles from "../styles/styles";
import { CgClose } from "react-icons/cg";

const AdminCustomer = () => {
  const { id } = useParams();
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(false);
  const [approveLoading, setApproveLoading] = useState(false);
  const [reject, setReject] = useState(false);
  const [deleteTag, setDeleteTag] = useState(false);
  const [comment, setComment] = useState("");
  const navigate = useNavigate();

  useEffect(() => {
    const loadCustomerInfo = async () => {
      if (id) {
        setLoading(true);
        await axios
          .get(`${server}/user/get-all-user-info/${id}`, {
            withCredentials: true,
          })
          .then((res) => {
            setLoading(false);
            setData(res.data);
            console.log(res.data);
          })
          .catch((error) => {
            setLoading(false);
            toast.error(
              error.response ? error.response.data.message : error.message
            );
            console.log(error);
          });
      } else {
        toast.error("Invalid customer id");
        return;
      }
    };

    loadCustomerInfo();
  }, []);

  const handleApprove = async (status) => {
    if (!status && comment.length === 0) {
      toast.error("please input a comment");
      return;
    }

    setApproveLoading(true);

    await axios
      .put(
        `${server}/user/lock/unlock`,
        { status, comment, id },
        { withCredentials: true }
      )
      .then((res) => {
        setApproveLoading(false);
        toast.success("Status updated successful");
        setComment("");
        setReject(false);

        setTimeout(() => {
          navigate("/admin-users");
        }, 1500);
      })
      .catch((err) => {
        setApproveLoading(false);
        toast.error(err.response ? err.response.data.message : err.message);
      });
  };

  const deleteCustomer = async () => {
    setApproveLoading(true);

    await axios
      .delete(`${server}/user/${id}`, { withCredentials: true })
      .then(() => {
        setDeleteTag(false);
        toast.success("Account deleted successfully");
        setApproveLoading(false);
        setTimeout(() => {
          navigate("/admin-users");
        }, 1500);
      })
      .catch((err) => {
        setApproveLoading(false);
        toast.error(err.response ? err.response.data.message : err.message);
      });
  };

  return (
    <div className="font-Poppins">
      <AdminHeader />
      {loading ? (
        <Spinner />
      ) : (
        <div>
          <div className={`${styles.section}`}>
            <div
              className={
                "mt-1 py-2 px-5 bg-white flex gap-4 justify-between overflow-auto"
              }
            >
              <Link
                to={"/admin-users"}
                className="px-4 py-2 bg-yellow-500 text-white rounded font-[500] flex items-center gap-1"
              >
                <BiListCheck size={20} />
                View Customers
              </Link>
              {!data?.user?.status ? (
                <div className="flex gap-2">
                  <button
                    disabled={approveLoading}
                    className="px-4 py-2 bg-green-500 text-white rounded font-[500] flex items-center gap-1"
                    onClick={() => handleApprove(true)}
                  >
                    <IoMdCheckmark size={20} />
                    Unlock
                  </button>
                </div>
              ) : (
                <button
                  onClick={() => {
                    setReject(true);
                  }}
                  className="px-4 py-2 bg-red-300 text-white rounded font-[500] flex items-center gap-1"
                >
                  <BiLock size={20} />
                  Lock Account
                </button>
              )}

              <button
                className="px-4 py-2 bg-red-500 text-white rounded font-[500] flex items-center gap-1"
                onClick={() => setDeleteTag(true)}
              >
                <MdDelete size={20} />
                Delete
              </button>
            </div>
            <CustomerFullDetails data={data} />
          </div>

          {/* Rejecting Modal */}
          {reject && (
            <div className="absolute w-full h-[100%] bg-black/30 top-0 items-start left-0 flex justify-center">
              <div className="800px:w-[30%] w-[95%] pb-5 pt-3 bg-white mt-[150px] rounded px-4">
                <button
                  className="w-full flex justify-end p-1 rounded-full"
                  onClick={() => setReject(false)}
                >
                  <CgClose size={24} />
                </button>
                <h1 className="text-lg font-[600] w-full border-b">
                  Lock customer account
                </h1>
                <div className="mt-6">
                  <h4 className="text-sm font-[400]">
                    Lock account with comment:
                  </h4>
                  <textarea
                    value={comment}
                    className={`${styles.input}`}
                    onChange={(e) => setComment(e.target.value)}
                  />
                </div>
                <button
                  disabled={approveLoading}
                  onClick={() => handleApprove(false)}
                  className="px-4 py-2 bg-red-500 rounded text-white text-sm mt-1"
                >
                  Lock
                </button>
              </div>
            </div>
          )}

          {/* Delete Modal */}
          {deleteTag && (
            <div className="absolute w-full h-[100%] bg-black/30 top-0 items-start left-0 flex justify-center">
              <div className="800px:w-[30%] w-[95%] pb-5 pt-3 bg-white mt-[150px] rounded px-4">
                <button
                  className="w-full flex justify-end p-1 rounded-full"
                  onClick={() => setDeleteTag(false)}
                >
                  <CgClose size={24} />
                </button>
                <h1 className="text-lg font-[600] w-full border-b text-red-500 animate-pulse">
                  Deleting a customer !
                </h1>
                <div className="mt-6">
                  <h4 className="text-sm font-[400]">
                    Are you sure about this delete action?
                  </h4>
                  <p className="text-sm text-red-400 mt-2">
                    Take note that this action is irreversible and destructive!
                  </p>
                </div>
                <div className="flex items-center gap-4 mt-4">
                  <button
                    onClick={() => setDeleteTag(false)}
                    className="px-4 py-2 bg-green-500 rounded text-white text-sm mt-1"
                  >
                    Cancel
                  </button>
                  <button
                    disabled={approveLoading}
                    onClick={() => deleteCustomer()}
                    className="px-4 py-2 bg-red-500 rounded text-white text-sm mt-1"
                  >
                    Delete
                  </button>
                </div>
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
};

export default AdminCustomer;
