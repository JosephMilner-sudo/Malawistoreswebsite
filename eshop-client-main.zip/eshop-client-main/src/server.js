// export const server = "https://eshop-backend.systemdevmw.com/api";
// export const backendUrl = "https://eshop-backend.systemdevmw.com";

// export const server = "http://localhost:8000/api";
// export const backendUrl = "http://localhost:8000";

export const server = "https://app.malawistore.com/api";
export const backendUrl = "https://app.malawistore.com";
export const socket = "https://socket.malawistore.com";