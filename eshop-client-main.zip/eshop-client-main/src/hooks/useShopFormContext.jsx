import { useContext } from "react";
import { ShopFormContext } from "../context/ShopFormContext";

export const useShopFormContext = () => {
  const context = useContext(ShopFormContext);

  if (!context) {
    throw new Error("useAuth must be used within an AuthProvider");
  }
  return context;
};
