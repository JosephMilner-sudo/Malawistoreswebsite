import React from "react";
import { useSelector } from "react-redux";
import { Navigate } from "react-router-dom";

export const SystemProtectedRoute = ({ children }) => {
  const { loading, isAuthenticated } = useSelector((state) => state.system);

  if (!loading) {
    if (!isAuthenticated) {
      return <Navigate to={"/login-system"} replace />;
    }
    return children;
  }
};

export const SystemOptionalProtectedRoute = ({ children }) => {
  const { loading, isAuthenticated } = useSelector((state) => state.system);

  if (!loading) {
    if (isAuthenticated) {
      return <Navigate to={"/admin/dashboard"} replace />;
    }

    return children;
  }
};
