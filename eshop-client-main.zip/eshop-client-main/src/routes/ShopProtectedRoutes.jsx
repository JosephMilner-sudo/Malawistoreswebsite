import React from "react";
import { useSelector } from "react-redux";
import { Navigate } from "react-router-dom";

export const ShopProtectedRoute = ({ children }) => {
  const { loading, isAuthenticated } = useSelector((state) => state.shop);

  if (!loading) {
    if (!isAuthenticated) {
      return <Navigate to={"/login-shop"} replace />;
    }
    return children;
  }
};

export const ShopOptionalProtectedRoute = ({ children }) => {
  const { loading, isAuthenticated } = useSelector((state) => state.shop);

  if (!loading) {
    if (isAuthenticated) {
      return <Navigate to={"/shop/dashboard"} replace />;
    }
    return children;
  }
};
