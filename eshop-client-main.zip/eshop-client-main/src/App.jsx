import React, { useEffect, useState } from "react";
import {
  BrowserRouter as Router,
  Routes,
  Route,
  useLocation,
} from "react-router-dom";
import {
  LoginPage,
  SignUpPage,
  ActivationPage,
  HomePage,
  ProductsPage,
  EventsPage,
  FAQPage,
  ProductDetailsPage,
  ProfilePage,
  ShopCreatePage,
  ShopActivationPage,
  ShopLoginPage,
  SellerPage,
  ShopDashboardPage,
  CreateProductPage,
  ShopProductsPage,
  CreateEventPage,
  ShopEventsPage,
  ShopCouponsPage,
  CreateCouponPage,
  CheckoutPage,
  AllShopOrdersPage,
  OrderDetailsPage,
  ShopOrderDetails,
  TrackOrderPage,
  ShopRefunds,
  ShopSettingPage,
  WithdrawMoneyPage,
  ShopInboxPage,
  NotFound,
} from "./Routes";
import { ToastContainer } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import Store from "./redux/store";
import { loadUser } from "./redux/actions/user";
import BestSellingPage from "./pages/BestSellingPage";
import { useSelector } from "react-redux";
import { ShopFormProvider } from "./context/ShopFormContext";
import { loadShop } from "./redux/actions/shop";
import {
  ShopOptionalProtectedRoute,
  ShopProtectedRoute,
} from "./routes/ShopProtectedRoutes";
import ProtectedRoute from "./routes/ProtectedRoute";
import Loader from "./components/Loader";
import { getAllProducts } from "./redux/actions/product";
import { getAllEvents } from "./redux/actions/event";
import { server } from "./server";
import axios from "axios";
import { Elements } from "@stripe/react-stripe-js";
import { loadStripe } from "@stripe/stripe-js";
import UserInbox from "./components/userprofile/UserInbox";
import {
  SystemOptionalProtectedRoute,
  SystemProtectedRoute,
} from "./routes/SystemProtectedRoutes";
import {
  AdminDashboardOrders,
  AdminDashboardPage,
  AdminDashboardSellers,
  SystemActivationPage,
  SystemLoginPage,
  AdminDashboardCustomers,
  AdminDashboardProducts,
  AdminDashboardEvents,
  AdminSettingPage,
} from "./AdminRoutes";
import SystemCreatePage from "./pages/SystemCreatePage";
import { loadSystemUser } from "./redux/actions/system";
import AdminOrderDetails from "./pages/AdminOrderDetails";
import AdminCustomer from "./pages/AdminCustomer";
import CustomerFogortPwd from "./pages/CustomerFogortPwd";
import CustomerPasswordReset from "./pages/CustomerPasswordReset";
import ShopForgotPwd from "./pages/ShopForgotPwd";
import ShopPasswordReset from "./pages/ShopPasswordReset";
import AdminPasswordReset from "./pages/AdminPasswordReset";
import AdminForgotPwd from "./pages/AdminForgotPwd";

const AppContent = () => {
  const user = useSelector((state) => state.user);
  const shop = useSelector((state) => state.shop);
  const system = useSelector((state) => state.system);

  const location = useLocation();

  useEffect(() => {
    if (!location.pathname.includes("activation")) {
      Store.dispatch(loadUser());
      Store.dispatch(loadSystemUser());
      Store.dispatch(loadShop());
      Store.dispatch(getAllProducts());
      Store.dispatch(getAllEvents());
    } else {
      Store.dispatch({ type: "restoreLoading" });
    }
  }, [location.pathname]);

  const loadingAll = user.loading || shop.loading;

  return (
    <ShopFormProvider>
      {loadingAll ? (
        <div className="w-full h-screen flex items-center justify-center">
          <Loader />
        </div>
      ) : (
        <>
          <Routes>
            <Route path="/" element={<HomePage />} />
            <Route path="/login" element={<LoginPage />} />
            <Route path="/login-shop" element={<ShopLoginPage />} />
            <Route
              path="/shop-create"
              element={
                <ShopOptionalProtectedRoute
                  isAuthenticated={shop.isAuthenticated}
                >
                  <ShopCreatePage />
                </ShopOptionalProtectedRoute>
              }
            />
            <Route
              path="/login-system"
              element={
                <SystemOptionalProtectedRoute
                  isAuthenticated={system.isAuthenticated}
                >
                  <SystemLoginPage />
                </SystemOptionalProtectedRoute>
              }
            />
            <Route
              path="/system-create"
              element={
                <SystemOptionalProtectedRoute
                  isAuthenticated={system.isAuthenticated}
                >
                  <SystemCreatePage />
                </SystemOptionalProtectedRoute>
              }
            />
            <Route
              path="/customer-forgot-password"
              element={<CustomerFogortPwd />}
            />
            <Route
              path="/customer/password/reset/:token"
              element={<CustomerPasswordReset />}
            />
            <Route path="/admin-forgot-password" element={<AdminForgotPwd />} />
            <Route
              path="/admin/password/reset/:token"
              element={<AdminPasswordReset />}
            />
            <Route path="/shop-forgot-password" element={<ShopForgotPwd />} />
            <Route
              path="/shop/password/reset/:token"
              element={<ShopPasswordReset />}
            />
            <Route path="/sign-up" element={<SignUpPage />} />
            <Route path="/activation/:token" element={<ActivationPage />} />
            <Route
              path="/activation/admin/:token"
              element={<SystemActivationPage />}
            />
            <Route
              path="/shop/activation/:token"
              element={<ShopActivationPage />}
            />
            <Route
              path="/admin/dashboard"
              element={
                <SystemProtectedRoute>
                  <AdminDashboardPage />
                </SystemProtectedRoute>
              }
            />
            <Route
              path="/admin-sellers"
              element={
                <SystemProtectedRoute>
                  <AdminDashboardSellers />
                </SystemProtectedRoute>
              }
            />
            <Route
              path="/admin-users"
              element={
                <SystemProtectedRoute>
                  <AdminDashboardCustomers />
                </SystemProtectedRoute>
              }
            />
            <Route
              path="/admin-orders"
              element={
                <SystemProtectedRoute>
                  <AdminDashboardOrders />
                </SystemProtectedRoute>
              }
            />
            <Route
              path="/admin-products"
              element={
                <SystemProtectedRoute>
                  <AdminDashboardProducts />
                </SystemProtectedRoute>
              }
            />
            <Route
              path="/admin-events"
              element={
                <SystemProtectedRoute>
                  <AdminDashboardEvents />
                </SystemProtectedRoute>
              }
            />
            <Route
              path="/customer/:id"
              element={
                <SystemProtectedRoute>
                  <AdminCustomer />
                </SystemProtectedRoute>
              }
            />
            <Route
              path="/admin-profile"
              element={
                <SystemProtectedRoute>
                  <AdminSettingPage />
                </SystemProtectedRoute>
              }
            />
            <Route
              path="/shop/dashboard-create-product"
              element={
                <ShopProtectedRoute>
                  <CreateProductPage />
                </ShopProtectedRoute>
              }
            />
            <Route
              path="/shop/dashboard-orders"
              element={
                <ShopProtectedRoute>
                  <AllShopOrdersPage />
                </ShopProtectedRoute>
              }
            />
            <Route
              path="/shop/settings"
              element={
                <ShopProtectedRoute>
                  <ShopSettingPage />
                </ShopProtectedRoute>
              }
            />
            <Route
              path="/shop/dashboard-inbox"
              element={
                <ShopProtectedRoute>
                  <ShopInboxPage />
                </ShopProtectedRoute>
              }
            />
            <Route
              path="/shop/dashboard-withdraw-money"
              element={
                <ShopProtectedRoute>
                  <WithdrawMoneyPage />
                </ShopProtectedRoute>
              }
            />
            <Route
              path="/shop/dashboard-create-event"
              element={
                <ShopProtectedRoute>
                  <CreateEventPage />
                </ShopProtectedRoute>
              }
            />
            <Route
              path="/shop/dashboard-create-coupon"
              element={
                <ShopProtectedRoute>
                  <CreateCouponPage />
                </ShopProtectedRoute>
              }
            />
            <Route
              path="/shop/dashboard-refunds"
              element={
                <ShopProtectedRoute>
                  <ShopRefunds />
                </ShopProtectedRoute>
              }
            />
            <Route
              path="/shop/dashboard-products"
              element={
                <ShopProtectedRoute>
                  <ShopProductsPage />
                </ShopProtectedRoute>
              }
            />
            <Route
              path="/shop/dashboard-events"
              element={
                <ShopProtectedRoute>
                  <ShopEventsPage />
                </ShopProtectedRoute>
              }
            />
            <Route
              path="/shop/dashboard-coupons"
              element={
                <ShopProtectedRoute>
                  <ShopCouponsPage />
                </ShopProtectedRoute>
              }
            />{" "}
            <Route
              path={`/order/:orderId`}
              element={
                <ShopProtectedRoute>
                  <ShopOrderDetails />
                </ShopProtectedRoute>
              }
            />
            <Route
              path={`/admin/order/:orderId`}
              element={
                <SystemProtectedRoute>
                  <AdminOrderDetails />
                </SystemProtectedRoute>
              }
            />
            <Route
              path="/shop/dashboard"
              element={
                <ShopProtectedRoute>
                  <ShopDashboardPage />
                </ShopProtectedRoute>
              }
            />
            <Route path="/products" element={<ProductsPage />} />
            <Route path="/best-selling" element={<BestSellingPage />} />
            <Route path="/events" element={<EventsPage />} />
            <Route path="/faq" element={<FAQPage />} />
            <Route path="/product/:id" element={<ProductDetailsPage />} />
            <Route path="/seller/:shopId" element={<SellerPage />} />
            <Route
              path="/profile"
              element={
                <ProtectedRoute>
                  <ProfilePage />
                </ProtectedRoute>
              }
            />
            <Route
              path="/inbox"
              element={
                <ProtectedRoute>
                  <UserInbox />
                </ProtectedRoute>
              }
            />
            <Route
              path="/user/order/:orderId"
              element={
                <ProtectedRoute>
                  <OrderDetailsPage />
                </ProtectedRoute>
              }
            />
            <Route
              path="/user/track/order/:orderId"
              element={
                <ProtectedRoute>
                  <TrackOrderPage />
                </ProtectedRoute>
              }
            />
            <Route path="*" element={<NotFound />} />
          </Routes>

          <ToastContainer
            position="bottom-center"
            autoClose={4000}
            hideProgressBar={false}
            newestOnTop={false}
            closeOnClick
            rtl={false}
            pauseOnFocusLoss
            draggable
            pauseOnHover
            theme="dark"
          />
        </>
      )}
    </ShopFormProvider>
  );
};

const App = () => {
  const [stripeApiKey, setStripeApiKey] = useState("");

  const getStripeApiKey = async () => {
    const { data } = await axios.get(`${server}/payment/stripeApiKey`);
    setStripeApiKey(data.stripeApiKey);
    console.log(data.stripeApiKey);
  };

  useEffect(() => {
    getStripeApiKey();
  }, []);

  return (
    <Router>
      {stripeApiKey && (
        <Elements stripe={loadStripe(stripeApiKey)}>
          <Routes>
            <Route
              path="/checkout"
              element={
                <ProtectedRoute>
                  <CheckoutPage />
                </ProtectedRoute>
              }
            />
          </Routes>
        </Elements>
      )}
      <AppContent />
    </Router>
  );
};

export default App;
