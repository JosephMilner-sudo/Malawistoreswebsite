import axios from "axios";
import { createContext, useEffect, useState } from "react";
import { server } from "../server";
import { toast } from "react-toastify";
import secureLocalStorage from "react-secure-storage";
import { useNavigate } from "react-router-dom";

export const ShopFormContext = createContext();

export const ShopFormProvider = ({ children }) => {
  const initialFormData = {
    basicDetails: { name: "", description: "", logo: null },
    contactDetails: {
      email: "",
      phone: "",
      physicalAddress: "",
      city: "",
      country: "",
      postalCode: "",
    },
    businessRegDetails: {
      businessType: "",
      tinCertificate: null,
      registrationCertificate: null,
    },
    ownerDetails: {
      ownerName: "",
      ownerPhoneNumber: "",
      ownerEmail: "",
      nationalID: null,
      dateOfBirth: "",
      gender: "",
    },
    securityDetails: {
      password: "",
      confirmPassword: "",
      securityQuestion: "",
      securityAnswer: "",
    },
  };

  const [loading, setLoading] = useState(false);
  const [errors, setErrors] = useState({});
  const [currentStep, setCurrentStep] = useState(() => {
    const savedStep = secureLocalStorage.getItem("currentStep");
    return savedStep ? JSON.parse(savedStep) : 1;
  });
  const [formData, setFormData] = useState(() => {
    const savedData = secureLocalStorage.getItem("formData");
    return savedData ? JSON.parse(savedData) : initialFormData;
  });
  const navigate = useNavigate();

  // List of fields to exclude from secure storage
  const excludedFields = [
    "logo",
    "tinCertificate",
    "registrationCertificate",
    "nationalID",
  ];

  // Save formData to secure storage whenever it changes
  useEffect(() => {
    const dataToSave = {};

    Object.keys(formData).forEach((section) => {
      dataToSave[section] = {};
      Object.keys(formData[section]).forEach((field) => {
        const value = formData[section][field];

        // Exclude null/empty fields and the specified file fields
        if (value !== null && value !== "" && !excludedFields.includes(field)) {
          dataToSave[section][field] = value;
        }
      });
    });

    secureLocalStorage.setItem("formData", JSON.stringify(dataToSave));
  }, [formData]);

  // Save currentStep to secure storage whenever it changes
  useEffect(() => {
    secureLocalStorage.setItem("currentStep", JSON.stringify(currentStep));
  }, [currentStep]);

  const handleChange = (step, data) => {
    setFormData((prevState) => ({
      ...prevState,
      [step]: { ...prevState[step], ...data },
    }));
  };

  const validate = (step) => {
    const currentData = formData[step];
    const newErrors = {};

    // Helper function for phone number validation
    const isValidPhoneNumber = (number) => {
      const phoneRegex = /^265[289]\d{7,13}$/; // Matches numbers starting with 2652 or 2658 and 8–15 digits in total
      return phoneRegex.test(number);
    };

    // Helper function for checking if a string is a valid number
    const isValidNumber = (value) => {
      return !isNaN(value) && value > 0;
    };

    const validations = {
      basicDetails: () => {
        if (!currentData.name) {
          newErrors.basicDetails = {
            ...newErrors.basicDetails,
            name: "Name is required.",
          };
        }
        if (!currentData.description) {
          newErrors.basicDetails = {
            ...newErrors.basicDetails,
            description: "Description is required.",
          };
        }
        if (!currentData.logo) {
          newErrors.basicDetails = {
            ...newErrors.basicDetails,
            logo: "Logo is required.",
          };
        } else if (currentData.logo.size > 3 * 1024 * 1024) {
          newErrors.basicDetails = {
            ...newErrors.basicDetails,
            logo: "Logo must not exceed 3MB.",
          };
        }
      },

      contactDetails: () => {
        if (!currentData.email) {
          newErrors.contactDetails = {
            ...newErrors.contactDetails,
            email: "Email is required.",
          };
        }
        if (!isValidPhoneNumber(currentData.phone)) {
          newErrors.contactDetails = {
            ...newErrors.contactDetails,
            phone: "Invalid phone number. i.e. (265996570252)",
          };
        }
        if (!currentData.physicalAddress) {
          newErrors.contactDetails = {
            ...newErrors.contactDetails,
            physicalAddress: "Physical address is required.",
          };
        }
        if (!currentData.city) {
          newErrors.contactDetails = {
            ...newErrors.contactDetails,
            city: "City is required.",
          };
        }
        if (!currentData.country) {
          newErrors.contactDetails = {
            ...newErrors.contactDetails,
            country: "Country is required.",
          };
        }
      },

      businessRegDetails: () => {
        if (!currentData.businessType) {
          newErrors.businessRegDetails = {
            ...newErrors.businessRegDetails,
            businessType: "Business type is required.",
          };
        }
        if (!currentData.tinCertificate) {
          newErrors.businessRegDetails = {
            ...newErrors.businessRegDetails,
            tinCertificate: "TIN certificate is required.",
          };
        } else if (currentData.tinCertificate.size > 3 * 1024 * 1024) {
          newErrors.businessRegDetails = {
            ...newErrors.businessRegDetails,
            tinCertificate: "TIN certificate must not exceed 3MB.",
          };
        }

        if (!currentData.registrationCertificate) {
          newErrors.businessRegDetails = {
            ...newErrors.businessRegDetails,
            registrationCertificate: "Registration certificate is required.",
          };
        } else if (currentData.registrationCertificate.size > 3 * 1024 * 1024) {
          newErrors.businessRegDetails = {
            ...newErrors.businessRegDetails,
            registrationCertificate:
              "Registration certificate must not exceed 3MB.",
          };
        }
      },

      ownerDetails: () => {
        if (!currentData.ownerName) {
          newErrors.ownerDetails = {
            ...newErrors.ownerDetails,
            ownerName: "Owner name is required.",
          };
        }
        if (!isValidPhoneNumber(currentData.ownerPhoneNumber)) {
          newErrors.ownerDetails = {
            ...newErrors.ownerDetails,
            ownerPhoneNumber: "Invalid phone number. i.e (265996570252)",
          };
        }
        if (!currentData.ownerEmail) {
          newErrors.ownerDetails = {
            ...newErrors.ownerDetails,
            ownerEmail: "Owner email is required.",
          };
        }
        if (!currentData.nationalID) {
          newErrors.ownerDetails = {
            ...newErrors.ownerDetails,
            nationalID: "National ID is required.",
          };
        } else if (currentData.nationalID.size > 3 * 1024 * 1024) {
          newErrors.ownerDetails = {
            ...newErrors.ownerDetails,
            nationalID: "National ID must not exceed 3MB.",
          };
        }
        if (!currentData.dateOfBirth) {
          newErrors.ownerDetails = {
            ...newErrors.ownerDetails,
            dateOfBirth: "Date of birth is required.",
          };
        }
        if (!currentData.gender) {
          newErrors.ownerDetails = {
            ...newErrors.ownerDetails,
            gender: "Gender is required.",
          };
        }
      },

      securityDetails: () => {
        if (!currentData.password) {
          newErrors.securityDetails = {
            ...newErrors.securityDetails,
            password: "Password is required.",
          };
        }
        if (currentData.password !== currentData.confirmPassword) {
          newErrors.securityDetails = {
            ...newErrors.securityDetails,
            confirmPassword: "Passwords do not match.",
          };
        }
        if (!currentData.securityQuestion) {
          newErrors.securityDetails = {
            ...newErrors.securityDetails,
            securityQuestion: "Security question is required.",
          };
        }
        if (!currentData.securityAnswer) {
          newErrors.securityDetails = {
            ...newErrors.securityDetails,
            securityAnswer: "Security answer is required.",
          };
        }
      },
    };

    if (validations[step]) validations[step]();

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const goToNextStep = () => {
    setCurrentStep(currentStep + 1);
  };

  const handleNext = async () => {
    const steps = [
      "basicDetails",
      "contactDetails",
      "businessRegDetails",
      "ownerDetails",
      "securityDetails",
    ];
    const stepKey = steps[currentStep - 1];

    if (validate(stepKey)) {
      if (currentStep <= 5) {
        goToNextStep();
      } else {
        handleSubmit();
      }
    } else {
      console.log(`Validation failed for step ${currentStep} (${stepKey})`);
    }
  };

  const handleBack = () => {
    if (currentStep > 1) {
      setCurrentStep(currentStep - 1);
    }
  };

  const handleSubmit = async () => {
    const options = {
      headers: {
        "Content-Type": "multipart/form-data",
      },
    };

    const formDataToSend = new FormData();

    // Append Basic Details
    formDataToSend.append("name", formData.basicDetails.name);
    formDataToSend.append("description", formData.basicDetails.description);
    if (formData.basicDetails.logo) {
      formDataToSend.append("logo", formData.basicDetails.logo);
    }

    // Append Contact Details
    formDataToSend.append("email", formData.contactDetails.email);
    formDataToSend.append("phone", formData.contactDetails.phone);
    formDataToSend.append(
      "physicalAddress",
      formData.contactDetails.physicalAddress
    );
    formDataToSend.append("city", formData.contactDetails.city);
    formDataToSend.append("country", formData.contactDetails.country);
    formDataToSend.append("postalCode", formData.contactDetails.postalCode);

    // Append Business Registration Details
    formDataToSend.append(
      "businessType",
      formData.businessRegDetails.businessType
    );
    if (formData.businessRegDetails.tinCertificate) {
      formDataToSend.append(
        "tinCertificate",
        formData.businessRegDetails.tinCertificate
      );
    }
    if (formData.businessRegDetails.registrationCertificate) {
      formDataToSend.append(
        "registrationCertificate",
        formData.businessRegDetails.registrationCertificate
      );
    }

    // Append Owner Details
    formDataToSend.append("ownerName", formData.ownerDetails.ownerName);
    formDataToSend.append(
      "ownerPhoneNumber",
      formData.ownerDetails.ownerPhoneNumber
    );
    formDataToSend.append("ownerEmail", formData.ownerDetails.ownerEmail);
    formDataToSend.append("gender", formData.ownerDetails.gender);
    formDataToSend.append("dateOfBirth", formData.ownerDetails.dateOfBirth);
    if (formData.ownerDetails.nationalID) {
      formDataToSend.append("nationalID", formData.ownerDetails.nationalID);
    }

    // Append Security Details
    formDataToSend.append("password", formData.securityDetails.password);
    formDataToSend.append(
      "confirmPassword",
      formData.securityDetails.confirmPassword
    );
    formDataToSend.append(
      "securityQuestion",
      formData.securityDetails.securityQuestion
    );
    formDataToSend.append(
      "securityAnswer",
      formData.securityDetails.securityAnswer
    );

    setLoading(true);

    await axios
      .post(`${server}/shop/create-shop`, formDataToSend, options)
      .then((res) => {
        setLoading(false);
        toast.success(res.data?.message);

        // Clear formData from state
        //setFormData(initialFormData);
        //setCurrentStep(1);

        //navigate("/login-shop");

        // Remove data from secure storage
        //secureLocalStorage.removeItem("formData");
        //secureLocalStorage.removeItem("currentStep");
      })
      .catch((err) => {
        setLoading(false);
        toast.error(err.response?.data?.message || "An error occurred");
      });
  };

  return (
    <ShopFormContext.Provider
      value={{
        formData,
        currentStep,
        handleBack,
        handleChange,
        handleNext,
        errors,
        loading,
      }}
    >
      {children}
    </ShopFormContext.Provider>
  );
};
