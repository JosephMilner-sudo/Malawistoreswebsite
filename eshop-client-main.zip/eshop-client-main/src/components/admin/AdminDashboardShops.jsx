import React, { useEffect } from "react";
import { useState } from "react";
import axios from "axios";
import { server } from "../../server";
import Spinner from "../Spinner";
import styles from "../../styles/styles";
import { Link } from "react-router-dom";
import { CgEye } from "react-icons/cg";

const AdminDashboardShops = () => {
  const [shops, setShops] = useState([]);
  const [loading, setLoading] = useState(false);
  const [searchTerm, setSearchTerm] = useState("");
  const [currentPage, setCurrentPage] = useState(1);
  const [recordsPerPage, setRecordsPerPage] = useState(10);
  const shopsPerPage = recordsPerPage;

  useEffect(() => {
    const loadAllShops = async () => {
      setLoading(true);
      await axios
        .get(`${server}/shop/get-all-shops`, { withCredentials: true })
        .then((res) => {
          setLoading(false);
          setShops(res.data?.shops);
        })
        .catch((err) => {
          setLoading(false);
          console.log(err);
        });
    };

    loadAllShops();
  }, []);

  const filteredshops = shops?.filter(
    (shop) =>
      shop.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      shop._id.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const totalPages = Math.ceil(filteredshops?.length / shopsPerPage);
  const indexOfLastshop = currentPage * shopsPerPage;
  const indexOfFirstshop = indexOfLastshop - shopsPerPage;
  const currentshops = filteredshops?.slice(indexOfFirstshop, indexOfLastshop);

  const handlePageChange = (pageNumber) => {
    setCurrentPage(pageNumber);
  };

  const handleRecordsPerPageChange = (event) => {
    setRecordsPerPage(Number(event.target.value));
    setCurrentPage(1); // Reset to page 1 when records per page changes
  };

  if (loading) {
    return <Spinner />;
  }
  return (
    <div className="bg-white w-full mt-10 800px:px-8 px-4 p-4 rounded-xl shadow-sm  overflow-auto">
      <div className="flex flex-col 800px:flex-row items-center justify-between mb-4">
        <h1 className="text-xl font-semibold mb-2 800px:mb-0">All shops</h1>
        <input
          type="text"
          placeholder="Search by ID and name..."
          className={`${styles.input} !w-[50%]`}
          value={searchTerm}
          onChange={(e) => {
            setSearchTerm(e.target.value);
            setCurrentPage(1); // Reset to page 1 on new search
          }}
        />
      </div>

      <div className="overflow-x-auto">
        <table className="min-w-full divide-y divide-gray-200 text-sm text-left border">
          <thead className="bg-white border-b">
            <tr className="text-xs font-semibold text-gray-600 uppercase tracking-wider">
              <th className="px-6 py-4 border-r">shop Id</th>
              <th className="px-6 py-4 border-r">Name</th>
              <th className="px-6 py-4 border-r text-right">Email</th>
              <th className="px-6 py-4 border-r text-right">City</th>
              <th className="px-6 py-4 border-r text-right">Is Approved ?</th>
              <th className="px-6 py-4 border-r text-right">Preview</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-gray-100">
            {currentshops?.map((shop) => (
              <tr key={shop._id} className="hover:bg-gray-50">
                <td className="px-4 py-2">{shop._id}</td>
                <td className="px-4 py-2">
                  {shop.name?.length > 50
                    ? shop.name?.slice(0, 50) + " ..."
                    : shop.name}
                </td>
                <td className="px-4 py-2 text-right">{shop.email}</td>
                <td className="px-4 py-2 text-right">{shop.city}</td>
                <td className="px-4 py-2">
                  {shop.isApproved ? (
                    <h4 className="px-2 py-1 bg-green-400 text-white rounded-xl font-[500]">
                      Yes
                    </h4>
                  ) : (
                    <h4 className="px-2 py-1 bg-red-400 text-white rounded-xl font-[500]">
                      No
                    </h4>
                  )}
                </td>
                <td className="px-4 py-2 text-right">
                  <Link
                    to={`/seller/${shop._id}`}
                    className="text-blue-500 hover:text-blue-700 text-center flex justify-center"
                  >
                    <CgEye size={20} />
                  </Link>
                </td>
              </tr>
            ))}
            {currentshops?.length === 0 && (
              <tr>
                <td colSpan="7" className="text-center py-4 text-gray-500">
                  No shops found.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>

      {/* Pagination */}
      {totalPages > 1 && (
        <div className="flex justify-between items-center mt-6 space-x-4">
          {/* Records per page */}
          <div className="flex items-center space-x-2">
            <span className="text-gray-700">Records per page:</span>
            <select
              value={recordsPerPage}
              onChange={handleRecordsPerPageChange}
              className="border border-gray-300 px-2 py-1 rounded-md text-sm"
            >
              {[5, 10, 20, 50].map((count) => (
                <option key={count} value={count}>
                  {count}
                </option>
              ))}
            </select>
          </div>

          {/* Pagination buttons */}
          <div className="flex items-center space-x-2">
            <button
              onClick={() => handlePageChange(1)}
              className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700"
              disabled={currentPage === 1}
            >
              First
            </button>
            <button
              onClick={() => handlePageChange(currentPage - 1)}
              className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700"
              disabled={currentPage === 1}
            >
              Prev
            </button>
            <span className="text-sm">{`Page ${currentPage} of ${totalPages}`}</span>
            <button
              onClick={() => handlePageChange(currentPage + 1)}
              className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700"
              disabled={currentPage === totalPages}
            >
              Next
            </button>
            <button
              onClick={() => handlePageChange(totalPages)}
              className="px-4 py-2 bg-blue-600 text-black rounded-md hover:bg-blue-700"
              disabled={currentPage === totalPages}
            >
              Last
            </button>
          </div>
        </div>
      )}
    </div>
  );
};

export default AdminDashboardShops;
