import React from "react";
import { backendUrl } from "../../server";
import { AiOutlineShop } from "react-icons/ai";

const AdminFullDetails = ({ admin }) => {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 p-4">
      <div className="col-span-full flex flex-col items-center text-center border-b pb-1">
        <h2 className="text-xl font-semibold mb-1">{admin.name}</h2>
        <p className="text-sm text-gray-400 mb-2 font-light">#{admin._id}</p>
        <div className="rounded-full border h-[150px] w-[150px] border-primary relative self-center">
          {admin.avatar ? (
            <img
              src={`${backendUrl}/${admin.avatar}`}
              alt="Shop Logo"
              className="object-contain w-full h-full rounded-full"
            />
          ) : (
            <AiOutlineShop className="w-full h-full" />
          )}
        </div>
      </div>
      <p>
        <strong>Email:</strong> {admin.email}
      </p>
      <p>
        <strong>Role:</strong> {admin.role}
      </p>
      <p>
        <strong>Date created:</strong>{" "}
        {new Date(admin.createdAt).toDateString()}
      </p>
    </div>
  );
};

export default AdminFullDetails;
