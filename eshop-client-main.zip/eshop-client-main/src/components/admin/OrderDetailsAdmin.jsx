import React, { useEffect, useState } from "react";
import { Link, useNavigate, useParams } from "react-router-dom";
import { useDispatch, useSelector } from "react-redux";
import { FaShoppingBag } from "react-icons/fa";
import axios from "axios";
import { toast } from "react-toastify";
import { backendUrl, server } from "../../server";
import styles from "../../styles/styles";
import { toKwacha } from "../../utils/toKwacha";
import { getAllOrders } from "../../redux/actions/order";
import { CgArrowRight, CgClose, CgInfo } from "react-icons/cg";
import { AiFillDelete } from "react-icons/ai";

const OrderDetailsAdmin = () => {
  const { orders } = useSelector((state) => state.order);
  const { orderId } = useParams();
  const dispatch = useDispatch();
  const [status, setStatus] = useState("");
  const navigate = useNavigate();
  const [toggleCustomerInfo, setToggleCustomerInfo] = useState(false);
  const [deleteTag, setDeleteTag] = useState(false);
  const [approveLoading, setApproveLoading] = useState(false);

  const orderStatuses = [
    "Processing",
    "Transferred to delivery partner",
    "Shipping",
    "Received",
    "On the way",
    "Delivered",
  ];

  useEffect(() => {
    dispatch(getAllOrders());
  }, []);

  const deleteOrder = async () => {
    setApproveLoading(true);
    await axios
      .delete(`${server}/order/delete-order/${orderId}`, {
        withCredentials: true,
      })
      .then((res) => {
        setApproveLoading(false);
        setDeleteTag(false);
        toast.success("Order deleted successfully");

        setTimeout(() => {
          navigate("/admin-orders");
        }, 1500);
      })
      .catch((err) => {
        setApproveLoading(false);
        toast.error(err.response ? err.response.data.message : err.message);
      });
  };

  const updateOrderStatusHandler = async () => {
    await axios
      .put(
        `${server}/order/admin/update-order-status/${orderId}`,
        { status },
        { withCredentials: true }
      )
      .then((res) => {
        toast.success("Order Updated!");
        setTimeout(() => {
          navigate("/admin-orders");
        }, 1500);
      })
      .catch((err) => {
        toast.error(err.response.data.message);
      });
  };

  const updateRefundStatusHandler = async () => {
    await axios
      .put(
        `${server}/order/admin/order-refund-success/${orderId}`,
        { status },
        { withCredentials: true }
      )
      .then((res) => {
        toast.success(res?.data.message);
        setTimeout(() => {
          navigate("/admin-refunds");
        }, 1500);
      })
      .catch((err) => {
        toast.error(err.response.data.message);
      });
  };

  const data = orders && orders.find((item) => item._id === orderId);

  return (
    <div className={`min-h-screen py-8 relative`}>
      <div className={`${styles.section}`}>
        <div className="flex items-center justify-between 800px:p-4 p-2">
          <div className="flex items-center gap-3">
            <FaShoppingBag size={38} className="text-yellow-600" />
            <h1 className="800px:text-2xl text-lg font-semibold text-gray-800">
              Order Details
            </h1>
          </div>

          <div className="flex gap-4">
            <Link
              className="px-4 py-2 rounded-md border-2 border-yellow-500 bg-yellow-200 hover:bg-yellow-300 transition 800px:text-md text-sm"
              to={"/admin-orders"}
            >
              Order List
            </Link>

            <button
              className="flex items-center gap-1 px-4 py-2 rounded bg-red-500 text-white font-[500]"
              onClick={() => setDeleteTag(true)}
            >
              <AiFillDelete size={20} /> Delete{" "}
            </button>
          </div>
        </div>

        <div className="flex justify-between pt-6 800px:text-md text-sm">
          <h5 className="text-gray-600">
            Order ID:{" "}
            <span className="text-gray-800">#{data?._id?.slice(0, 8)}</span>
          </h5>
          <h5 className="text-gray-600">
            Placed On:{" "}
            <span className="text-gray-800">
              {data?.createdAt?.slice(0, 10)}
            </span>
          </h5>
        </div>

        <div className="pt-6">
          {data?.cart?.map((item, index) => (
            <div key={index} className="flex items-center mb-6 border-b pb-4">
              <img
                src={`${backendUrl}/${item.images[0]}`}
                className="w-20 h-20 object-contain"
                alt={item?.name}
              />
              <div className="ml-4 w-full">
                <h5 className="800px:text-md text-sm font-medium">
                  {item?.name}
                </h5>
                <h5 className="text-gray-600 800px:text-md text-sm">
                  {toKwacha(item?.discountPrice || item?.originalPrice)} x{" "}
                  {item.quantity}
                </h5>
              </div>
            </div>
          ))}
        </div>

        <Link
          to={`/seller/${data?.cart[0]?.shop?._id}`}
          className={`text-sm mt-2 border-2 bg-white shadow-md rounded px-4 py-2 border-yellow-500 flex gap-1 items-center w-[150px]`}
          onClick={() => {
            setToggleCustomerInfo(true);
          }}
        >
          {" "}
          Visit Shop
          <CgArrowRight size={20} />
        </Link>

        <div className="pt-4 text-right">
          <h5 className="800px:text-md text-sm font-semibold">
            Total Price:{" "}
            <span className="font-bold">{toKwacha(data?.totalPrice)}</span>
          </h5>
        </div>

        <div className="flex flex-wrap pt-6">
          <div className="w-full md:w-2/3 mb-6 md:mb-0">
            <h4 className="800px:text-md text-sm font-semibold">
              Shipping Address
            </h4>
            <p className="800px:text-md text-sm">
              {data?.shippingAddress?.address1}{" "}
              {data?.shippingAddress?.address2}
            </p>
            <p className="800px:text-md text-sm">
              {data?.shippingAddress?.city}, {data?.shippingAddress?.country}
            </p>
            <p className="800px:text-md text-sm">{data?.user?.phoneNumber}</p>
          </div>
          <div className="w-full md:w-1/3">
            <h4 className="800px:text-md text-sm font-semibold">
              Payment Info
            </h4>
            <p className="800px:text-md text-sm">
              Type: {data?.paymentInfo?.type}
            </p>
            <p className="800px:text-md text-sm">
              Status: {data?.paymentInfo?.status || "Not Paid"}
            </p>
          </div>

          <button
            className={`text-sm mt-2 border-2 bg-white shadow-md rounded px-4 py-2 border-yellow-500 flex gap-1 items-center`}
            onClick={() => {
              setToggleCustomerInfo(true);
            }}
          >
            {" "}
            <CgInfo size={20} />
            Customer Info
          </button>
        </div>

        <div className="pt-6 w-full md:w-1/4">
          <h4 className="800px:text-md text-sm font-semibold">Order Status</h4>
          <select
            className="block w-full px-4 py-2 mt-2 border rounded-md shadow-sm focus:ring-2 focus:ring-yellow-500 800px:text-md text-sm"
            value={status}
            onChange={(e) => setStatus(e.target.value)}
          >
            {data?.status !== "Processing Refund" &&
            data?.status !== "Refund Successful"
              ? orderStatuses
                  .slice(orderStatuses.indexOf(data?.status))
                  .map((option, index) => (
                    <option key={index} value={option}>
                      {option}
                    </option>
                  ))
              : ["Processing Refund", "Refund Successful"]
                  .slice(
                    ["Processing Refund", "Refund Successful"].indexOf(
                      data?.status
                    )
                  )
                  .map((option, index) => (
                    <option key={index} value={option}>
                      {option}
                    </option>
                  ))}
          </select>

          <button
            className="800px:text-md text-sm mt-4 w-full px-5 py-3 bg-yellow-600 text-white rounded-md hover:bg-yellow-700 transition"
            onClick={
              data?.status !== "Processing Refund" &&
              data?.status !== "Refund Successful"
                ? updateOrderStatusHandler
                : updateRefundStatusHandler
            }
          >
            Update Status
          </button>
        </div>
      </div>

      {toggleCustomerInfo && (
        <div className="absolute w-full top-0 left-0 h-[100%] bg-black/35 flex justify-center items-start z-50">
          <div className="800px:w-[40%] w-[95%] bg-white pt-2 pb-5 mt-[30px] rounded shadow-lg">
            <div className="flex justify-between items-center border-b px-5 pb-3">
              <h2 className="text-lg font-semibold text-gray-700">
                Customer Details
              </h2>
              <button
                onClick={() => setToggleCustomerInfo(false)}
                className="text-gray-500 hover:text-red-500"
              >
                <CgClose size={20} />
              </button>
            </div>
            <div className="p-5">
              <div className="flex items-center space-x-4 mb-6">
                <img
                  src={`${backendUrl}/${data?.user.avatar}`}
                  alt="User Avatar"
                  className="w-16 h-16 rounded-full object-cover border"
                />
                <div>
                  <p className="text-lg font-medium text-gray-800">
                    {data?.user.name}
                  </p>
                  <p className="text-sm text-gray-500">{data?.user.role}</p>
                </div>
              </div>

              <div className="space-y-3 text-sm text-gray-700">
                <p>
                  <strong>Email:</strong> {data?.user.email}
                </p>
                <p>
                  <strong>Phone Number:</strong> +{data?.user.phoneNumber}
                </p>
                <p>
                  <strong>Account Created:</strong>{" "}
                  {new Date(data?.user.createdAt).toLocaleString()}
                </p>
                <p>
                  <strong>User ID:</strong> {data?.user._id}
                </p>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Delete Modal */}
      {deleteTag && (
        <div className="absolute w-full h-[100%] bg-black/30 top-0 items-start left-0 flex justify-center">
          <div className="800px:w-[30%] w-[95%] pb-5 pt-3 bg-white mt-[150px] rounded px-4">
            <button
              className="w-full flex justify-end p-1 rounded-full"
              onClick={() => setDeleteTag(false)}
            >
              <CgClose size={24} />
            </button>
            <h1 className="text-lg font-[600] w-full border-b text-red-500 animate-pulse">
              Deleting an order !
            </h1>
            <div className="mt-6">
              <h4 className="text-sm font-[400]">
                Are you sure about this delete action?
              </h4>
              <p className="text-sm text-red-400 mt-2">
                Take note that this action is irreversible and destructive!
              </p>
            </div>
            <div className="flex items-center gap-4 mt-4">
              <button
                onClick={() => setDeleteTag(false)}
                className="px-4 py-2 bg-green-500 rounded text-white text-sm mt-1"
              >
                Cancel
              </button>
              <button
                disabled={approveLoading}
                onClick={() => deleteOrder()}
                className="px-4 py-2 bg-red-500 rounded text-white text-sm mt-1"
              >
                Delete
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default OrderDetailsAdmin;
