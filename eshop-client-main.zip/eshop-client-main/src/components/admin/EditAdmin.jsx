import React, { useState } from "react";
import { AiOutlineCamera, AiOutlineShop } from "react-icons/ai";
import { useDispatch, useSelector } from "react-redux";
import styles from "../../styles/styles";
import { backendUrl, server } from "../../server";
import axios from "axios";
import { toast } from "react-toastify";
import { loadSystemUser } from "../../redux/actions/system";
import { ClipLoader } from "react-spinners";

const EditAdmin = () => {
  const { admin } = useSelector((state) => state.system);
  const [logo, setLogo] = useState(null);
  const [loading, setLoading] = useState(false);
  const [formData, setFormData] = useState({
    name: admin?.name || "",
    role: admin?.role || "",
  });
  const dispatch = useDispatch();

  const handleChange = (e) => {
    const { name, value } = e.target;

    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    setLoading(true);

    await axios
      .put(
        `${server}/system/update-system-info`,
        { ...formData, id: admin?._id },
        {
          withCredentials: true,
        }
      )
      .then((res) => {
        setLoading(false);
        toast.success("System Info updated successfully");
        setTimeout(() => {
          dispatch(loadSystemUser());
        }, 1500);
      })
      .catch((err) => {
        setLoading(false);
        toast.error(err?.response?.data.message);
      });
  };

  const handleImage = async (e) => {
    e.preventDefault();

    const logoFile = e.target.files[0];
    setLogo(logoFile);

    const formData = new FormData();

    formData.append("avatar", logoFile);

    setLoading(true);

    await axios
      .put(`${server}/system/update-system-avatar`, formData, {
        headers: {
          "Content-Type": "multipart/form-data",
        },
        withCredentials: true,
      })
      .then((res) => {
        setLoading(false);
        toast.success("Avatar uploaded successfully");
        setTimeout(() => {
          dispatch(loadSystemUser());
        }, 1500);
      })
      .catch((err) => {
        setLoading(false);
        toast.error(err?.response?.data.message);
      });
  };

  return (
    <form
      onSubmit={handleSubmit}
      className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 p-4"
    >
      <div className="col-span-full flex flex-col items-center text-center border-b pb-1">
        <div className="w-full flex 800px:flex-row flex-col justify-evenly 800px:items-start gap-3 mt-2">
          <div className="rounded-full border h-[70px] w-[70px] border-primary relative self-center">
            {admin.avatar ? (
              <img
                src={
                  logo
                    ? URL.createObjectURL(logo)
                    : `${backendUrl}/${admin.avatar}`
                }
                alt="Shop Logo"
                className="object-cover w-full h-full rounded-full"
              />
            ) : (
              <AiOutlineShop className="w-full h-full" />
            )}
            <div className="absolute top-[-15px] left-7 bg-primary z-20 rounded-full p-0.5">
              <input
                onChange={handleImage}
                type="file"
                id="avatar"
                className="hidden"
                accept="image/*"
              />
              <label htmlFor="avatar" className="cursor-pointer">
                <AiOutlineCamera size={20} className="text-white" />
              </label>
            </div>
          </div>

          <div className="flex flex-col gap-1 items-start">
            <label htmlFor="">Full Name</label>
            <input
              className={`${styles.input}}`}
              type="text"
              name="name"
              value={formData.name}
              onChange={handleChange}
              required
            />
          </div>

          <div className="flex flex-col gap-1 items-start">
            <label htmlFor="">Role</label>
            <select
              className={`${styles.input}}`}
              name="role"
              value={formData.role}
              onChange={handleChange}
              required
            >
              <option value="">Select Role</option>
              <option value="admin">Admin</option>
            </select>
          </div>
        </div>
      </div>

      <div className="flex flex-col gap-1 items-start">
        <label htmlFor="">Password</label>
        <input
          className={`${styles.input}}`}
          type="password"
          name="password"
          value={formData.password}
          onChange={handleChange}
          required
        />
      </div>
      <button
        disabled={loading}
        type="submit"
        className={`${styles.button} 800px:col-span-3`}
      >
        {loading ? <ClipLoader size={24} color={"white"} /> : "Update"}
      </button>
    </form>
  );
};

export default EditAdmin;
