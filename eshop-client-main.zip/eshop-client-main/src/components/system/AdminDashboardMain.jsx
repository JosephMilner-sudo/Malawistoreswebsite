import React, { useEffect, useState } from "react";
import { AiOutlineMoneyCollect } from "react-icons/ai";
import { MdBorderClear } from "react-icons/md";
import { Link } from "react-router-dom";
import axios from "axios";
import { server } from "../../server";
import { toast } from "react-toastify";
import Loader from "../Loader";
import styles from "../../styles/styles";
import Spinner from "../Spinner";
import { toKwacha } from "../../utils/toKwacha";
import { BsEyeFill } from "react-icons/bs";

const AdminDashboardMain = () => {
  const [sellers, setSellers] = useState([]);
  const [adminOrders, setAdminOrders] = useState([]);
  const [adminOrderLoading, setAdminOrderLoading] = useState(false);
  const [sellersLoading, setSellersLoading] = useState(false);

  useEffect(() => {
    const loadAllSellers = async () => {
      setSellersLoading(true);
      await axios
        .get(`${server}/shop/get-all-shops`, { withCredentials: true })
        .then((res) => {
          setSellersLoading(false);
          setSellers(res.data.shops);
        })
        .catch((err) => {
          setSellersLoading(false);
          toast.error(err.response ? err.response.data.message : err.message);
        });
    };

    const loadAllOrders = async () => {
      setAdminOrderLoading(true);
      await axios
        .get(`${server}/order/get-all-orders`, { withCredentials: true })
        .then((res) => {
          setAdminOrderLoading(false);
          setAdminOrders(res.data.orders);
        })
        .catch((err) => {
          setAdminOrderLoading(false);
          toast.error(err.response ? err.response.data.message : err.message);
        });
    };

    loadAllOrders();
    loadAllSellers();
  }, []);

  const adminEarning =
    adminOrders &&
    adminOrders.reduce((acc, item) => acc + item.totalPrice * 0.1, 0);

  const adminBalance = adminEarning?.toFixed(2);

  const rows =
    adminOrders?.map((item) => ({
      id: item._id,
      quantity: item?.cart?.reduce((acc, item) => acc + item.quantity, 0),
      total: `${toKwacha(item?.totalPrice)}`,
      status: item?.status,
      createdAt: item?.createdAt.slice(0, 10),
    })) || [];

  const latestOrders = rows && rows.length > 4 ? rows.slice(0, 4) : rows;

  return (
    <>
      {adminOrderLoading && sellersLoading ? (
        <Spinner />
      ) : (
        <div className="w-full p-4">
          <h3 className="text-[22px] font-Poppins pb-2">Overview</h3>
          <div className="w-full block 800px:flex items-center justify-between">
            <div className="w-full mb-4 800px:w-[30%] min-h-[20vh] bg-white shadow rounded px-2 py-5">
              <div className="flex items-center">
                <AiOutlineMoneyCollect
                  size={30}
                  className="mr-2"
                  fill="#00000085"
                />
                <h3
                  className={`${styles.productTitle} !text-[18px] leading-5 !font-[400] text-[#00000085]`}
                >
                  Total Earning (10% / order)
                </h3>
              </div>
              <h5 className="pt-2 pl-[36px] text-[22px] font-[500]">
                {toKwacha(adminBalance)}
              </h5>
            </div>

            <div className="w-full mb-4 800px:w-[30%] min-h-[20vh] bg-white shadow rounded px-2 py-5">
              <div className="flex items-center">
                <MdBorderClear size={30} className="mr-2" fill="#00000085" />
                <h3
                  className={`${styles.productTitle} !text-[18px] leading-5 !font-[400] text-[#00000085]`}
                >
                  All Sellers
                </h3>
              </div>
              <h5 className="pt-2 pl-[36px] text-[22px] font-[500]">
                {sellers?.length}
              </h5>
              <Link to="/admin-sellers">
                <h5 className="pt-4 pl-2 text-[#077f9c]">View Sellers</h5>
              </Link>
            </div>

            <div className="w-full mb-4 800px:w-[30%] min-h-[20vh] bg-white shadow rounded px-2 py-5">
              <div className="flex items-center">
                <AiOutlineMoneyCollect
                  size={30}
                  className="mr-2"
                  fill="#00000085"
                />
                <h3
                  className={`${styles.productTitle} !text-[18px] leading-5 !font-[400] text-[#00000085]`}
                >
                  All Orders
                </h3>
              </div>
              <h5 className="pt-2 pl-[36px] text-[22px] font-[500]">
                {adminOrders?.length}
              </h5>
              <Link to="/admin-orders">
                <h5 className="pt-4 pl-2 text-[#077f9c]">View Orders</h5>
              </Link>
            </div>
          </div>

          <br />
          <h3 className="text-[22px] font-Poppins pb-2">Latest Orders</h3>
          <div className="w-full min-h-[45vh] bg-white rounded shadow overflow-x-auto">
            <table className="min-w-full text-sm text-left text-gray-500">
              <thead className="text-xs text-gray-700 uppercase bg-gray-100">
                <tr>
                  <th scope="col" className="px-6 py-3">
                    Order ID
                  </th>
                  <th scope="col" className="px-6 py-3">
                    Status
                  </th>
                  <th scope="col" className="px-6 py-3">
                    Items quantity
                  </th>
                  <th scope="col" className="px-6 py-3">
                    Total
                  </th>
                  <th scope="col" className="px-6 py-3">
                    Order Date
                  </th>
                  <th scope="col" className="px-6 py-3">
                    
                  </th>
                </tr>
              </thead>
              <tbody>
                {latestOrders.length === 0 ? (
                  <tr>
                    <td
                      colSpan="5"
                      className="px-6 py-4 text-center text-gray-400"
                    >
                      No orders found.
                    </td>
                  </tr>
                ) : (
                  rows.map((row) => (
                    <tr
                      key={row.id}
                      className="bg-white border-b hover:bg-gray-50 transition duration-150"
                    >
                      <td className="px-6 py-4 font-medium text-gray-900">
                        {row.id}
                      </td>
                      <td
                        className={`px-6 py-4 ${
                          row.status === "Delivered"
                            ? "text-green-600"
                            : "text-red-600"
                        }`}
                      >
                        {row.status}
                      </td>
                      <td className="px-6 py-4">{row.quantity}</td>
                      <td className="px-6 py-4">{row.total}</td>
                      <td className="px-6 py-4">{row.createdAt}</td>
                      <td className="px-6 py-4"><Link to={`/admin/order/${row?.id}`} className=""><BsEyeFill size={20} /></Link></td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </>
  );
};

export default AdminDashboardMain;
