import axios from "axios";
import React, { useState } from "react";
import {
  BiCreditCard,
  BiLock,
  BiLogOut,
  BiMenuAltLeft,
  BiMessage,
} from "react-icons/bi";
import { BsBag, BsPerson } from "react-icons/bs";
import { CgTrack } from "react-icons/cg";
import { FaAddressBook } from "react-icons/fa";
import { HiOutlineReceiptRefund } from "react-icons/hi";
import { server } from "../../../server";
import { toast } from "react-toastify";
import { useNavigate } from "react-router-dom";
import { MdCancel } from "react-icons/md";

const sidebarItems = [
  { id: 1, label: "Profile", icon: <BsPerson /> },
  { id: 2, label: "Orders", icon: <BsBag /> },
  { id: 3, label: "Refunds", icon: <HiOutlineReceiptRefund /> },
  { id: 4, label: "Inbox", icon: <BiMessage />, navigateTo: "/inbox" },
  { id: 5, label: "Track Order", icon: <CgTrack /> },
  { id: 6, label: "Payments", icon: <BiCreditCard /> },
  { id: 7, label: "Address", icon: <FaAddressBook /> },
  { id: 8, label: "Change Password", icon: <BiLock /> },
  { id: 9, label: "Logout", icon: <BiLogOut />, isLogout: true },
];

const ProfileSideBar = ({ active, setActive }) => {
  const navigate = useNavigate();
  const [toggleMenuLabels, setToggleMenuLabels] = useState(false);

  const logoutHandler = async () => {
    try {
      const res = await axios.get(`${server}/user/logout`, {
        withCredentials: true,
      });
      toast.success(res.data.message);
      window.location.reload();
      navigate("/login");
    } catch (err) {
      console.log(err.response?.data?.message);
    }
  };

  const handleClick = (item) => {
    setActive(item.id);
    setToggleMenuLabels(false);
    if (item.isLogout) logoutHandler();
    if (item.navigateTo) navigate(item.navigateTo);
  };

  return (
    <div className="flex flex-col">
      {!toggleMenuLabels ? (
        <button
          className="800px:hidden block self-end p-2"
          onClick={() => {
            setToggleMenuLabels(true);
          }}
        >
          <BiMenuAltLeft size={24} title="Maximize" />
        </button>
      ) : (
        <button
          className="800px:hidden block self-end p-2"
          onClick={() => {
            setToggleMenuLabels(false);
          }}
        >
          <MdCancel title="Minimize" size={24} />
        </button>
      )}
      <div className="w-full shadow-md rounded-sm flex flex-col items-start px-4 800px:py-7 py-4 gap-7 left-0 top-0 800px:sticky 800px:px-6 800px:top-[70px]">
        {sidebarItems.map((item) => (
          <div
            key={item.id}
            className="flex items-center gap-3 cursor-pointer"
            onClick={() => handleClick(item)}
          >
            {React.cloneElement(item.icon, {
              color: active === item.id ? "red" : undefined,
              size: 20,
            })}
            <span
              className={`800px:block 800px:text-[12pt] text-sm ${
                toggleMenuLabels ? "flex" : "hidden"
              }  ${active === item.id ? "text-red-600 font-semibold" : ""}`}
            >
              {item.label}
            </span>
          </div>
        ))}
      </div>
    </div>
  );
};

export default ProfileSideBar;
