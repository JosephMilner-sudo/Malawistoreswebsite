import React from "react";
import { Link } from "react-router-dom";
import { Logo } from "../../../static/data";
import {
  BiGift,
  BiMenu,
  BiMessageSquareDetail,
  BiPackage,
  BiShoppingBag,
  BiUserCircle,
} from "react-icons/bi";
import { MdCancel, MdOutlineLocalOffer } from "react-icons/md";
import { useSelector } from "react-redux";
import { backendUrl } from "../../../server";

const DashboardHeader = ({ toggleMenu, setToggleMenu }) => {
  const { shop } = useSelector((state) => state.shop);
  return (
    <div className="sticky w-full h-[80px] bg-primary top-0 left-0 z-30 flex items-center justify-between px-5 border-b-[1px] border-t-gray-600">
      {!toggleMenu ? (
        <button className="800px:hidden block" onClick={() => setToggleMenu(true)}>
          <BiMenu size={30} color="white" />
        </button>
      ) : (
        <button className="800px:hidden block" onClick={() => setToggleMenu(false)}>
          <MdCancel size={30} color="white" />
        </button>
      )}
      <div>
        <Link to={"/shop/dashboard"}>
          <img src={Logo} alt="" className="w-[60px] h-[50px]" />
        </Link>
      </div>

      <div className="flex items-center">
        <div className="items-center mr-4 800px:flex hidden">
          <Link to={"/shop/dashboard-coupons"}>
            {" "}
            <BiGift title="Coupons" size={30} className="text-white mx-4" />
          </Link>

          <Link to={"/shop/dashboard-offers"}>
            {" "}
            <MdOutlineLocalOffer
              title="Offers"
              size={30}
              className="text-white mx-4"
            />
          </Link>
          <Link to={"/shop/dashboard-orders"}>
            {" "}
            <BiShoppingBag
              title="Orders"
              size={30}
              className="text-white mx-4"
            />
          </Link>
          <Link to={"/shop/dashboard-products"}>
            {" "}
            <BiPackage size={30} title="Products" className="text-white mx-4" />
          </Link>
          <Link to={"/shop/dashboard-inbox"}>
            {" "}
            <BiMessageSquareDetail
              size={30}
              title="Messages"
              className="text-white mx-4"
            />
          </Link>
        </div>
        <Link
          to={`/seller/${shop?._id}`}
          title="Preview your shop"
          className="pl-4"
        >
          {shop?.logo ? (
            <img
              src={`${backendUrl}/${shop.logo}`}
              alt="LOGO"
              className="w-[50px] h-[50px] rounded-full object-cover border-2 border-white"
            />
          ) : (
            <BiUserCircle
              size={34}
              color="yellow"
              className="border-2 rounded-full border-yellow-400"
            />
          )}
        </Link>
      </div>
    </div>
  );
};

export default DashboardHeader;
