import React, { useState } from "react";
import { AiOutlineFolderAdd } from "react-icons/ai";
import {
  BiGift,
  BiMessageSquareDetail,
  BiPackage,
  BiShoppingBag,
} from "react-icons/bi";
import { CiMoneyBill, CiSettings } from "react-icons/ci";
import { HiOutlineReceiptRefund } from "react-icons/hi";
import { MdDashboard, MdOutlineLocalOffer } from "react-icons/md";
import { VscNewFile } from "react-icons/vsc";
import { Link } from "react-router-dom";
import { motion, AnimatePresence } from "framer-motion";

const links = [
  { id: 1, name: "Dashboard", icon: MdDashboard, path: "/shop/dashboard" },
  {
    id: 2,
    name: "Orders",
    icon: BiShoppingBag,
    path: "/shop/dashboard-orders",
  },
  {
    id: 3,
    name: "Products",
    icon: BiPackage,
    path: "/shop/dashboard-products",
  },
  {
    id: 4,
    name: "Create Product",
    icon: AiOutlineFolderAdd,
    path: "/shop/dashboard-create-product",
  },
  {
    id: 5,
    name: "Events",
    icon: MdOutlineLocalOffer,
    path: "/shop/dashboard-events",
  },
  {
    id: 6,
    name: "Create Event",
    icon: VscNewFile,
    path: "/shop/dashboard-create-event",
  },
  {
    id: 7,
    name: "Withdraw Money",
    icon: CiMoneyBill,
    path: "/shop/dashboard-withdraw-money",
  },
  {
    id: 8,
    name: "Shop Inbox",
    icon: BiMessageSquareDetail,
    path: "/shop/dashboard-inbox",
  },
  {
    id: 9,
    name: "Discount Codes",
    icon: BiGift,
    path: "/shop/dashboard-coupons",
  },
  {
    id: 10,
    name: "Refunds",
    icon: HiOutlineReceiptRefund,
    path: "/shop/dashboard-refunds",
  },
  {
    id: 11,
    name: "Settings",
    icon: CiSettings,
    path: "/shop/settings",
  },
];

const DashboardSidebar = ({ activeLink, toggleMenu, setToggleMenu }) => {
  const [active, setActive] = useState(activeLink);
  return (
    <>
      <div className="800px:block hidden w-full h-[100vh] bg-primary shadow-sm overflow-y-auto sticky top-0 left-0 z-10">
        {links.map(({ id, name, icon: Icon, path }) => (
          <div
            key={id}
            className={`w-full flex items-center p-4 ${
              active === id ? "border border-y-yellow-500" : ""
            }`}
          >
            <Link
              to={path}
              className="w-full flex items-center"
              onClick={() => setActive(id)}
            >
              <Icon size={30} color={active === id ? "yellow" : "white"} />
              <h5
                className={`pl-2 font-[400] 800px:block hidden ${
                  active === id ? "text-yellow-500" : "text-white"
                }`}
              >
                {name}
              </h5>
            </Link>
          </div>
        ))}
      </div>
      {/* mobile nav */}
      <AnimatePresence>
        {toggleMenu && (
          <motion.div
            initial={{ x: "-100%", opacity: 0 }}
            animate={{ x: 0, opacity: 1 }}
            exit={{ x: "-100%", opacity: 0 }}
            transition={{ duration: 0.5, ease: "easeInOut" }}
            className="800px:w-full h-[100vh] bg-primary shadow-sm overflow-y-auto absolute 800px:sticky 800px:top-0 left-0 z-50"
          >
            {links.map(({ id, name, icon: Icon, path }) => (
              <div
                key={id}
                className={`w-full flex items-center p-4 ${
                  active === id ? "border border-y-yellow-500" : ""
                }`}
              >
                <Link
                  to={path}
                  className="w-full flex items-center"
                  onClick={() => setActive(id)}
                >
                  <Icon size={30} color={active === id ? "yellow" : "white"} />
                  <h5
                    className={`pl-2 font-[400] 800px:block ${
                      active === id ? "text-yellow-500" : "text-white"
                    }`}
                  >
                    {name}
                  </h5>
                </Link>
              </div>
            ))}
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
};

export default DashboardSidebar;
