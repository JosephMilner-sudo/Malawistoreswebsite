import React, { useState } from "react";
import styles from "../../styles/styles";
import { Link } from "react-router-dom";
import Logo from "./../../assets/images/logo.png";
import { categoriesData } from "./../../static/data";
import {
  AiOutlineHeart,
  AiOutlineSearch,
  AiOutlineShoppingCart,
} from "react-icons/ai";
import { FaAngleRight } from "react-icons/fa";
import { BiMenu, BiMenuAltLeft } from "react-icons/bi";
import { IoIosArrowDown, IoIosArrowUp } from "react-icons/io";
import { CgClose } from "react-icons/cg";
import DropDown from "../DropDown";
import Navbar from "../Navbar";
import { useSelector } from "react-redux";
import { backendUrl } from "../../server";
import Cart from "../route/Cart";
import Wishlist from "../route/Wishlist";

const Header = ({ activeNavLink }) => {
  const [searchTerm, setSearchTerm] = useState("");
  const [searchData, setSearchData] = useState(null);
  const { cart } = useSelector((state) => state.cart);
  const { wishlist } = useSelector((state) => state.wishlist);
  const [active, setActive] = useState(false);
  const [dropDown, setDropDown] = useState(false);
  const { isAuthenticated, user } = useSelector((state) => state.user);
  const system = useSelector((state) => state.system);
  const shop = useSelector((state) => state.shop);
  const [openCart, setOpenCart] = useState(false);
  const [openWishlist, setOpenWishlist] = useState(false);
  const [open, setOpen] = useState(false);
  const { allProducts } = useSelector((state) => state.product);

  const handleSearchChange = (e) => {
    const term = e.target.value;
    setSearchTerm(term);

    const filteredData =
      allProducts &&
      allProducts.filter((product) => {
        return product?.name?.toLowerCase().includes(term?.toLowerCase());
      });
    setSearchData(filteredData);
  };

  const renderSearchItems = (item, index) => {
    return (
      <Link
        key={index}
        to={`/product/${item._id}`}
        onClick={() => {
          setSearchData(null);
        }}
      >
        <div className="w-full flex items-start py-3">
          <img
            src={backendUrl + "/" + item.images[0]}
            alt="product"
            className="w-[40px] h-[40px] mr-[10px] object-cover"
          />
          <h1 className="800px:text-md text-sm">
            {item?.name?.length > 70
              ? item.name?.slice(0, 70) + " ..."
              : item?.name}
          </h1>
        </div>
      </Link>
    );
  };

  window.addEventListener("scroll", () => {
    if (window.scrollY > 70) {
      setActive(true);
    } else {
      setActive(false);
    }
  });

  return (
    <div>
      <div className={`${styles.section} font-Poppins`}>
        {/* Top header */}
        <div className="hidden 800px:flex items-center justify-between h-[70px] py-4">
          {/* Logo */}
          <Link to="/">
            <img src={Logo} alt="Logo" className="w-32 h-16 object-contain" />
          </Link>

          {/* Search Box */}
          <div className="relative w-[50%]">
            <input
              type="text"
              value={searchTerm}
              onChange={handleSearchChange}
              placeholder="Search products..."
              className="w-full h-10 px-4 border-2 border-yellow-500 rounded-md focus:outline-none focus:ring-2 focus:ring-yellow-400"
            />
            <AiOutlineSearch
              size={22}
              className="absolute right-3 top-2.5 text-yellow-600"
            />
            {searchTerm && searchData?.length > 0 && (
              <div className="absolute w-full z-10 mt-1 bg-white shadow-md max-h-[300px] overflow-y-auto p-4 rounded-md">
                {searchData.map((item, index) =>
                  renderSearchItems(item, index)
                )}
              </div>
            )}
          </div>

          {/* admin Button */}
          <Link to="/login-system" className={`${styles.button}`}>
            <h1 className="text-white uppercase font-medium flex items-center gap-2">
              {system?.isAuthenticated ? "Admin Dashboard" : "Admin"}
              <FaAngleRight size={20} />
            </h1>
          </Link>

          {/* Seller Button */}
          <Link to="/login-shop" className={`${styles.button}`}>
            <h1 className="text-white uppercase font-medium flex items-center gap-2">
              {shop?.isAuthenticated ? "Dashboard" : "I am a Seller"}
              <FaAngleRight size={20} />
            </h1>
          </Link>
        </div>
      </div>

      {/* Navigation Bar */}
      <div
        className={`transition-all duration-300 ${
          active ? "shadow-sm fixed top-0 left-0 z-10" : ""
        } hidden 800px:flex items-center justify-between w-full bg-primary h-[70px]`}
      >
        <div
          className={`${styles.section} flex items-center justify-between w-full`}
        >
          {/* Categories Dropdown */}
          <div className="relative hidden 1000px:block w-[270px] mt-2">
            <div className="flex items-center justify-between h-[60px] px-5 bg-white border border-gray-200 rounded-md shadow-sm hover:shadow-md transition cursor-pointer">
              <div className="flex items-center gap-3">
                <BiMenuAltLeft size={26} className="text-yellow-600" />
                <button
                  onClick={() => setDropDown(!dropDown)}
                  className="text-gray-700 text-[15px] font-semibold tracking-wide focus:outline-none"
                >
                  Browse Categories
                </button>
              </div>
              {dropDown ? (
                <IoIosArrowUp
                  size={22}
                  className="text-gray-600 transition"
                  onClick={() => setDropDown(false)}
                />
              ) : (
                <IoIosArrowDown
                  size={22}
                  className="text-gray-600 transition"
                  onClick={() => setDropDown(true)}
                />
              )}
            </div>

            {dropDown && (
              <DropDown
                categoriesData={categoriesData}
                setDropDown={setDropDown}
              />
            )}
          </div>

          {/* Main Navbar */}
          <Navbar activeNavLink={activeNavLink} />

          {/* Icons */}
          <div className="flex items-center gap-4">
            {/* Wishlist */}
            <div
              className="relative cursor-pointer"
              onClick={() => setOpenWishlist(true)}
            >
              <AiOutlineHeart size={26} className="text-white/80" />
              <span className="absolute -top-1 -right-1 w-4 h-4 bg-[#3bc177] text-white text-xs rounded-full flex items-center justify-center">
                {wishlist?.length}
              </span>
            </div>

            {/* Cart */}
            <div
              className="relative cursor-pointer"
              onClick={() => setOpenCart(true)}
            >
              <AiOutlineShoppingCart size={26} className="text-white/80" />
              <span className="absolute -top-1 -right-1 w-4 h-4 bg-[#3bc177] text-white text-xs rounded-full flex items-center justify-center">
                {cart?.length}
              </span>
            </div>

            {/* Profile */}
            <div className="relative cursor-pointer pr-2">
              {isAuthenticated ? (
                <Link to="/profile">
                  <img
                    src={`${backendUrl}/${user?.avatar}`}
                    alt="User"
                    className="w-10 h-10 rounded-full border-2 border-yellow-400 object-cover"
                  />
                </Link>
              ) : (
                <Link
                  to="/login"
                  className="text-white/80 px-4 py-1 border border-white/80 rounded bg-black/80 shadow-lg"
                >
                  Login
                </Link>
              )}
            </div>
          </div>
        </div>

        {/* Cart & Wishlist Drawers */}
        {openCart && <Cart setOpenCart={setOpenCart} />}
        {openWishlist && <Wishlist setOpenWishlist={setOpenWishlist} />}
      </div>

      {/* Mobile Header */}
      <div className="800px:hidden flex h-[70px] bg-primary border-b border-gray-200 w-full z-50 shadow-md items-center justify-between px-4">
        {openCart && <Cart setOpenCart={setOpenCart} />}
        {openWishlist && <Wishlist setOpenWishlist={setOpenWishlist} />}

        {/* Menu Icon */}
        <BiMenu
          onClick={() => setOpen(true)}
          size={30}
          className="cursor-pointer text-white"
        />

        {/* Logo */}
        <Link to={"/"}>
          <img
            src={Logo}
            alt="Logo"
            className="w-[55px] h-[45px] object-contain"
          />
        </Link>

        {/* Cart Icon */}
        <div
          className="relative cursor-pointer"
          onClick={() => setOpenCart(true)}
        >
          <AiOutlineShoppingCart size={26} className="text-white opacity-90" />
          <span className="absolute -top-1 -right-1 rounded-full bg-green-500 w-4 h-4 text-white text-[10px] flex items-center justify-center font-semibold">
            {cart?.length}
          </span>
        </div>

        {/* Sidebar Menu */}
        {open && (
          <div className="fixed inset-0 bg-black/50 z-40">
            <div className="w-[70%] bg-white h-full fixed top-0 left-0 z-50 shadow-lg flex flex-col justify-between">
              {/* Top Section */}
              <div>
                <div className="flex justify-between items-center p-4 border-b border-gray-100">
                  <div
                    className="relative cursor-pointer"
                    onClick={() => {
                      setOpenWishlist(true);
                      setOpen(false);
                    }}
                  >
                    <AiOutlineHeart size={28} className="text-gray-700" />
                    <span className="absolute -top-1 -right-1 rounded-full bg-green-500 w-4 h-4 text-white text-[10px] flex items-center justify-center font-semibold">
                      {wishlist?.length}
                    </span>
                  </div>
                  <CgClose
                    size={30}
                    className="text-red-500 cursor-pointer"
                    onClick={() => setOpen(false)}
                  />
                </div>

                {/* Search Input */}
                <div className="px-4 mt-4 relative">
                  <input
                    type="text"
                    className={`${styles.input}`}
                    value={searchTerm}
                    placeholder="Search products"
                    onChange={handleSearchChange}
                  />
                  {searchTerm && searchData?.length > 0 && (
                    <div className="absolute z-50 bg-white border mt-1 w-full shadow-md max-h-[200px] overflow-y-auto">
                      {searchData.map((item, index) =>
                        renderSearchItems(item, index)
                      )}
                    </div>
                  )}
                </div>

                {/* Navigation Links */}
                <Navbar activeNavLink={activeNavLink} />

                {/* admin Button */}
                <div className="px-4 mt-6">
                  <Link to={"/login-system"} className={`${styles.button}`}>
                    <h1 className="text-white flex items-center justify-center gap-2 font-medium uppercase text-sm">
                      {system?.isAuthenticated ? "Admin Dashboard" : "Admin"}
                      <FaAngleRight size={18} />
                    </h1>
                  </Link>
                </div>

                {/* Seller Button */}
                <div className="px-4 mt-6">
                  <Link to={"/login-shop"} className={`${styles.button}`}>
                    <h1 className="text-white flex items-center justify-center gap-2 font-medium uppercase text-sm">
                      {shop?.isAuthenticated ? "Dashboard" : "I am a Seller"}
                      <FaAngleRight size={18} />
                    </h1>
                  </Link>
                </div>
              </div>

              {/* Auth Section */}
              <div className="px-4 pb-6">
                {!isAuthenticated ? (
                  <div>
                    <h4 className="text-sm py-2 text-center font-semibold">
                      Customer
                    </h4>
                    <div className="flex justify-between gap-3">
                      <Link
                        to={"/login"}
                        className="flex-1 py-2 border rounded-md border-primary text-primary text-sm shadow-sm text-center"
                      >
                        Login
                      </Link>
                      <Link
                        to={"/sign-up"}
                        className="flex-1 py-2 border rounded-md border-primary text-primary text-sm shadow-sm text-center"
                      >
                        Sign Up
                      </Link>
                    </div>
                  </div>
                ) : (
                  <Link to="/profile" className="flex items-center gap-3">
                    <img
                      src={`${backendUrl}/${user?.avatar}`}
                      alt="Profile"
                      className="w-[50px] h-[50px] rounded-full border-2 border-yellow-400 object-cover"
                    />
                    <span className="text-gray-800 text-sm italic font-light">
                      {user?.name}
                    </span>
                  </Link>
                )}
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default Header;
