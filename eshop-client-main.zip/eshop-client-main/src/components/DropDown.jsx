import React from "react";
import { useNavigate } from "react-router-dom";

const DropDown = ({ categoriesData, setDropDown }) => {
  const navigate = useNavigate();

  const handleSubmit = (item) => {
    navigate(`/products?category=${item.title}`);
    setDropDown(false);
    window.location.reload();
  };

  return (
    <div className="w-[270px] absolute top-full left-0 z-30 bg-white border border-gray-200 rounded-b-lg shadow-lg">
      {categoriesData?.map((item, index) => (
        <div
          key={index}
          onClick={() => handleSubmit(item)}
          className="flex items-center gap-3 px-4 py-3 hover:bg-gray-100 cursor-pointer transition-all duration-200 ease-in-out"
        >
          <img
            src={item.image_Url}
            alt={item.title}
            className="w-7 h-7 object-cover rounded-md"
          />
          <span className="text-sm font-medium text-gray-800 select-none">
            {item.title}
          </span>
        </div>
      ))}
    </div>
  );
};

export default DropDown;
