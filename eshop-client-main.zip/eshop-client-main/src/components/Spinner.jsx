import React from "react";
import { ClipLoader } from "react-spinners";

const Spinner = () => {
  return (
    <div className="w-full h-max flex items-center py-10 justify-center">
      <ClipLoader size={100} color="blue" className="w-full self-center" />
    </div>
  );
};

export default Spinner;
