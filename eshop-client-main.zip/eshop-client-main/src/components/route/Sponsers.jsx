import React from "react";
import styles from "../../styles/styles";

const Sponsors = () => {
  const sponsorImages = [
    "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSEsB9diPnS64NXe6yc54f5Gqxn5x6-SYVZ_Q&s",
    "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQuND6VXlRwxFSh9vmZyvIsGaPKD_rYz6cb_A&s",
    "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRz368D6gorCMvHtXRPvdbOmxz2jWgIFMIxLA&s",
    "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcT4SNKX6vg_l1Vcp9ofsI4DBj0xjyQ2cAWYQg&sg",
    "https://pbs.twimg.com/profile_images/1544672242914803716/I9Khm0xj_400x400.jpg",
  ];

  return (
    <div
      className={`${styles.section} sm:block bg-white py-10 px-5 mb-12 cursor-pointer rounded-xl`}
    >
      <div className="w-full px-2 py-4">
        <h1 className="text-xl font-bold text-center">Our Partners</h1>
      </div>

      <div className="flex justify-around flex-wrap w-full gap-4">
        {sponsorImages.map((src, index) => (
          <div key={index} className="flex items-center justify-center">
            <img
              src={src}
              alt={`Sponsor ${index + 1}`}
              className="w-[150px] object-contain"
            />
          </div>
        ))}
      </div>
    </div>
  );
};

export default Sponsors;
