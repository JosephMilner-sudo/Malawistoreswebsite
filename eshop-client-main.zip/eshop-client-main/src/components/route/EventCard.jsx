import React from "react";
import styles from "../../styles/styles";
import { Link } from "react-router-dom";
import CountDown from "./CountDown";
import { backendUrl } from "../../server";
import { toKwacha } from "../../utils/toKwacha";
import { useDispatch, useSelector } from "react-redux";
import { toast } from "react-toastify";
import { addTocart } from "../../redux/actions/cart";

const EventCard = ({ active, data }) => {
  const dispatch = useDispatch();
  const { cart } = useSelector((state) => state.cart);

  const addToCartHandler = () => {
    const itemExist = cart?.find((i) => i._id === data._id);

    if (itemExist) {
      toast.error("Item already exists in cart");
    } else if (data?.stock < 1) {
      toast.error("Product stock is limited");
    } else {
      const cartData = { ...data, quantity: 1 };
      dispatch(addTocart(cartData));
      toast.success("Item added to cart successfully");
    }
  };

  return (
    <div
      className={`w-full bg-white rounded-lg shadow-md overflow-hidden ${
        active ? "" : "mb-12"
      } lg:flex p-4 gap-6`}
    >
      {/* Image Section */}
      <div className="w-full lg:w-[50%] flex justify-center">
        <img
          src={`${backendUrl}/${data?.images?.[0]}`}
          alt={data?.name}
          className="object-cover w-full h-[300px] lg:h-[400px] rounded-md"
        />
      </div>

      {/* Info Section */}
      <div className="w-full lg:w-[50%] flex flex-col justify-between">
        <div>
          <h2 className={`${styles.productTitle} text-2xl font-semibold mb-2`}>
            {data?.name}
          </h2>
          <p className="text-gray-700 text-sm mb-4">
            {data?.description?.length > 300
              ? data.description?.slice(0, 300) + " ..."
              : data.description}
          </p>

          {/* Price Info */}
          <div className="flex items-center justify-between mb-2">
            <div className="flex items-center">
              <span className="text-lg font-medium text-red-500 line-through mr-3">
                {toKwacha(data?.originalPrice)}
              </span>
              <span className="text-xl font-bold text-gray-900">
                {toKwacha(data?.discountPrice)}
              </span>
            </div>
            <span className="text-green-600 text-sm font-medium">
              {data?.soldOut} sold
            </span>
          </div>

          <CountDown data={data} />
        </div>

        {/* Action Buttons */}
        <div className="mt-6 flex gap-4">
          <Link to={`/product/${data?._id}?isEvent=true`} className="w-fit">
            <button className={`${styles.button} text-white`}>
              See Details
            </button>
          </Link>
          <button
            onClick={addToCartHandler}
            className={`${styles.button} text-white bg-green-600 hover:bg-green-700`}
          >
            Add to Cart
          </button>
        </div>
      </div>
    </div>
  );
};

export default EventCard;
