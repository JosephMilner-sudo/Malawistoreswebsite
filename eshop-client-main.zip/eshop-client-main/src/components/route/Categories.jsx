import React from "react";
import { useNavigate } from "react-router-dom";
import { brandingData, categoriesData } from "../../static/data";
import styles from "../../styles/styles";

const Categories = () => {
  const navigate = useNavigate();

  return (
    <>
      {/* Categories Grid */}
      <div
        className={`${styles.section} bg-white p-6 rounded-xl mb-12 font-Poppins 800px:mt-[-170px] mt-[-230px] relative`}
        id="categories"
      >
        <h2 className="text-lg 800px:text-2xl font-semibold text-gray-800 mb-6 border-b pb-2">
          Shop by Category
        </h2>

        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-6">
          {categoriesData?.map((i) => {
            const handleSubmit = () => {
              navigate(`/products?category=${i.title}`);
            };

            return (
              <div
                key={`category-${i.id}`}
                onClick={handleSubmit}
                className="shadow-md hover:shadow-md rounded-lg p-4 flex flex-col items-center justify-center text-center cursor-pointer transition duration-300 hover:scale-[1.03]"
              >
                <img
                  src={i?.image_Url}
                  alt={i?.title || "Category"}
                  className="w-20 h-20 object-cover mb-3 rounded-md"
                />
                <h5 className="text-sm sm:text-base font-medium text-gray-700">
                  {i?.title}
                </h5>
              </div>
            );
          })}
        </div>
      </div>

      {/* Branding Section */}
      <div
        className={`${styles.section} hidden sm:block font-Poppins relative`}
      >
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 my-12 p-6 bg-white rounded-xl shadow-md">
          {brandingData?.map((i, index) => (
            <div
              key={`branding-${index}`}
              className="flex items-start gap-4 bg-yellow-50 p-4 rounded-md hover:shadow transition duration-300"
            >
              <div className="text-blue-600 text-3xl">{i?.icon}</div>
              <div>
                <h3 className="font-semibold text-base text-gray-800">
                  {i?.title}
                </h3>
                <p className="text-sm text-gray-600">{i?.Description}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </>
  );
};

export default Categories;
