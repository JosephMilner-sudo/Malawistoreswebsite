import React from "react";
import styles from "../../styles/styles";
import { useSelector } from "react-redux";
import { ProductCard } from "./../";

const FeaturedProducts = () => {
  const { allProducts } = useSelector((state) => state.product);

  return (
    <div className={`${styles.section} py-10`}>
      <div className="mb-6">
        <h2 className="800px:text-2xl text-lg font-semibold text-gray-800">
          Featured Products
        </h2>
        <p className="text-sm text-gray-500">Handpicked just for you</p>
      </div>

      {allProducts && allProducts.length > 0 ? (
        <div className="grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-4 xl:grid-cols-5">
          {allProducts.map((product, index) => (
            <ProductCard data={product} key={index} />
          ))}
        </div>
      ) : (
        <div className="flex justify-center items-center h-40">
          <p className="text-gray-600 text-sm">
            No featured products available
          </p>
        </div>
      )}
    </div>
  );
};

export default FeaturedProducts;
