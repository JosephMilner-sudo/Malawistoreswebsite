import React from "react";
import { RxCross1 } from "react-icons/rx";
import { BiCartAdd, BiHeart, BiTrashAlt } from "react-icons/bi";
import { useDispatch, useSelector } from "react-redux";
import { removeFromList } from "../../redux/actions/wishlist";
import { addTocart } from "../../redux/actions/cart";
import { backendUrl } from "../../server";
import { toKwacha } from "../../utils/toKwacha";
import { toast } from "react-toastify";

const Wishlist = ({ setOpenWishlist }) => {
  const { wishlist } = useSelector((state) => state.wishlist);
  const dispatch = useDispatch();

  const removeFromWishlistHandler = (item) => {
    dispatch(removeFromList(item));
  };

  return (
    <div className="fixed top-0 left-0 w-full h-screen bg-black/40 z-[9999]">
      <div className="fixed top-0 right-0 w-[80%] md:w-[30%] lg:w-[25%] h-full bg-white shadow-md flex flex-col">
        {/* Header */}
        <div className="flex items-center justify-between px-4 py-3 border-b">
          <div className="flex items-center gap-2">
            <BiHeart size={22} className="text-pink-600" />
            <h2 className="text-[18px] font-semibold text-gray-800">
              Wishlist ({wishlist.length})
            </h2>
          </div>
          <RxCross1
            size={22}
            onClick={() => setOpenWishlist(false)}
            className="cursor-pointer text-gray-600 hover:text-red-500 transition"
          />
        </div>

        {/* Body */}
        <div className="flex-1 overflow-y-auto">
          {wishlist.length === 0 ? (
            <div className="flex items-center justify-center h-full text-gray-500 font-medium">
              Wishlist is empty!
            </div>
          ) : (
            wishlist.map((item) => (
              <WishlistItem
                key={item._id}
                data={item}
                removeFromWishlistHandler={removeFromWishlistHandler}
                setOpenWishlist={setOpenWishlist}
              />
            ))
          )}
        </div>
      </div>
    </div>
  );
};

const WishlistItem = ({ data, removeFromWishlistHandler, setOpenWishlist }) => {
  const dispatch = useDispatch();
  const { cart } = useSelector((state) => state.cart);

  const price = data?.discountPrice || data?.originalPrice;

  const addToCartHandler = () => {
    const exists = cart?.find((i) => i._id === data._id);
    if (exists) {
      toast.error("Item already in cart");
    } else {
      dispatch(addTocart({ ...data, quantity: 1 }));
      removeFromWishlistHandler(data);
      setOpenWishlist(false);
      toast.success("Item added to cart");
    }
  };

  return (
    <div className="flex items-center justify-between px-4 py-3 border-b group hover:bg-gray-50 transition">
      {/* Remove Icon */}
      <BiTrashAlt
        size={20}
        title="Remove from wishlist"
        className="text-red-500 cursor-pointer hover:scale-110 transition"
        onClick={() => removeFromWishlistHandler(data)}
      />

      {/* Product Image */}
      <img
        src={backendUrl + "/" + data?.images[0]}
        alt={data?.name}
        className="w-[70px] h-[70px] object-cover rounded-md mx-3"
      />

      {/* Product Info */}
      <div className="flex flex-col flex-1">
        <span className="text-[14px] text-gray-800 font-medium leading-5">
          {data?.name?.length > 50
            ? data?.name?.slice(0, 50) + "..."
            : data?.name}
        </span>
        <span className="text-red-600 font-semibold text-[15px] mt-1">
          {toKwacha(price)}
        </span>
      </div>

      {/* Add to Cart */}
      <BiCartAdd
        size={24}
        title="Add to cart"
        onClick={addToCartHandler}
        className="cursor-pointer text-green-600 hover:scale-110 transition ml-2"
      />
    </div>
  );
};

export default Wishlist;
