import React, { useState } from "react";
import { BsBag } from "react-icons/bs";
import { RxCross1 } from "react-icons/rx";
import { Link } from "react-router-dom";
import { HiOutlineMinus, HiPlus } from "react-icons/hi";
import { useDispatch, useSelector } from "react-redux";
import { backendUrl } from "../../server";
import { toKwacha } from "../../utils/toKwacha";
import { addTocart, removeFromCart } from "../../redux/actions/cart";
import { toast } from "react-toastify";
import { BiTrash } from "react-icons/bi";

const Cart = ({ setOpenCart }) => {
  const { cart } = useSelector((state) => state.cart);
  const dispatch = useDispatch();

  const removeFromCarthandler = (data) => {
    dispatch(removeFromCart(data));
  };

  const handleQuantityChange = (data) => {
    dispatch(addTocart(data));
  };

  const calculateTotal = () => {
    return cart.reduce(
      (acc, item) =>
        acc + item.quantity * (item.discountPrice || item.originalPrice),
      0
    );
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-40 z-50 font-Roboto">
      <div className="fixed right-0 top-0 h-full w-full sm:w-[80%] md:w-[60%] lg:w-[30%] bg-white flex flex-col shadow-xl overflow-hidden">
        {/* Header */}
        <div className="flex justify-between items-center px-4 py-4 border-b">
          <div className="flex items-center gap-2">
            <BsBag size={24} />
            <h5 className="text-lg font-semibold">{cart?.length} item(s)</h5>
          </div>
          <RxCross1
            size={24}
            className="cursor-pointer"
            onClick={() => setOpenCart(false)}
          />
        </div>

        {/* Content */}
        {cart?.length === 0 ? (
          <div className="flex flex-1 items-center justify-center">
            <h5 className="text-center text-gray-600">Your cart is empty!</h5>
          </div>
        ) : (
          <>
            <div className="flex-1 overflow-y-auto px-4 py-2">
              {cart.map((item) => (
                <CartSingle
                  key={item.id}
                  data={item}
                  handleQuantityChange={handleQuantityChange}
                  removeFromCarthandler={removeFromCarthandler}
                />
              ))}
            </div>

            {/* Checkout Section */}
            <div className="px-4 py-3 border-t">
              <div className="flex justify-between text-base font-semibold mb-3">
                <h3>Subtotal:</h3>
                <h3>{toKwacha(calculateTotal())}</h3>
              </div>
              <Link to="/checkout">
                <div className="bg-red-600 text-white text-center py-3 rounded-md hover:bg-red-700 transition duration-300">
                  Checkout Now {toKwacha(calculateTotal())}
                </div>
              </Link>
            </div>
          </>
        )}
      </div>
    </div>
  );
};

const CartSingle = ({ data, handleQuantityChange, removeFromCarthandler }) => {
  const [value, setValue] = useState(data?.quantity);
  const totalPrice = (data?.discountPrice || data?.originalPrice) * value;

  const increment = () => {
    if (data?.stock <= value) {
      toast.error("Product stock is limited");
    } else {
      const newQuantity = value + 1;
      setValue(newQuantity);
      handleQuantityChange({ ...data, quantity: newQuantity });
    }
  };

  const decrement = () => {
    if (value > 1) {
      const newQuantity = value - 1;
      setValue(newQuantity);
      handleQuantityChange({ ...data, quantity: newQuantity });
    }
  };

  return (
    <div className="border-b py-4 flex items-start gap-4">
      {/* Quantity */}
      <div className="flex flex-col items-center">
        <button
          className="bg-green-700 w-6 h-6 rounded-full flex items-center justify-center text-white"
          onClick={increment}
        >
          <HiPlus size={16} />
        </button>
        <span className="my-1">{value}</span>
        <button
          className={`w-6 h-6 rounded-full flex items-center justify-center ${
            value > 1
              ? "bg-red-600 text-white"
              : "bg-gray-300 text-gray-500 cursor-not-allowed"
          }`}
          onClick={decrement}
          disabled={value === 1}
        >
          <HiOutlineMinus size={14} />
        </button>
      </div>

      {/* Image */}
      <img
        src={backendUrl + "/" + data?.images[0]}
        alt={data?.name}
        className="w-20 h-20 object-cover rounded-md"
      />

      {/* Details */}
      <div className="flex-1">
        <Link
          to={data.startDate ? `/product/${data._id}?isEvent=true` : `/product/${data._id}`}
          className="text-sm font-medium text-gray-800 hover:underline block"
        >
          {data?.name?.length > 70
            ? data?.name.slice(0, 70) + "..."
            : data?.name}
        </Link>
        <p className="text-sm text-gray-500 mt-1">
          {`${(data?.discountPrice || data?.originalPrice).toFixed(
            2
          )} × ${value}`}
        </p>
        <p className="text-red-600 font-semibold text-sm mt-1">
          {toKwacha(totalPrice)}
        </p>
      </div>

      {/* Remove */}
      <BiTrash
        size={22}
        className="text-red-500 cursor-pointer ml-2"
        onClick={() => removeFromCarthandler(data)}
      />
    </div>
  );
};

export default Cart;
