import React from "react";
import styles from "../../styles/styles";
import { Link } from "react-router-dom";

const Hero = () => {
  return (
    <div
      className={`relative font-Poppins min-h-[65vh] 800px:min-h-[70vh] w-full bg-no-repeat pt-[30px]`}
      style={{
        backgroundImage:
          "url(https://themes.rslahmed.dev/rafcart/assets/images/banner-3.jpg)",
        backgroundSize: "cover",
        backgroundPosition: "center",
      }}
    >
      <div className={`800px:pl-[80px] pl-[20px] w-[90%] 800px:w-[55%]`}>
        <h1
          className={`text-[35px] leading-[1.2] 800px:text-[60px] text-[#3d3a3a] font-[600] capitalize`}
        >
          Malawi's <span className="text-red-500 font-extrabold">Online</span>{" "}
          <span className="text-green-600 animate-pulse">Market Place</span>
        </h1>
        <p className="pt-5 800px:block hidden text-[16px] font-[Poppins] font-[400] text-[#000000ba]">
          Discover the ultimate shopping experience with our app—designed to
          save you time, offer unbeatable deals, and bring your favorite
          products right to your doorstep. Shop smarter, faster, and with ease
          like never before.
        </p>
        <Link to="/products" className="inline-block">
          <div className={`${styles.button} mt-5`}>
            <span className="text-[#fff] font-[Poppins] text-[18px]">
              Shop Now
            </span>
          </div>
        </Link>
      </div>
    </div>
  );
};

export default Hero;
