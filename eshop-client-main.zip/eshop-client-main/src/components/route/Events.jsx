import React from "react";
import EventCard from "./EventCard";
import styles from "../../styles/styles";
import { useSelector } from "react-redux";

const Events = () => {
  const { allEvents, loading } = useSelector((state) => state.event);
  return (
    <div>
      <h1 className="pl-4 text-xl font-semibold text-gray-600">Popular Events</h1>
      <p className="pl-4 pb-2 text-sm text-gray-600">Great offers for you</p>
      {!loading && allEvents && allEvents?.length > 0 ? (
        allEvents?.map((item, index) => {
          return <EventCard key={index} active={true} data={item} />;
        })
      ) : (
        <div className="w-full h-[50vh] flex items-center justify-center">
          <h4 className="text-lg">:No Events Found</h4>
        </div>
      )}
    </div>
  );
};

export default Events;
