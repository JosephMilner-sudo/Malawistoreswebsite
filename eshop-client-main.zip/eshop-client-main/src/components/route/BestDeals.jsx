import React, { useEffect, useState } from "react";
import styles from "../../styles/styles";
import { useSelector } from "react-redux";
import { ProductCard } from "./../";

const BestDeals = () => {
  const [data, setData] = useState(null);
  const { allProducts } = useSelector((state) => state.product);

  useEffect(() => {
    if (allProducts) {
      const sortedData = [...allProducts].sort(
        (a, b) => b.soldOut - a.soldOut
      );
      const firstFive =
        sortedData.length > 5 ? sortedData.slice(0, 5) : sortedData;
      setData(firstFive);
    }
  }, [allProducts]);

  return (
    <div className={`${styles.section} py-10`}>
      <div className="mb-6">
        <h2 className="800px:text-2xl text-lg font-semibold text-gray-800">Best Deals</h2>
        <p className="text-sm text-gray-500">Top-selling products right now</p>
      </div>

      {data && data.length > 0 ? (
        <div className="grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-4 xl:grid-cols-5">
          {data.map((item, index) => (
            <ProductCard data={item} key={index} />
          ))}
        </div>
      ) : (
        <div className="flex justify-center items-center h-40">
          <p className="text-gray-600 text-sm">No products available</p>
        </div>
      )}
    </div>
  );
};

export default BestDeals;
