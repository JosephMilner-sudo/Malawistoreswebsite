import React, { useEffect, useState } from "react";
import styles from "../../styles/styles";
import { useSelector } from "react-redux";
import { ProductCard } from "./../"

const RelatedProducts = ({ data, eventTag }) => {
  const [products, setProducts] = useState(null);
  const { allProducts } = useSelector((state) => state.product);
  const { allEvents } = useSelector((state) => state.event);

  useEffect(() => {
    if (eventTag) {
      if (data) {
        const relatedProd =
          allEvents &&
          allEvents.filter((item) => item.category === data.category);
        setProducts(relatedProd);
      }
    } else {
      if (data) {
        const relatedProd =
          allProducts &&
          allProducts.filter((item) => item.category === data.category);
        setProducts(relatedProd);
      }
    }
  }, [data]);

  if (!data) {
    return null;
  }

  return (
    <div className=" bg-gray-100 px-3 py-2 rounded 800px:px-10 800px:mx-3 mx-1  ">
      <div className={`p-4 ${styles.section}`}>
        <h2
          className={`${styles.heading} border-b mb-5 font-[500] text-[16pt]`}
        >
          Related Products
        </h2>

        <div className="mt-3 w-full">
          <div className="grid grid-cols-1 gap-[20px] md:grid-cols-2 md:gap-[25px] lg:grid-cols-4 lg:gap-[25px] xl:grid-cols-5 xl:gap-[30px] mb-12 border-0">
            {products && products.length !== 0 && (
              <>
                {products &&
                  products.map((item, index) => (
                    <ProductCard data={item} key={index} isEvent={eventTag} />
                  ))}
              </>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default RelatedProducts;
