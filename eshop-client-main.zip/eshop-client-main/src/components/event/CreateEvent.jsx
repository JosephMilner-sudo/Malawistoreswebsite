import React, { useEffect, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { useNavigate } from "react-router-dom";
import styles from "../../styles/styles";
import { categoriesData } from "../../static/data";
import { CgAdd } from "react-icons/cg";
import { toast } from "react-toastify";
import { MdDelete } from "react-icons/md";
import { createEvent } from "../../redux/actions/event";

const CreateEvent = () => {
  const { success, error } = useSelector((state) => state.event);
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const [errors, setErrors] = useState({});
  const MAX_IMAGES = 5; // Set a limit on the number of images allowed
  const ALLOWED_FILE_TYPES = [
    "image/jpeg",
    "image/png",
    "image/gif",
    "image/webp",
  ]; // Allowed file type
  const formDataDefaults = {
    name: "",
    description: "",
    category: "",
    tags: "",
    originalPrice: "",
    discountPrice: "",
    stock: "",
    images: [],
    startDate: null,
    endDate: null,
  };
  const [formData, setFormData] = useState(formDataDefaults);

  useEffect(() => {
    if (error) {
      toast.error(error);
    }
    if (success) {
      toast.success("Event added Successfully");
      setFormData(formDataDefaults);

      // Delay clearing state to allow toast to show
      setTimeout(() => {
        dispatch({ type: "clearState" });
        navigate("/shop/dashboard");
      }, 3000);
    }
  }, [error, success]);

  const validate = () => {
    let newErrors = {};

    if (!formData.name) newErrors.name = "Product name is required.";
    if (!formData.description)
      newErrors.description = "Description is required.";
    if (!formData.category) newErrors.category = "Category is required.";

    if (
      !formData.originalPrice ||
      isNaN(formData.originalPrice.replace(/,/g, ""))
    ) {
      newErrors.originalPrice = "Valid price is required.";
    }

    if (formData.images.length < 1) {
      newErrors.images = "At least one image is required.";
    } else {
      // Check for valid image types
      if (
        formData.images.some(
          (file) =>
            !["image/png", "image/jpeg", "image/jpg", "image/webp"].includes(
              file.type
            )
        )
      ) {
        newErrors.images = "Only PNG, JPEG, WEBP, and JPG formats are allowed.";
      }

      // Check for maximum file size (3MB)
      if (formData.images.some((file) => file.size > 3 * 1024 * 1024)) {
        newErrors.images = "Each image must not exceed 3MB.";
      }
    }

    if (!formData.startDate)
      newErrors.startDate = "Event start date is required.";
    if (!formData.endDate) newErrors.endDate = "Event end date is required.";

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleChange = (e) => {
    const { name, value } = e.target;
    let formattedValue = value;
    let newErrors = { ...errors }; // Create a copy of the current errors to modify

    if (name === "originalPrice" || name === "discountPrice") {
      // Remove non-numeric characters and reformat the price
      formattedValue = value
        .replace(/\D/g, "")
        .replace(/\B(?=(\d{3})+(?!\d))/g, ",");
    } else if (name === "stock") {
      // Remove non-numeric characters and ensure it's a positive integer
      formattedValue = value.replace(/\D/g, ""); // Remove anything that's not a number

      // Check if the stock is a positive integer
      if (formattedValue === "" || parseInt(formattedValue, 10) <= 0) {
        newErrors[name] = "Stock must be a positive integer greater than zero.";
      } else {
        delete newErrors[name]; // Remove error if it's valid
      }
    } else if (name === "startDate") {
      const startDate = new Date(value);
      const minEndDate = new Date(
        startDate.getTime() + 3 * 24 * 60 * 60 * 1000
      );
      formattedValue = startDate;
      setFormData((prev) => ({ ...prev, endDate: null }));
      document.getElementById("endDate").min = minEndDate
        .toISOString()
        .slice(0, 10);
    } else if (name === "endDate") {
      const endDate = new Date(value);
      formattedValue = endDate;
    }

    // Update the form data and errors state
    setFormData((prev) => ({ ...prev, [name]: formattedValue }));
    setErrors(newErrors);
  };

  const today = new Date().toISOString().slice(0, 10);

  const minEndDate = formData.startDate
    ? new Date(formData.startDate.getTime() + 3 * 24 * 60 * 60 * 1000)
        .toISOString()
        .slice(0, 10)
    : "";

  const handleImageChange = (e) => {
    e.preventDefault();
    let files = Array.from(e.target.files);

    // Filter out files that don't match allowed types
    const validFiles = files.filter((file) =>
      ALLOWED_FILE_TYPES.includes(file.type)
    );

    if (validFiles.length !== files.length) {
      toast.error(
        "Some files are not valid image types (only JPG, PNG, GIF and WEBP are allowed)."
      );
    }

    // Filter out any duplicate files
    files = files.filter(
      (file) =>
        !formData.images.some((existingFile) => existingFile.name === file.name)
    );

    // Limit the number of files to the maximum allowed
    if (formData.images.length + files.length > MAX_IMAGES) {
      toast.error(`You can only upload up to ${MAX_IMAGES} images.`);
      return;
    }

    // Add valid files to the state
    setFormData((prev) => ({
      ...prev,
      images: [...prev.images, ...validFiles],
    }));
  };

  // Handle image removal
  const handleImageRemove = (index) => {
    setFormData((prev) => {
      const updatedImages = [...prev.images];
      updatedImages.splice(index, 1); // Remove the image at the specified index
      return { ...prev, images: updatedImages };
    });
  };

  const handleSubmit = (e) => {
    e.preventDefault();

    if (validate()) {
      // Remove commas from originalPrice and discountPrice
      const cleanedFormData = {
        ...formData,
        originalPrice: formData.originalPrice.replace(/,/g, ""), // Remove commas from originalPrice
        discountPrice: formData.discountPrice.replace(/,/g, ""), // Remove commas from discountPrice
      };

      const newFormData = new FormData();

      cleanedFormData.images.forEach((image) =>
        newFormData.append("images", image)
      );

      newFormData.append("name", cleanedFormData.name);
      newFormData.append("description", cleanedFormData.description);
      newFormData.append("category", cleanedFormData.category);
      newFormData.append("tags", cleanedFormData.tags);
      newFormData.append("originalPrice", cleanedFormData.originalPrice);
      newFormData.append("discountPrice", cleanedFormData.discountPrice);
      newFormData.append("stock", cleanedFormData.stock);
      newFormData.append("startDate", cleanedFormData.startDate.toISOString());
      newFormData.append("endDate", cleanedFormData.endDate.toISOString());

      dispatch(createEvent(newFormData));
    }
    console.log(errors);
  };

  return (
    <div className="w-[90%] bg-white h-[80vh] rounded-sm shadow-md px-3 overflow-y-auto font-Poppins">
      <div className="w-full flex items-center justify-center py-5 border-b border-yellow-400 sticky top-0 left-0 bg-white z-10">
        <h1 className="800px:text-xl text-lg font-[600]">Create Event</h1>
      </div>

      <form
        onSubmit={handleSubmit}
        className="flex flex-col w-full p-3 lg:gap-5 gap-4 mt-2 lg:grid grid-cols-2"
      >
        {/* Product Name */}
        <div className="w-full">
          <label htmlFor="name">
            Product name <span className="text-red-500">*</span>
          </label>
          <input
            type="text"
            id="name"
            name="name"
            className={`${styles.input} ${errors.name ? "border-red-500" : ""}`}
            value={formData.name}
            onChange={handleChange}
            placeholder="i.e. Lenovo laptop"
            required
          />
          {errors.name && <p className="text-red-500 text-sm">{errors.name}</p>}
        </div>

        {/* Description */}
        <div className="w-full">
          <label htmlFor="description">
            Description <span className="text-red-500">*</span>
          </label>
          <textarea
            id="description"
            name="description"
            className={`${styles.input} ${
              errors.description ? "border-red-500" : ""
            }`}
            value={formData.description}
            onChange={handleChange}
            placeholder="A brief description and specifications about your event product"
            cols={10}
            required
          />
          {errors.description && (
            <p className="text-red-500 text-sm">{errors.description}</p>
          )}
        </div>

        {/* Category */}
        <div className="w-full">
          <label htmlFor="category">
            Category <span className="text-red-500">*</span>
          </label>
          <select
            id="category"
            name="category"
            className={`${styles.input} ${
              errors.category ? "border-red-500" : ""
            }`}
            value={formData.category}
            onChange={handleChange}
            required
          >
            <option value="">Select product category</option>
            {categoriesData?.map((item) => (
              <option key={item?.id} value={item?.title}>
                {item?.title}
              </option>
            ))}
          </select>
          {errors.category && (
            <p className="text-red-500 text-sm">{errors.category}</p>
          )}
        </div>

        {/* Tags */}
        <div className="w-full">
          <label htmlFor="tags">Product tags</label>
          <input
            type="text"
            id="tags"
            name="tags"
            className={`${styles.input} ${
              Array.isArray(formData.tags) && formData.tags.length > 0
                ? "border-red-500"
                : ""
            }`}
            value={formData.tags}
            onChange={handleChange}
          />
        </div>

        {/* Original Price */}
        <div className="w-full relative">
          <label htmlFor="originalPrice">
            Original Price <span className="text-red-500">*</span>
          </label>
          <input
            type="text"
            id="originalPrice"
            name="originalPrice"
            className={`${styles.input} !pl-[42px] ${
              errors.originalPrice ? "border-red-500" : ""
            }`}
            value={formData.originalPrice}
            onChange={handleChange}
            required
          />
          <div className="absolute bottom-0 left-0 flex justify-center items-center bg-yellow-500 py-[5px] px-2 rounded-sm">
            <p className="text-white">MK</p>
          </div>
          {errors.originalPrice && (
            <p className="text-red-500 text-sm">{errors.originalPrice}</p>
          )}
        </div>

        <div className="w-full relative">
          <label htmlFor="discountPrice">Price with Discount</label>
          <input
            type="text"
            id="discountPrice"
            name="discountPrice"
            className={`${styles.input} !pl-[42px] ${
              errors.originalPrice ? "border-red-500" : ""
            }`}
            value={formData.discountPrice}
            onChange={handleChange}
          />
          <div className="absolute bottom-0 left-0 flex justify-center items-center bg-yellow-500 py-[5px] px-2 rounded-sm">
            <p className="text-white">MK</p>
          </div>
        </div>

        <div className="w-full relative">
          <label htmlFor="startDate">Start Date</label>
          <input
            type="date"
            name="startDate"
            id="start-date"
            value={
              formData.startDate
                ? formData.startDate.toISOString().slice(0, 10)
                : ""
            }
            min={today}
            placeholder="Enter your event product stock..."
            className={`${styles.input} ${
              errors.startDate ? "border-red-500" : ""
            }`}
            onChange={handleChange}
          />
          {errors.startDate && (
            <p className="text-red-500 text-sm">{errors.startDate}</p>
          )}
        </div>

        <div className="w-full relative">
          <label htmlFor="startDate">End Date</label>
          <input
            type="date"
            name="endDate"
            id="endDate"
            value={
              formData.endDate
                ? formData.endDate.toISOString().slice(0, 10)
                : ""
            }
            min={minEndDate}
            placeholder="Enter your event product end date..."
            className={`${styles.input} ${
              errors.endDate ? "border-red-500" : ""
            }`}
            onChange={handleChange}
          />
          {errors.endDate && (
            <p className="text-red-500 text-sm">{errors.endDate}</p>
          )}
        </div>

        {/* Stock */}
        <div className="w-full">
          <label htmlFor="stock">
            Product Stock <span className="text-red-500">*</span>
          </label>
          <input
            type="number"
            id="stock"
            required
            name="stock"
            className={`${styles.input} ${
              errors.stock ? "border-red-500" : ""
            }`}
            value={formData.stock}
            onChange={handleChange}
          />
          {errors.stock && (
            <p className="text-red-500 text-sm">{errors.stock}</p>
          )}
        </div>

        {/* Upload Images */}
        <div className="w-full">
          <label htmlFor="images">
            Upload Images <span className="text-red-500">*</span>
          </label>
          <div className="flex gap-1 items-center mt-1 overflow-x-auto">
            <label
              htmlFor="images"
              className="p-2 border-r-2 border-yellow-600 sticky left-0 z-10 bg-white rounded-r-md cursor-pointer"
            >
              <CgAdd
                size={34}
                title="Upload images"
                className="animate-pulse"
              />
            </label>
            <input
              type="file"
              id="images"
              name="images"
              className={`hidden ${
                Array.isArray(formData.images) && formData.images.length === 0
                  ? "border-red-500"
                  : ""
              }`}
              onChange={handleImageChange}
              multiple
            />
            {errors.images && (
              <p className="text-red-500 text-sm">{errors.images}</p>
            )}
            {formData.images?.map((item, index) => (
              <div key={index} className="relative">
                <img
                  src={URL.createObjectURL(item)}
                  alt="ProductImage"
                  className="w-[120px] h-[120px] object-cover border"
                />
                <button
                  type="button"
                  onClick={() => handleImageRemove(index)}
                  className="absolute top-0 right-0 bg-red-500 text-white p-1 rounded-full"
                >
                  <MdDelete />
                </button>
              </div>
            ))}
          </div>
        </div>

        {/* Submit Button */}
        <div className="w-full col-span-2">
          <button
            type="submit"
            className={`${styles.button} !w-full !text-white`}
          >
            Create
          </button>
        </div>
      </form>
    </div>
  );
};

export default CreateEvent;
