import React, { useEffect, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { deleteEvent, getAllEventsForShop } from "../../redux/actions/event";
import { ClipLoader } from "react-spinners";
import { Link } from "react-router-dom";
import { AiOutlineDelete } from "react-icons/ai";
import { CgEye } from "react-icons/cg";
import { toast } from "react-toastify";
import styles from "../../styles/styles";
import { toKwacha } from "../../utils/toKwacha";

const AllShopEvents = () => {
  const dispatch = useDispatch();
  const { events, loading, error } = useSelector((state) => state.event);
  const { shop } = useSelector((state) => state.shop);

  const [searchTerm, setSearchTerm] = useState("");
  const [currentPage, setCurrentPage] = useState(1);
  const rowsPerPage = 10;

  useEffect(() => {
    dispatch(getAllEventsForShop(shop?._id));
    if (error !== "Invalid shopId format") {
      toast.error(error);
    }
  }, [dispatch, shop?._id, error]);

  const handleDelete = (productId) => {
    dispatch(deleteEvent(productId));
  };

  const filteredEvents = events?.filter((item) =>
    item.name.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const totalPages = Math.ceil(filteredEvents?.length / rowsPerPage);
  const paginatedEvents = filteredEvents?.slice(
    (currentPage - 1) * rowsPerPage,
    currentPage * rowsPerPage
  );

  const handlePrevPage = () => {
    if (currentPage > 1) setCurrentPage((prev) => prev - 1);
  };

  const handleNextPage = () => {
    if (currentPage < totalPages) setCurrentPage((prev) => prev + 1);
  };

  if (loading) {
    return (
      <div className="w-full h-[80vh] flex items-center justify-center">
        <ClipLoader size={100} color="blue" />
      </div>
    );
  }

  return (
    <div className="bg-white w-full pt-1 mt-10 800px:px-8 px-2 shadow-sm">
      <div className="flex justify-between items-center mb-4">
        <h1 className="text-lg font-semibold">All Events</h1>
        <input
          type="text"
          placeholder="Search by name"
          value={searchTerm}
          onChange={(e) => {
            setSearchTerm(e.target.value);
            setCurrentPage(1); // reset to first page on new search
          }}
          className={`${styles.input} !w-[50%]`}
        />
      </div>

      <div className="overflow-x-auto">
        <table className="min-w-full bg-white border border-gray-100">
          <thead>
            <tr className="text-left text-sm font-medium text-gray-600">
              <th className="py-3 px-4 border">Product ID</th>
              <th className="py-3 px-4 border">Name</th>
              <th className="py-3 px-4 border text-right">Price</th>
              <th className="py-3 px-4 border text-right">In Stock</th>
              <th className="py-3 px-4 border text-right">Sold Out</th>
              <th className="py-3 px-4 border">Preview</th>
              <th className="py-3 px-4 border">Delete</th>
            </tr>
          </thead>
          <tbody>
            {paginatedEvents?.map((item) => (
              <tr key={item._id} className="text-sm text-gray-700">
                <td className="py-2 px-4 ">{item._id}</td>
                <td className="py-2 px-4 ">
                  {" "}
                  {item.name?.length > 50
                    ? item.name?.slice(0, 50) + " ..."
                    : item.name}
                </td>
                <td className="py-2 px-4  text-right">
                  {" "}
                  {toKwacha(item.originalPrice)}
                </td>
                <td className="py-2 px-4  text-right">{item.stock}</td>
                <td className="py-2 px-4 ">{item.soldOut}</td>
                <td className="py-2 px-4 ">
                  <Link to={`/product/${item._id}?isEvent=true`}>
                    <CgEye
                      size={20}
                      className="text-blue-600 hover:text-blue-800"
                    />
                  </Link>
                </td>
                <td className="py-2 px-4 ">
                  <button onClick={() => handleDelete(item._id)}>
                    <AiOutlineDelete
                      size={20}
                      className="text-red-600 hover:text-red-800"
                    />
                  </button>
                </td>
              </tr>
            ))}

            {paginatedEvents?.length === 0 && (
              <tr>
                <td colSpan="7" className="text-center py-4 text-gray-500">
                  No events found.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>

      {/* Pagination */}
      {filteredEvents?.length > rowsPerPage && (
        <div className="flex flex-wrap gap-2 justify-between items-center mt-4">
          <div className="flex gap-2">
            <button
              onClick={() => setCurrentPage(1)}
              className="px-4 py-2 bg-gray-200 text-sm rounded hover:bg-gray-300"
              disabled={currentPage === 1}
            >
              First
            </button>
            <button
              onClick={handlePrevPage}
              className="px-4 py-2 bg-gray-200 text-sm rounded hover:bg-gray-300"
              disabled={currentPage === 1}
            >
              Previous
            </button>
          </div>

          <span className="text-sm text-gray-700">
            Page {currentPage} of {totalPages}
          </span>

          <div className="flex gap-2">
            <button
              onClick={handleNextPage}
              className="px-4 py-2 bg-gray-200 text-sm rounded hover:bg-gray-300"
              disabled={currentPage === totalPages}
            >
              Next
            </button>
            <button
              onClick={() => setCurrentPage(totalPages)}
              className="px-4 py-2 bg-gray-200 text-sm rounded hover:bg-gray-300"
              disabled={currentPage === totalPages}
            >
              Last
            </button>
          </div>
        </div>
      )}
    </div>
  );
};

export default AllShopEvents;
