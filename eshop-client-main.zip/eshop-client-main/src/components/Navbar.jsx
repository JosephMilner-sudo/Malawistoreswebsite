import React from "react";
import { navItems } from "../static/data";
import { Link } from "react-router-dom";

const Navbar = ({ activeNavLink }) => {
  return (
    <div
      className={`flex 800px:items-center 800px:flex-row flex-col 800px:mt-0 mt-[20px] 800px:gap-0 gap-9 `}
    >
      {navItems &&
        navItems.map((item, index) => (
          <div className="flex" key={index}>
            <Link
              to={item.url}
              className={`${
                activeNavLink === index + 1
                  ? "800px:text-yellow-300 text-yellow-500 800px:text-lg text-sm"
                  : "800px:text-white 800px:text-lg text-sm"
              } px-6 text-lg font-medium cursor-pointer`}
            >
              {item.title}
            </Link>
          </div>
        ))}
    </div>
  );
};

export default Navbar;
