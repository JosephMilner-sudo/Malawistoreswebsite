import React from "react";
import { useShopFormContext } from "./../../hooks/useShopFormContext";
import styles from "./../../styles/styles";

const ContactDetailsStep = () => {
  const { formData, handleChange, errors, handleNext, handleBack } =
    useShopFormContext();

  return (
    <div className="w-full max-w-xl bg-white shadow-md mt-5">
      <div className="bg-primary text-white w-full px-5 py-3">
        <h2 className="text-xl font-bold">Shop Contact Details</h2>
      </div>

      <div className="p-6">
        {/* Input Fields Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
          {/* Email */}
          <div>
            <label className="block text-sm font-medium text-gray-700">
              Email <span className="text-red-500">*</span>
            </label>
            <input
              type="email"
              className={`${styles.input} focus:outline-none focus:ring-2 focus:ring-yellow-500`}
              value={formData.contactDetails.email}
              onChange={(e) =>
                handleChange("contactDetails", { email: e.target.value })
              }
              placeholder="Enter email"
            />
            {errors?.contactDetails?.email && (
              <p className="text-red-500 text-sm">{errors.contactDetails.email}</p>
            )}
          </div>

          {/* Phone */}
          <div>
            <label className="block text-sm font-medium text-gray-700">
              Phone <span className="text-red-500">*</span>
            </label>
            <input
              type="text"
              className={`${styles.input} focus:outline-none focus:ring-2 focus:ring-yellow-500`}
              value={formData.contactDetails.phone}
              onChange={(e) =>
                handleChange("contactDetails", { phone: e.target.value })
              }
              placeholder="Enter phone number"
            />
            {errors?.contactDetails?.phone && (
              <p className="text-red-500 text-sm">{errors.contactDetails.phone}</p>
            )}
          </div>

          {/* Physical Address */}
          <div className="lg:col-span-2">
            <label className="block text-sm font-medium text-gray-700">
              Physical Address <span className="text-red-500">*</span>
            </label>
            <input
              type="text"
              className={`${styles.input} focus:outline-none focus:ring-2 focus:ring-yellow-500`}
              value={formData.contactDetails.physicalAddress}
              onChange={(e) =>
                handleChange("contactDetails", { physicalAddress: e.target.value })
              }
              placeholder="Enter physical address"
            />
            {errors?.contactDetails?.physicalAddress && (
              <p className="text-red-500 text-sm">{errors.contactDetails.physicalAddress}</p>
            )}
          </div>

          {/* City */}
          <div>
            <label className="block text-sm font-medium text-gray-700">
              City <span className="text-red-500">*</span>
            </label>
            <input
              type="text"
              className={`${styles.input} focus:outline-none focus:ring-2 focus:ring-yellow-500`}
              value={formData.contactDetails.city}
              onChange={(e) =>
                handleChange("contactDetails", { city: e.target.value })
              }
              placeholder="Enter city"
            />
             {errors?.contactDetails?.city && (
              <p className="text-red-500 text-sm">{errors.contactDetails.city}</p>
            )}
          </div>

          {/* Country */}
          <div>
            <label className="block text-sm font-medium text-gray-700">
              Country <span className="text-red-500">*</span>
            </label>
            <input
              type="text"
              className={`${styles.input} focus:outline-none focus:ring-2 focus:ring-yellow-500`}
              value={formData.contactDetails.country}
              onChange={(e) =>
                handleChange("contactDetails", { country: e.target.value })
              }
              placeholder="Enter country"
            />
             {errors?.contactDetails?.country && (
              <p className="text-red-500 text-sm">{errors.contactDetails.country}</p>
            )}
          </div>

          {/* Postal Code */}
          <div>
            <label className="block text-sm font-medium text-gray-700">
              Postal Code
            </label>
            <input
              type="text"
              className={`${styles.input} focus:outline-none focus:ring-2 focus:ring-yellow-500`}
              value={formData.contactDetails.postalCode}
              onChange={(e) =>
                handleChange("contactDetails", { postalCode: e.target.value })
              }
              placeholder="Enter postal code"
            />
             
          </div>
        </div>

        {/* Navigation Buttons */}
        <div className="flex justify-between mt-6">
          <button
            className="px-4 py-2 bg-gray-500 text-white rounded-md hover:bg-gray-600 transition"
            onClick={handleBack}
          >
            Back
          </button>
          <button
            className="px-4 py-2 bg-yellow-600 text-white rounded-md hover:bg-yellow-700 transition"
            onClick={handleNext}
          >
            Next
          </button>
        </div>
      </div>
    </div>
  );
};

export default ContactDetailsStep;
