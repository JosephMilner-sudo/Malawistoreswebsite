import React, { useEffect, useState } from "react";
import { ProductCard, Ratings } from "./../";
import { Link } from "react-router-dom";
import Spinner from "../Spinner";
import { backendUrl } from "../../server";
import { useDispatch, useSelector } from "react-redux";
import { getAllEventsForShop } from "../../redux/actions/event";
import { format } from "timeago.js";

const ShopProfileData = ({ shopId, isOwner, products, loading }) => {
  const [active, setActive] = useState(1);
  const dispatch = useDispatch();
  const { events } = useSelector((state) => state.event);

  useEffect(() => {
    dispatch(getAllEventsForShop(shopId));
  }, []);

  const reviews = products && products.map((product) => product.reviews).flat();

  return (
    <div className="w-full font-Poppins">
      <div className="w-full flex items-center justify-evenly pb-1 gap-2 overflow-auto py-6">
        <button
          className={`800px:text-lg text-sm border-2 border-primary py-2 px-5 rounded-md ${
            active === 1 &&
            "text-yellow-600 font-bold animate-bounce border-yellow-600"
          }`}
          onClick={() => {
            setActive(1);
          }}
        >
          Shop Products
        </button>
        <button
          className={`800px:text-lg text-sm border-2 border-primary py-2 px-5 rounded-md ${
            active === 2 &&
            "text-yellow-600 font-bold animate-bounce border-yellow-600"
          }`}
          onClick={() => {
            setActive(2);
          }}
        >
          Running Events
        </button>
        <button
          className={`800px:text-lg text-sm border-2 border-primary py-2 px-5 rounded-md ${
            active === 3 &&
            "text-yellow-600 font-bold animate-bounce border-yellow-600"
          }`}
          onClick={() => {
            setActive(3);
          }}
        >
          Shop Reviews
        </button>

        {isOwner && (
          <Link
            to={"/shop/dashboard"}
            className={`bg-yellow-500 text-white py-2 px-5 rounded-md font-bold border-yellow-600 flex ml-4"
          `}
          >
            Dashboard
          </Link>
        )}
      </div>

      <div>
        {active === 1 && (
          <div className="">
            {loading ? (
              <Spinner />
            ) : (
              <div className="w-full grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-[20px] mt-8">
                {products && products.length > 0 ? (
                  products.map((product) => (
                    <ProductCard
                      key={product?._id}
                      products={products}
                      data={product}
                      isAuthenticated={true}
                    />
                  ))
                ) : (
                  <div className="col-span-1 md:col-span-2 lg:col-span-3 xl:col-span-4 mt-[40px]">
                    <h5 className="font-[400] text-md text-center">
                      No Products for this Shop/Seller
                    </h5>
                  </div>
                )}
              </div>
            )}
          </div>
        )}
      </div>

      <div>
        {active === 2 && (
          <div className="">
            {loading ? (
              <Spinner />
            ) : (
              <div className="w-full grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-[20px] mt-8">
                {events && events.length > 0 ? (
                  events.map((product) => (
                    <ProductCard
                      key={product._id}
                      data={product}
                      isAuthenticated={true}
                      isEvent={true}
                    />
                  ))
                ) : (
                  <div className="col-span-1 md:col-span-2 lg:col-span-3 xl:col-span-4 mt-[40px]">
                    <h5 className="font-[400] text-md text-center">
                      No running events for this Shop/Seller
                    </h5>
                  </div>
                )}
              </div>
            )}
          </div>
        )}
      </div>

      <div>
        {active === 3 && (
          <div className="">
            {loading ? (
              <Spinner />
            ) : (
              <div className="w-full flex mt-7 flex-col gap-3">
                {reviews && reviews.length > 0 ? (
                  reviews.map((review) => (
                    <div key={review?._id} className="flex gap-2 items-start">
                      <img
                        src={`${backendUrl}/${review?.user?.avatar}`}
                        alt={review?.user?.name}
                        className="w-[70px] h-[70px] rounded-full border border-yellow-300"
                      />
                      <div className="flex-1 flex flex-col gap-1">
                        <h4 className="flex gap-2">
                          {review?.user?.name}{" "}
                          <Ratings rating={review?.rating} />
                        </h4>
                        <p className="text-gray-500 text-sm">
                          {review?.comment}
                        </p>
                        <p className="text-sm italic text-gray-600">
                          {format(review?.createdAt)}
                        </p>
                      </div>
                    </div>
                  ))
                ) : (
                  <div className="col-span-1 md:col-span-2 lg:col-span-3 xl:col-span-4 mt-[40px]">
                    <h5 className="font-[400] 800px:text-lg text-[11pt] text-center">
                      No Reviews for this Shop/Seller
                    </h5>
                  </div>
                )}
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
};

export default ShopProfileData;
