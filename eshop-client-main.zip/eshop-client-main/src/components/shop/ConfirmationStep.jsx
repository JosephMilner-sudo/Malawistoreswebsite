import React, { useContext } from "react";
import { ShopFormContext } from "./../../context/ShopFormContext";
import { ClipLoader } from "react-spinners";

const ConfirmationStep = () => {
  const { formData, handleBack, handleNext, loading } =
    useContext(ShopFormContext);

  return (
    <div className="w-full mx-auto bg-white shadow-md p-6">
      <div className="bg-primary text-white px-5 py-3 rounded-t-lg">
        <h2 className="text-xl font-bold">Confirm Your Details</h2>
        <p className="text-sm">Review all details before submitting</p>
      </div>

      <div className="p-6 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {/* Basic Details */}
        <section className="bg-gray-100 p-4 rounded-lg shadow">
          <h3 className="text-lg font-semibold border-b pb-2">Basic Details</h3>
          <p>
            <strong>Name:</strong> {formData.basicDetails.name || "N/A"}
          </p>
          <p>
            <strong>Description:</strong>{" "}
            {formData.basicDetails.description || "N/A"}
          </p>
          {formData.basicDetails.logo && (
            <p>
              <strong>Logo:</strong>{" "}
              <span className="text-green-600">Uploaded ✅</span>
            </p>
          )}
        </section>

        {/* Contact Details */}
        <section className="bg-gray-100 p-4 rounded-lg shadow">
          <h3 className="text-lg font-semibold border-b pb-2">
            Contact Details
          </h3>
          <p>
            <strong>Email:</strong> {formData.contactDetails.email || "N/A"}
          </p>
          <p>
            <strong>Phone:</strong> {formData.contactDetails.phone || "N/A"}
          </p>
          <p>
            <strong>Address:</strong>{" "}
            {formData.contactDetails.physicalAddress || "N/A"}
          </p>
          <p>
            <strong>City:</strong> {formData.contactDetails.city || "N/A"}
          </p>
          <p>
            <strong>Country:</strong> {formData.contactDetails.country || "N/A"}
          </p>
          <p>
            <strong>Postal Code:</strong>{" "}
            {formData.contactDetails.postalCode || "N/A"}
          </p>
        </section>

        {/* Business Registration */}
        <section className="bg-gray-100 p-4 rounded-lg shadow">
          <h3 className="text-lg font-semibold border-b pb-2">
            Business Registration
          </h3>
          <p>
            <strong>Business Type:</strong>{" "}
            {formData.businessRegDetails.businessType || "N/A"}
          </p>
          {formData.businessRegDetails.tinCertificate && (
            <p>
              <strong>TIN Certificate:</strong>{" "}
              <span className="text-green-600">Uploaded ✅</span>
            </p>
          )}
          {formData.businessRegDetails.registrationCertificate && (
            <p>
              <strong>Registration Certificate:</strong>{" "}
              <span className="text-green-600">Uploaded ✅</span>
            </p>
          )}
        </section>

        {/* Owner Details */}
        <section className="bg-gray-100 p-4 rounded-lg shadow">
          <h3 className="text-lg font-semibold border-b pb-2">Owner Details</h3>
          <p>
            <strong>Owner Name:</strong>{" "}
            {formData.ownerDetails.ownerName || "N/A"}
          </p>
          <p>
            <strong>Owner Phone:</strong>{" "}
            {formData.ownerDetails.ownerPhoneNumber || "N/A"}
          </p>
          <p>
            <strong>Gender:</strong> {formData.ownerDetails.gender || "N/A"}
          </p>
          <p>
            <strong>Date of Birth:</strong>{" "}
            {formData.ownerDetails.dateOfBirth || "N/A"}
          </p>
          <p>
            <strong>Owner Email:</strong>{" "}
            {formData.ownerDetails.ownerEmail || "N/A"}
          </p>
          {formData.ownerDetails.nationalID && (
            <p>
              <strong>National ID:</strong>{" "}
              <span className="text-green-600">Uploaded ✅</span>
            </p>
          )}
        </section>

        {/* Security Details */}
        <section className="bg-gray-100 p-4 rounded-lg shadow">
          <h3 className="text-lg font-semibold border-b pb-2">
            Security Details
          </h3>
          <p>
            <strong>Password:</strong>{" "}
            <span className="text-gray-500">••••••••</span>
          </p>
          <p>
            <strong>Security Question:</strong>{" "}
            {formData.securityDetails.securityQuestion || "N/A"}
          </p>
          <p>
            <strong>Security Answer:</strong>{" "}
            {formData.securityDetails.securityAnswer || "N/A"}
          </p>
        </section>
      </div>

      {/* Navigation Buttons */}
      <div className="flex justify-between mt-6 px-6 pb-4">
        <button
          className="px-4 py-2 bg-gray-500 text-white rounded-md hover:bg-gray-600 transition"
          onClick={handleBack}
        >
          Back
        </button>
        <button
          disabled={loading}
          className={`px-4 py-2 bg-green-600 text-white flex items-center justify-center rounded-md hover:bg-green-700 transition ${
            loading && "cursor-not-allowed bg-green-200"
          }`}
          onClick={handleNext}
        >
          {loading ? (
            <ClipLoader size={24} color={"white"} />
          ) : (
            <>Confirm & Submit</>
          )}
        </button>
      </div>
    </div>
  );
};

export default ConfirmationStep;
