import React, { useState } from "react";
import { AiFillEdit, AiFillInfoCircle } from "react-icons/ai";
import { useSelector } from "react-redux";
import EditShop from "./EditShop";
import ShopFullDetails from "./ShopFullDetails";

const ShopSettings = () => {
  const [active, setActive] = useState(1);
  const { shop } = useSelector((state) => state.shop);

  return (
    <div className="pt-6 px-4 w-full flex flex-col font-Poppins items-center">
      <h1 className="text-center 800px:text-xl text-lg font-bold mb-4">
        Shop Settings
      </h1>
      <div className="w-full max-w-6xl rounded-xl bg-gray-100 py-3 flex items-center justify-evenly shadow-md">
        <button
          onClick={() => setActive(1)}
          className={`flex px-4 py-2 bg-white items-center rounded-md gap-1 ${
            active === 1 &&
            "font-bold text-yellow-600 border-2 border-yellow-300"
          }`}
        >
          <AiFillEdit />
          Update Shop
        </button>
        <button
          onClick={() => setActive(2)}
          className={`flex px-4 py-2 bg-white items-center rounded-md gap-1 ${
            active === 2 &&
            "font-bold text-yellow-600 border-2 border-yellow-300"
          }`}
        >
          <AiFillInfoCircle />
          Shop Information
        </button>
      </div>

      <div
        className={`${
          active === 1 &&
          "shadow-lg w-full mt-4 max-w-6xl bg-white rounded-xl p-6 border overflow-y-auto"
        }"}`}
      >
        {active === 1 && shop && <EditShop />}
      </div>
      <br />

      <div
        className={`${
          active === 2 &&
          "shadow-lg w-full max-w-6xl bg-white rounded-xl p-6 border overflow-y-auto mb-2"
        }`}
      >
        {active === 2 && shop && <ShopFullDetails shop={shop} />}
      </div>
    </div>
  );
};

export default ShopSettings;
