import React from "react";
import { useShopFormContext } from "./../../hooks/useShopFormContext";
import styles from "./../../styles/styles";

const BasicDetailsStep = () => {
  const { formData, handleChange, errors, handleNext } = useShopFormContext();

  return (
    <div className="w-full max-w-xl bg-white shadow-md mt-5">
      <div className="bg-primary text-white w-full px-5 py-3">
        {" "}
        <h2 className="text-xl font-bold">Basic Details</h2>{" "}
      </div>

      <div className="p-6">
        {/* Name Input */}
        <div className="mb-4">
          <label className="block text-sm font-medium text-gray-700">
            Shop Name <span className="text-red-500">*</span>
          </label>
          <input
            type="text"
            className={`${styles.input}" focus:outline-none focus:ring-2 focus:ring-yellow-500"`}
            value={formData.basicDetails.name}
            onChange={(e) =>
              handleChange("basicDetails", { name: e.target.value })
            }
            placeholder="Enter shop name"
          />
          {errors?.basicDetails?.name && (
            <p className="text-red-500 text-sm">{errors.basicDetails.name}</p>
          )}
        </div>

        {/* Description Input */}
        <div className="mb-4">
          <label className="block text-sm font-medium text-gray-700">
            Description <span className="text-red-500">*</span>
          </label>
          <textarea
            className={`${styles.input}" focus:outline-none focus:ring-2 focus:ring-yellow-500"`}
            value={formData.basicDetails.description}
            onChange={(e) =>
              handleChange("basicDetails", { description: e.target.value })
            }
            placeholder="Enter a brief description of your shop"
          />
          {errors?.basicDetails?.description && (
            <p className="text-red-500 text-sm">
              {errors.basicDetails.description}
            </p>
          )}
        </div>

        {/* Logo Upload */}
        <div className="mb-4">
          <label className="block text-sm font-medium text-gray-700">
            Upload Logo <span className="text-red-500">*</span>
          </label>
          <input
            type="file"
            className={`${styles.input}" focus:outline-none focus:ring-2 focus:ring-yellow-500"`}
            accept="image/*"
            onChange={(e) =>
              handleChange("basicDetails", { logo: e.target.files[0] })
            }
          />
          {errors?.basicDetails?.logo && (
            <p className="text-red-500 text-sm">{errors.basicDetails.logo}</p>
          )}
        </div>

        {/* Next Button */}
        <div className="flex justify-end mt-4">
          <button
            className="px-4 py-2 bg-yellow-600 text-white rounded-md hover:bg-yellow-700 transition"
            onClick={handleNext}
          >
            Next
          </button>
        </div>
      </div>
    </div>
  );
};

export default BasicDetailsStep;
