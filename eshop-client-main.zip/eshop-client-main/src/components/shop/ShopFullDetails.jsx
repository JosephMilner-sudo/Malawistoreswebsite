import React from "react";
import { backendUrl } from "../../server";
import { AiOutlineShop } from "react-icons/ai";

const ShopFullDetails = ({ shop }) => {
  const renderFilePreview = (file) => {
    if (!file) return null;
    //const isPDF = file.endsWith(".pdf");
    return (
      <div className="mt-2">
        {/* {isPDF ? (
              <iframe
                title={file}
                src={file}
                className="w-full h-56 border rounded-md"
              ></iframe>
            ) : (
              <img
                src={`${backendUrl}/${file}`}
                alt="Document Preview"
                className="w-[275px] h-auto border rounded-md "
              />
            )} */}
        <a
          href={`${backendUrl}/${file}`}
          download
          className="mt-2 inline-block px-4 py-2 bg-blue-600 text-white rounded-md shadow-md hover:bg-blue-700"
        >
          Preview
        </a>
      </div>
    );
  };
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 p-4">
      <div className="col-span-full flex flex-col items-center text-center border-b pb-1">
        <h2 className="text-xl font-semibold mb-1">{shop.name}</h2>
        <p className="text-sm text-gray-400 mb-2 font-light">#{shop._id}</p>
        <div className="rounded-full border h-[150px] w-[150px] border-primary relative self-center">
          {shop.logo ? (
            <img
              src={`${backendUrl}/${shop.logo}`}
              alt="Shop Logo"
              className="object-contain w-full h-full rounded-full"
            />
          ) : (
            <AiOutlineShop className="w-full h-full" />
          )}
        </div>

        <p className="text-gray-700 italic">{shop.description}</p>
      </div>
      <p>
        <strong>Business Email:</strong> {shop.email}
      </p>
      <p>
        <strong>Phone:</strong> {shop.phone}
      </p>
      <p>
        <strong>Address:</strong> {shop.physicalAddress}, {shop.city},{" "}
        {shop.country}
      </p>
      <p>
        <strong>Business Type:</strong> {shop.businessType}
      </p>
      <p>
        <strong>Owner:</strong> {shop.ownerName} ({shop.ownerPhoneNumber})
      </p>
      <p>
        <strong>Date of Birth:</strong>{" "}
        {new Date(shop.dateOfBirth).toDateString()}
      </p>
      <p>
        <strong>Gender:</strong> {shop.gender}
      </p>
      <p>
        <strong>Postal Code:</strong> {shop.postalCode}
      </p>
      <p>
        <strong>Approval Status:</strong>{" "}
        {shop.isApproved ? "✅ Approved" : "⏳ Pending"}
      </p>
      <div className="">
        <strong>TIN Certificate:</strong>
        {renderFilePreview(shop.tinCertificate)}
      </div>
      <div className="">
        <strong>Registration Certificate:</strong>
        {renderFilePreview(shop.registrationCertificate)}
      </div>
      <div className="">
        <strong>National ID:</strong>
        {renderFilePreview(shop.nationalID)}
      </div>
    </div>
  );
};

export default ShopFullDetails;
