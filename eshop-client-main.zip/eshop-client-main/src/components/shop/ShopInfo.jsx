import React, { useState } from "react";
import { backendUrl, server } from "./../../server";
import { BsShop } from "react-icons/bs";
import styles from "../../styles/styles";
import axios from "axios";
import { toast } from "react-toastify";
import { ClipLoader } from "react-spinners";
import { Link, useNavigate } from "react-router-dom";
import { useSelector } from "react-redux";
import { BiHome, BiMessage } from "react-icons/bi";

const ShopInfo = ({ isOwner, shopData, products }) => {
  const shop = shopData;
  const { user, isAuthenticated } = useSelector((state) => state.user);
  const navigate = useNavigate();
  const [loading, setLoading] = useState(false);
  const [logoutLoading, setLogoutLoading] = useState(false);
  const totalReviews =
    products &&
    products.reduce((acc, product) => acc + product.reviews.length, 0);

  const totalRatings =
    products &&
    products.reduce(
      (acc, product) =>
        acc + product.reviews.reduce((sum, review) => sum + review.rating, 0),
      0
    );

  const avgRating = totalRatings / totalReviews || 0;

  const logoutHandler = async () => {
    setLogoutLoading(true);
    await axios
      .get(`${server}/shop/logout`, { withCredentials: true })
      .then((res) => {
        setLogoutLoading(false);
        toast.success("Logging you out");
        window.location.reload();
      })
      .catch((err) => {
        setLogoutLoading(false);
        console.log(err.response.data.message);
      });
  };

  const handleSendMessage = async () => {
    if (!isAuthenticated) {
      toast.error("Login to iniate a conversation with our shop");
      return;
    }

    setLoading(true);

    const groupTitle = shop?._id + user?._id;
    const userId = user?._id;
    const shopId = shop?._id;

    await axios
      .post(`${server}/conversation/create-conversation`, {
        groupTitle,
        userId,
        shopId,
      })
      .then((res) => {
        setLoading(false);
        navigate(`/inbox?conversationId=${res.data.conversation._id}`);
      })
      .catch((err) => {
        setLoading(false);
        toast.error(err.response.data.message);
      });
  };

  return (
    <div className="w-full flex flex-col gap-6 font-Poppins p-4">
      <div className="flex w-full justify-center items-center flex-col gap-1 relative">
        <Link
          to={"/"}
          title="Go back to Home page"
          className="absolute top-0 left-0 p-1 bg-black/50 rounded-full text-white"
        >
          <BiHome size={24} />
        </Link>
        {shop?.logo ? (
          <img
            src={`${backendUrl}/${shop.logo}`}
            alt="Logo"
            className="w-[150px] h-[150px] rounded-full object-cover border-2 border-yellow-400"
          />
        ) : (
          <div className="w-[150px] h-[150px] rounded-full border-2 border-yellow-400 bg-gray-200 flex items-center justify-center">
            <BsShop className="" size={100} />
          </div>
        )}

        <h2 className="text-lg font-[500]">{shop?.name}</h2>
      </div>

      <div>
        <p className="text-gray-500 text-center">
          {shop?.description?.length > 100 ? shop?.description?.slice(0, 100) + " ... " : shop.description}
        </p>
      </div>

      <div className="flex flex-col gap-3">
        <div>
          <h4 className="font-[600]">Address</h4>
          <p className="text-gray-500">{shop?.physicalAddress}</p>
        </div>
        <div>
          <h4 className="font-[600]">Phone Number</h4>
          <p className="text-gray-500">{shop?.phone}</p>
        </div>
        <div>
          <h4 className="font-[600]">Total Products</h4>
          <p className="text-gray-500">{products?.length}</p>
        </div>
        <div>
          <h4 className="font-[600]">Shop Ratings</h4>
          <p className="text-gray-500">{avgRating}/5</p>
        </div>
        <div>
          <h4 className="font-[600]">Joined On</h4>
          <p className="text-gray-500">{shop?.createdAt?.length > 10 ? shop?.createdAt.slice(0, 10) : shop.createdAt}</p>
        </div>
      </div>

      {isOwner ? (
        <div className="w-full flex justify-evenly items-center">
          <Link
            to={"/shop/settings"}
            className={`${styles.button} !text-white`}
          >
            Edit Shop
          </Link>

          {logoutLoading ? (
            <ClipLoader size={30} color="red" />
          ) : (
            <button
              className={`${styles.button} !text-white !bg-red-500`}
              onClick={logoutHandler}
              disabled={logoutLoading}
            >
              Logout
            </button>
          )}
        </div>
      ) : (
        <button
          className={`${styles.button} ml-6`}
          onClick={handleSendMessage}
          disabled={loading}
        >
          <span className="text-white flex items-center gap-2">
            {loading ? (
              <ClipLoader size={24} color="white" />
            ) : (
              <>
                Send message <BiMessage size={20} />{" "}
              </>
            )}
          </span>
        </button>
      )}
    </div>
  );
};

export default ShopInfo;
