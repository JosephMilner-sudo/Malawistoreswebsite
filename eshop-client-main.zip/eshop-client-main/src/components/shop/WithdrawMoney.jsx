import React, { useEffect, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { getAllOrdersForShop } from "../../redux/actions/order";
import { toKwacha } from "../../utils/toKwacha";
import styles from "../../styles/styles";

const WithdrawMoney = () => {
  const dispatch = useDispatch();
  const { orders } = useSelector((state) => state.order);
  const { shop } = useSelector((state) => state.shop);

  const [deliveredOrders, setDeliveredOrders] = useState([]);

  useEffect(() => {
    if (shop?._id) {
      dispatch(getAllOrdersForShop(shop._id));
    }
  }, [dispatch, shop?._id]);

  useEffect(() => {
    if (orders?.length) {
      const delivered = orders.filter((order) => order.status === "Delivered");
      setDeliveredOrders(delivered);
    }
  }, [orders]);

  const totalEarnings = deliveredOrders.reduce(
    (acc, order) => acc + order.totalPrice,
    0
  );

  const serviceCharge = totalEarnings * 0.1;
  const availableBalance = totalEarnings - serviceCharge;

  return (
    <div className="w-full p-8 min-h-[90vh] bg-gray-50">
      <div className="w-full max-w-md mx-auto bg-white shadow-md rounded-lg p-6 flex flex-col items-center justify-center gap-4">
        <h2 className="800px:text-2xl  font-semibold text-gray-800">
          Withdraw Funds
        </h2>
        <p className="800px:text-lg text-sm text-gray-700">
          Available Balance:{" "}
          <span className="font-bold">{toKwacha(availableBalance)}</span>
        </p>
        <button
          className={`${styles.button} px-6 py-2 text-white bg-green-600 hover:bg-green-700 rounded`}
        >
          Withdraw
        </button>
      </div>
    </div>
  );
};

export default WithdrawMoney;
