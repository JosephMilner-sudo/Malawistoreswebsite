import React, { useState } from "react";
import { useShopFormContext } from "./../../hooks/useShopFormContext";
import styles from "./../../styles/styles";
import { HiEyeOff } from "react-icons/hi";
import { BsEye } from "react-icons/bs";

const SecurityDetailsStep = () => {
  const { formData, handleChange, errors, handleBack, handleNext } =
    useShopFormContext();

  const [showPassword, setShowPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);

  return (
    <div className="w-full max-w-xl bg-white shadow-md mt-5">
      <div className="bg-primary text-white w-full px-5 py-3">
        <h2 className="text-xl font-bold">Security Details</h2>
      </div>

      <div className="p-6">
        {/* Input Fields Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
          {/* Password */}
          <div className="relative">
            <label className="block text-sm font-medium text-gray-700">
              Password <span className="text-red-500">*</span>
            </label>
            <input
              type={showPassword ? "text" : "password"}
              className={`${styles.input} pr-10`}
              value={formData.securityDetails.password}
              onChange={(e) =>
                handleChange("securityDetails", { password: e.target.value })
              }
              placeholder="Enter password"
            />
            <button
              type="button"
              className="absolute right-3 top-8 text-gray-500"
              onClick={() => setShowPassword(!showPassword)}
            >
              {showPassword ? <HiEyeOff size={20} /> : <BsEye size={20} />}
            </button>
            {errors?.securityDetails?.password && (
              <p className="text-red-500 text-sm">
                {errors.securityDetails.password}
              </p>
            )}
          </div>

          {/* Confirm Password */}
          <div className="relative">
            <label className="block text-sm font-medium text-gray-700">
              Confirm Password <span className="text-red-500">*</span>
            </label>
            <input
              type={showConfirmPassword ? "text" : "password"}
              className={`${styles.input} pr-10`}
              value={formData.securityDetails.confirmPassword}
              onChange={(e) =>
                handleChange("securityDetails", {
                  confirmPassword: e.target.value,
                })
              }
              placeholder="Re-enter password"
            />
            <button
              type="button"
              className="absolute right-3 top-8 text-gray-500"
              onClick={() => setShowConfirmPassword(!showConfirmPassword)}
            >
              {showConfirmPassword ? (
                <HiEyeOff size={20} />
              ) : (
                <BsEye size={20} />
              )}
            </button>
            {errors?.securityDetails?.confirmPassword && (
              <p className="text-red-500 text-sm">
                {errors.securityDetails.confirmPassword}
              </p>
            )}
          </div>

          {/* Security Question */}
          <div className="lg:col-span-2">
            <label className="block text-sm font-medium text-gray-700">
              Security Question <span className="text-red-500">*</span>
            </label>
            <select
              className={`${styles.input}`}
              value={formData.securityDetails.securityQuestion}
              onChange={(e) =>
                handleChange("securityDetails", {
                  securityQuestion: e.target.value,
                })
              }
            >
              <option value="">Select a security question</option>
              <option value="pet">What was your first pet's name?</option>
              <option value="school">
                What is the name of your first school?
              </option>
              <option value="city">In which city were you born?</option>
            </select>
            {errors?.securityDetails?.securityQuestion && (
              <p className="text-red-500 text-sm">
                {errors.securityDetails.securityQuestion}
              </p>
            )}
          </div>

          {/* Answer to Security Question */}
          <div className="lg:col-span-2">
            <label className="block text-sm font-medium text-gray-700">
              Security Answer <span className="text-red-500">*</span>
            </label>
            <input
              type="text"
              className={`${styles.input}`}
              value={formData.securityDetails.securityAnswer}
              onChange={(e) =>
                handleChange("securityDetails", {
                  securityAnswer: e.target.value,
                })
              }
              placeholder="Enter your answer"
            />
            {errors?.securityDetails?.securityAnswer && (
              <p className="text-red-500 text-sm">
                {errors.securityDetails.securityAnswer}
              </p>
            )}
          </div>
        </div>

        {/* Navigation Buttons */}
        <div className="flex justify-between mt-6">
          <button
            className="px-4 py-2 bg-gray-500 text-white rounded-md hover:bg-gray-600 transition"
            onClick={handleBack}
          >
            Back
          </button>
          <button
            className="px-4 py-2 bg-yellow-600 text-white rounded-md hover:bg-yellow-700 transition"
            onClick={handleNext}
          >
            Next
          </button>
        </div>
      </div>
    </div>
  );
};

export default SecurityDetailsStep;
