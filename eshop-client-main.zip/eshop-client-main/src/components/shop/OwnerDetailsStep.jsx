import React from "react";
import { useShopFormContext } from "./../../hooks/useShopFormContext";
import styles from "./../../styles/styles";

const OwnerDetailsStep = () => {
  const { formData, handleChange, errors, handleNext, handleBack } =
    useShopFormContext();

  const today = new Date();
  const minDate = new Date(today.setFullYear(today.getFullYear() - 18))
    .toISOString()
    .split("T")[0];

  return (
    <div className="w-full max-w-xl bg-white shadow-md mt-5">
      <div className="bg-primary text-white w-full px-5 py-3">
        <h2 className="text-xl font-bold">Shop Owner Details</h2>
      </div>

      <div className="p-6">
        {/* Input Fields Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
          {/* Owner Name */}
          <div>
            <label className="block text-sm font-medium text-gray-700">
              Owner Full Name <span className="text-red-500">*</span>
            </label>
            <input
              type="text"
              className={`${styles.input} focus:outline-none focus:ring-2 focus:ring-yellow-500`}
              value={formData.ownerDetails.ownerName}
              onChange={(e) =>
                handleChange("ownerDetails", { ownerName: e.target.value })
              }
              placeholder="Enter owner's name"
            />
            {errors?.ownerDetails?.ownerName && (
              <p className="text-red-500 text-sm">
                {errors.ownerDetails.ownerName}
              </p>
            )}
          </div>

          {/* Owner Phone Number */}
          <div>
            <label className="block text-sm font-medium text-gray-700">
              Phone Number <span className="text-red-500">*</span>
            </label>
            <input
              type="text"
              className={`${styles.input} focus:outline-none focus:ring-2 focus:ring-yellow-500`}
              value={formData.ownerDetails.ownerPhoneNumber}
              onChange={(e) =>
                handleChange("ownerDetails", {
                  ownerPhoneNumber: e.target.value,
                })
              }
              placeholder="Enter phone number"
            />
            {errors?.ownerDetails?.ownerPhoneNumber && (
              <p className="text-red-500 text-sm">
                {errors.ownerDetails.ownerPhoneNumber}
              </p>
            )}
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700">
              Gender <span className="text-red-500">*</span>
            </label>
            <select
              className={`${styles.input} focus:outline-none focus:ring-2 focus:ring-yellow-500`}
              value={formData.ownerDetails.gender}
              onChange={(e) =>
                handleChange("ownerDetails", {
                  gender: e.target.value,
                })
              }
            >
              <option value="">Select Gender</option>
              <option value="Male">Male</option>
              <option value="Female">Female</option>
              <option value="Others">Others</option>
            </select>
            {errors?.ownerDetails?.gender && (
              <p className="text-red-500 text-sm">
                {errors.ownerDetails.gender}
              </p>
            )}
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700">
              Date of Birth <span className="text-red-500">*</span>
            </label>
            <input
              type="date"
              max={minDate}
              required
              className={`${styles.input} focus:outline-none focus:ring-2 focus:ring-yellow-500`}
              value={formData.ownerDetails.dateOfBirth}
              onChange={(e) =>
                handleChange("ownerDetails", { dateOfBirth: e.target.value })
              }
              placeholder="Select date of Birth"
            />
            {errors?.ownerDetails?.dateOfBirth && (
              <p className="text-red-500 text-sm">
                {errors.ownerDetails.dateOfBirth}
              </p>
            )}
          </div>

          {/* Owner Email */}
          <div className="lg:col-span-2">
            <label className="block text-sm font-medium text-gray-700">
              Login Email <span className="text-red-500">*</span>
            </label>
            <input
              type="email"
              className={`${styles.input} focus:outline-none focus:ring-2 focus:ring-yellow-500`}
              value={formData.ownerDetails.ownerEmail}
              onChange={(e) =>
                handleChange("ownerDetails", { ownerEmail: e.target.value })
              }
              placeholder="Enter email address"
            />
            {errors?.ownerDetails?.ownerEmail && (
              <p className="text-red-500 text-sm">
                {errors.ownerDetails.ownerEmail}
              </p>
            )}
          </div>

          {/* Profile Picture Upload */}
          <div className="lg:col-span-2">
            <label className="block text-sm font-medium text-gray-700">
              Upload National ID <span className="text-red-500">*</span>
            </label>
            <input
              type="file"
              className={`${styles.input} focus:outline-none focus:ring-2 focus:ring-yellow-500`}
              onChange={(e) =>
                handleChange("ownerDetails", { nationalID: e.target.files[0] })
              }
            />
            {errors?.ownerDetails?.nationalID && (
              <p className="text-red-500 text-sm">
                {errors.ownerDetails.nationalID}
              </p>
            )}
          </div>
        </div>

        {/* Navigation Buttons */}
        <div className="flex justify-between mt-6">
          <button
            className="px-4 py-2 bg-gray-500 text-white rounded-md hover:bg-gray-600 transition"
            onClick={handleBack}
          >
            Back
          </button>
          <button
            className="px-4 py-2 bg-yellow-600 text-white rounded-md hover:bg-yellow-700 transition"
            onClick={handleNext}
          >
            Next
          </button>
        </div>
      </div>
    </div>
  );
};

export default OwnerDetailsStep;
