import React, { useState } from "react";
import { AiOutlineCamera, AiOutlineShop } from "react-icons/ai";
import { useDispatch, useSelector } from "react-redux";
import styles from "../../styles/styles";
import { backendUrl, server } from "../../server";
import axios from "axios";
import { toast } from "react-toastify";
import { loadShop } from "../../redux/actions/shop";
import { ClipLoader } from "react-spinners";

const EditShop = () => {
  const { shop } = useSelector((state) => state.shop);
  const [logo, setLogo] = useState(null);
  const [loading, setLoading] = useState(false);
  const [formData, setFormData] = useState({
    name: shop?.name || "",
    description: shop?.description || "",
    email: shop?.email || "",
    phone: shop?.phone || "",
    physicalAddress: shop?.physicalAddress || "",
    businessType: shop?.businessType || "",
    ownerName: shop?.ownerName || "",
    ownerEmail: shop?.ownerEmail || "",
    ownerPhoneNumber: shop?.ownerPhoneNumber || "",
    dateOfBirth: shop?.dateOfBirth?.slice(0, 10) || "",
    gender: shop?.gender || "",
    postalCode: shop?.postalCode || "",
    country: shop?.country || "",
    city: shop?.city || "",
    password: "",
  });
  const dispatch = useDispatch();

  const handleChange = (e) => {
    const { name, value } = e.target;

    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    setLoading(true);

    await axios
      .put(
        `${server}/shop/update-shop-info`,
        { ...formData, id: shop?._id },
        {
          withCredentials: true,
        }
      )
      .then((res) => {
        setLoading(false);
        toast.success("Shop Info updated successfully");
        setTimeout(() => {
          dispatch(loadShop());
        }, 1500);
      })
      .catch((err) => {
        setLoading(false);
        toast.error(err?.response?.data.message);
      });
  };

  const handleImage = async (e) => {
    e.preventDefault();

    const logoFile = e.target.files[0];
    setLogo(logoFile);

    const formData = new FormData();

    formData.append("logo", logoFile);

    setLoading(true);

    await axios
      .put(`${server}/shop/update-shop-logo`, formData, {
        headers: {
          "Content-Type": "multipart/form-data",
        },
        withCredentials: true,
      })
      .then((res) => {
        setLoading(false);
        toast.success("Logo uploaded successfully");
        setTimeout(() => {
          dispatch(loadShop());
        }, 1500);
      })
      .catch((err) => {
        setLoading(false);
        toast.error(err?.response?.data.message);
      });
  };

  return (
    <form
      onSubmit={handleSubmit}
      className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 p-4"
    >
      <div className="col-span-full flex flex-col items-center text-center border-b pb-1">
        <div className="w-full flex 800px:flex-row flex-col justify-evenly 800px:items-start gap-3 mt-2">
          <div className="rounded-full border h-[70px] w-[70px] border-primary relative self-center">
            {shop.logo ? (
              <img
                src={
                  logo
                    ? URL.createObjectURL(logo)
                    : `${backendUrl}/${shop.logo}`
                }
                alt="Shop Logo"
                className="object-cover w-full h-full rounded-full"
              />
            ) : (
              <AiOutlineShop className="w-full h-full" />
            )}
            <div className="absolute top-[-15px] left-7 bg-primary z-20 rounded-full p-0.5">
              <input
                onChange={handleImage}
                type="file"
                id="avatar"
                className="hidden"
                accept="image/*"
              />
              <label htmlFor="avatar" className="cursor-pointer">
                <AiOutlineCamera size={20} className="text-white" />
              </label>
            </div>
          </div>

          <div className="flex flex-col gap-1 items-start">
            <label htmlFor="">Shop Name</label>
            <input
              className={`${styles.input}}`}
              type="text"
              name="name"
              value={formData.name}
              onChange={handleChange}
              required
              disabled={true}
            />
          </div>

          <div className="flex flex-col gap-1 items-start">
            <label htmlFor="">Shop Description</label>
            <textarea
              className={`${styles.input}}`}
              name="description"
              cols={35}
              value={formData.description}
              onChange={handleChange}
              required
            />
          </div>
        </div>
      </div>
      <div className="flex flex-col gap-1 items-start">
        <label htmlFor="">Business Email</label>
        <input
          className={`${styles.input}}`}
          type="email"
          name="email"
          value={formData.email}
          onChange={handleChange}
          required
        />
      </div>
      <div className="flex flex-col gap-1 items-start">
        <label htmlFor="">Shop Phone number</label>
        <input
          className={`${styles.input}}`}
          type="text"
          name="phone"
          value={formData.phone}
          onChange={handleChange}
          required
        />
      </div>
      <div className="flex flex-col gap-1 items-start">
        <label htmlFor="">Shop Physical Address</label>
        <textarea
          className={`${styles.input}}`}
          name="physicalAddress"
          value={formData.physicalAddress}
          onChange={handleChange}
          required
        />
      </div>
      <div className="flex flex-col gap-1 items-start">
        <label htmlFor="">Business Type</label>
        <select
          className={`${styles.input}}`}
          type="text"
          name="businessType"
          value={formData.businessType}
          onChange={handleChange}
          required
        >
          <option value="">Select business type</option>
          <option value="sole-proprietor">Sole Proprietor</option>
          <option value="partnership">Partnership</option>
          <option value="company">Company</option>
        </select>
      </div>
      <div className="flex flex-col gap-1 items-start">
        <label htmlFor="">Owner Name</label>
        <input
          className={`${styles.input}}`}
          type="text"
          name="ownerName"
          value={formData.ownerName}
          onChange={handleChange}
          required
        />
      </div>
      <div className="flex flex-col gap-1 items-start">
        <label htmlFor="">Gender</label>
        <select
          className={`${styles.input}}`}
          name="gender"
          value={formData.gender}
          onChange={handleChange}
          required
        >
          <option value="">Select Gender</option>
          <option value="Male">Male</option>
          <option value="Female">Female</option>
          <option value="Others">Others</option>
        </select>
      </div>
      <div className="flex flex-col gap-1 items-start">
        <label htmlFor="">Owner Date of Birth</label>
        <input
          className={`${styles.input}}`}
          type="date"
          name="dateOfBirth"
          value={formData.dateOfBirth}
          onChange={handleChange}
          required
        />
      </div>

      <div className="flex flex-col gap-1 items-start">
        <label htmlFor="">Owner Phone Number</label>
        <input
          className={`${styles.input}}`}
          type="text"
          name="ownerPhoneNumber"
          value={formData.ownerPhoneNumber}
          onChange={handleChange}
          required
        />
      </div>

      <div className="flex flex-col gap-1 items-start">
        <label htmlFor="">Login Email Address</label>
        <input
          className={`${styles.input}}`}
          type="email"
          name="ownerEmail"
          value={formData.ownerEmail}
          onChange={handleChange}
          required
        />
      </div>

      <div className="flex flex-col gap-1 items-start">
        <label htmlFor="">Country</label>
        <input
          className={`${styles.input}}`}
          type="text"
          name="country"
          value={formData.country}
          onChange={handleChange}
          required
        />
      </div>

      <div className="flex flex-col gap-1 items-start">
        <label htmlFor="">City</label>
        <input
          className={`${styles.input}}`}
          type="text"
          name="city"
          value={formData.city}
          onChange={handleChange}
          required
        />
      </div>

      <div className="flex flex-col gap-1 items-start">
        <label htmlFor="">Postal Code</label>
        <input
          className={`${styles.input}}`}
          type="text"
          name="postalCode"
          value={formData.postalCode}
          onChange={handleChange}
          required
        />
      </div>

      <div className="flex flex-col gap-1 items-start">
        <label htmlFor="">Password</label>
        <input
          className={`${styles.input}}`}
          type="password"
          name="password"
          value={formData.password}
          onChange={handleChange}
          required
        />
      </div>
      <button
        disabled={loading}
        type="submit"
        className={`${styles.button} 800px:col-span-3`}
      >
        {loading ? <ClipLoader size={24} color={"white"} /> : "Update"}
      </button>
    </form>
  );
};

export default EditShop;
