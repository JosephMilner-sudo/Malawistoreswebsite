import React, { useEffect, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { deleteProduct } from "../../redux/actions/product";
import { ClipLoader } from "react-spinners";
import { Link } from "react-router-dom";
import { CgArrowRight } from "react-icons/cg";
import { toast } from "react-toastify";
import { getAllOrdersForShop } from "../../redux/actions/order";
import { toKwacha } from "../../utils/toKwacha";
import styles from "../../styles/styles";

const ShopRefunds = () => {
  const dispatch = useDispatch();
  const { orders, loading, error } = useSelector((state) => state.order);
  const { shop } = useSelector((state) => state.shop);

  const [search, setSearch] = useState("");
  const [page, setPage] = useState(1);
  const rowsPerPage = 10;

  useEffect(() => {
    dispatch(getAllOrdersForShop(shop?._id));

    if (error && error !== "Invalid shopId format") {
      toast.error(error);
    }
  }, []);

  const eligibleOrders = orders?.filter(
    (item) =>
      item.status === "Processing Refund" || item.status === "Refund Successful"
  );

  const filteredOrders = eligibleOrders?.filter((item) =>
    item._id.toLowerCase().includes(search.toLowerCase())
  );

  const paginatedOrders = filteredOrders?.slice(
    (page - 1) * rowsPerPage,
    page * rowsPerPage
  );

  const totalPages = Math.ceil((filteredOrders?.length || 0) / rowsPerPage);

  if (loading) {
    return (
      <div className="w-full h-[80vh] flex items-center justify-center">
        <ClipLoader size={100} color="blue" />
      </div>
    );
  }

  return (
    <div className="bg-white w-full pt-1 mt-10 800px:mx-8 mx-4">
      <div className="mb-4 flex justify-between items-center px-2">
        <h2 className="font-semibold text-lg">Refunds</h2>
        <input
          type="text"
          placeholder="Search by Product ID..."
          value={search}
          onChange={(e) => {
            setSearch(e.target.value);
            setPage(1); // reset page on search
          }}
          className={`${styles.input} !w-[50%]`}
        />
      </div>

      <div className="overflow-x-auto rounded-lg border border-gray-200">
        <table className="w-full text-sm text-left">
          <thead className="bg-white text-gray-700">
            <tr>
              <th className="px-4 py-2">Product Id</th>
              <th className="px-4 py-2">Status</th>
              <th className="px-4 py-2">Item Quantity</th>
              <th className="px-4 py-2">Total Price</th>
              <th className="px-4 py-2">Action</th>
            </tr>
          </thead>
          <tbody>
            {paginatedOrders?.length > 0 ? (
              paginatedOrders.map((item) => (
                <tr key={item._id} className="border-t hover:bg-gray-50">
                  <td className="px-4 py-2">{item._id}</td>
                  <td className="px-4 py-2">{item.status}</td>
                  <td className="px-4 py-2">{item.cart?.length}</td>
                  <td className="px-4 py-2">{toKwacha(item.totalPrice)}</td>
                  <td className="px-4 py-2">
                    <Link to={`/order/${item._id}`}>
                      <CgArrowRight size={22} className="text-blue-600" />
                    </Link>
                  </td>
                </tr>
              ))
            ) : (
              <tr>
                <td colSpan={5} className="text-center py-6">
                  No matching refunds found.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>

      {/* Pagination */}
      {totalPages > 1 && (
        <div className="flex justify-center mt-4 space-x-2">
          {[...Array(totalPages)].map((_, index) => (
            <button
              key={index}
              onClick={() => setPage(index + 1)}
              className={`px-3 py-1 border rounded ${
                page === index + 1
                  ? "bg-blue-600 text-white"
                  : "bg-white border-gray-300"
              }`}
            >
              {index + 1}
            </button>
          ))}
        </div>
      )}
    </div>
  );
};

export default ShopRefunds;
