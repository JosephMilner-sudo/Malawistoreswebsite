import React, { useEffect, useState } from "react";
import { AiOutlineArrowRight, AiOutlineMoneyCollect } from "react-icons/ai";
import styles from "../../styles/styles";
import { Link } from "react-router-dom";
import { MdBorderClear } from "react-icons/md";
import { useDispatch, useSelector } from "react-redux";
import { getAllOrdersForShop } from "../../redux/actions/order";
import { getAllProductsForShop } from "../../redux/actions/product";
import { toKwacha } from "../../utils/toKwacha";

const DashboardHero = () => {
  const dispatch = useDispatch();
  const { orders } = useSelector((state) => state.order);
  const { shop } = useSelector((state) => state.shop);
  const { products } = useSelector((state) => state.product);
  const [deliveredOrders, setDeliveredOrders] = useState(null);

  useEffect(() => {
    if (shop?._id) {
      dispatch(getAllOrdersForShop(shop._id));
      dispatch(getAllProductsForShop(shop._id));
    }
  }, [dispatch, shop?._id]);

  useEffect(() => {
    if (orders) {
      const orderData = orders.filter((item) => item.status === "Delivered");
      setDeliveredOrders(orderData);
    }
  }, [orders]);

  const totalEarningWithoutTax =
    deliveredOrders &&
    deliveredOrders.reduce((acc, item) => acc + item.totalPrice, 0);

  const serviceCharge = totalEarningWithoutTax * 0.1;
  const availableBalance = totalEarningWithoutTax - serviceCharge;

  const latestOrders =
    orders && orders.length > 4 ? orders.slice(0, 4) : orders;

  return (
    <div className="w-full 800px:p-8 p-2">
      <h3 className="text-[22px] font-Poppins pb-2">Overview</h3>

      {/* Summary Cards */}
      <div className="w-full block 800px:flex items-center justify-between">
        {/* Account Balance */}
        <div className="w-full mb-4 800px:w-[30%] min-h-[20vh] bg-white shadow rounded px-2 py-5">
          <div className="flex items-center">
            <AiOutlineMoneyCollect
              size={30}
              className="mr-2"
              fill="#00000085"
            />
            <h3
              className={`${styles.productTitle} !text-[18px] leading-5 !font-[400] text-[#00000085]`}
            >
              Account Balance{" "}
              <span className="text-[16px]">(with 10% service charge)</span>
            </h3>
          </div>
          <h5 className="pt-2 pl-[36px] text-[22px] font-[500]">
            {toKwacha(availableBalance)}
          </h5>
          <Link to="/shop/dashboard-withdraw-money">
            <h5 className="pt-4 pl-[2] text-[#077f9c]">Withdraw Money</h5>
          </Link>
        </div>

        {/* All Orders */}
        <div className="w-full mb-4 800px:w-[30%] min-h-[20vh] bg-white shadow rounded px-2 py-5">
          <div className="flex items-center">
            <MdBorderClear size={30} className="mr-2" fill="#00000085" />
            <h3
              className={`${styles.productTitle} !text-[18px] leading-5 !font-[400] text-[#00000085]`}
            >
              All Orders
            </h3>
          </div>
          <h5 className="pt-2 pl-[36px] text-[22px] font-[500]">
            {orders && orders.length}
          </h5>
          <Link to="/shop/dashboard-orders">
            <h5 className="pt-4 pl-2 text-[#077f9c]">View Orders</h5>
          </Link>
        </div>

        {/* All Products */}
        <div className="w-full mb-4 800px:w-[30%] min-h-[20vh] bg-white shadow rounded px-2 py-5">
          <div className="flex items-center">
            <AiOutlineMoneyCollect
              size={30}
              className="mr-2"
              fill="#00000085"
            />
            <h3
              className={`${styles.productTitle} !text-[18px] leading-5 !font-[400] text-[#00000085]`}
            >
              All Products
            </h3>
          </div>
          <h5 className="pt-2 pl-[36px] text-[22px] font-[500]">
            {products && products.length}
          </h5>
          <Link to="/shop/dashboard-products">
            <h5 className="pt-4 pl-2 text-[#077f9c]">View Products</h5>
          </Link>
        </div>
      </div>

      {/* Latest Orders Table */}
      <br />
      <h3 className="text-[22px] font-Poppins pb-2">Latest Orders</h3>
      <div className="w-full min-h-[45vh] bg-white rounded shadow overflow-x-auto">
        <table className="w-full text-left border-collapse">
          <thead className="bg-[#f9fafb] border-b border-gray-200">
            <tr className="text-sm font-medium text-gray-600">
              <th className="px-4 py-3">Order ID</th>
              <th className="px-4 py-3">Status</th>
              <th className="px-4 py-3">Items Qty</th>
              <th className="px-4 py-3">Total</th>
              <th className="px-4 py-3">Action</th>
            </tr>
          </thead>
          <tbody>
            {latestOrders && latestOrders.length > 0 ? (
              latestOrders.map((order) => (
                <tr
                  key={order._id}
                  className="text-sm border-b border-gray-200 hover:bg-gray-50 transition"
                >
                  <td className="px-4 py-3">{order._id}</td>
                  <td
                    className={`px-4 py-3 ${
                      order.status === "Delivered"
                        ? "text-green-600"
                        : "text-red-500"
                    }`}
                  >
                    {order.status}
                  </td>
                  <td className="px-4 py-3">
                    {order.cart.reduce((acc, item) => acc + item.quantity, 0)}
                  </td>
                  <td className="px-4 py-3">{toKwacha(order.totalPrice)}</td>
                  <td className="px-4 py-3">
                    <Link
                      to={`/order/${order._id}`}
                      className="text-blue-600 hover:text-blue-800"
                    >
                      <AiOutlineArrowRight size={20} />
                    </Link>
                  </td>
                </tr>
              ))
            ) : (
              <tr>
                <td colSpan={5} className="text-center py-4 text-gray-500">
                  No orders found.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default DashboardHero;
