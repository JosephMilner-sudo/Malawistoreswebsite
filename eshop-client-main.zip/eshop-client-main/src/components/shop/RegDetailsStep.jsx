import React from "react";
import { useShopFormContext } from "../../hooks/useShopFormContext";
import styles from "../../styles/styles";

const RegDetailsStep = () => {
  const { formData, handleChange, errors, handleNext, handleBack } =
    useShopFormContext();

  return (
    <div className="w-full max-w-xl bg-white shadow-md mt-5">
      <div className="bg-primary text-white w-full px-5 py-3">
        <h2 className="text-xl font-bold">Business Registration Details</h2>
      </div>

      <div className="p-6">
        {/* Input Fields Grid */}
        <div className="flex flex-col gap-6">
          {/* Business Type */}
          <div>
            <label className="block text-sm font-medium text-gray-700">
              Business Type <span className="text-red-500">*</span>
            </label>
            <select
              className={`${styles.input} focus:outline-none focus:ring-2 focus:ring-yellow-500`}
              value={formData.businessRegDetails.businessType}
              onChange={(e) =>
                handleChange("businessRegDetails", {
                  businessType: e.target.value,
                })
              }
            >
              <option value="">Select business type</option>
              <option value="sole-proprietor">Sole Proprietor</option>
              <option value="partnership">Partnership</option>
              <option value="company">Company</option>
            </select>
            {errors?.businessRegDetails?.businessType && (
              <p className="text-red-500 text-sm">
                {errors.businessRegDetails.businessType}
              </p>
            )}
          </div>

          {/* TIN Certificate Upload */}
          <div>
            <label className="block text-sm font-medium text-gray-700">
              Upload TIN Certificate <span className="text-red-500">*</span>
            </label>
            <input
              type="file"
              className={`${styles.input} focus:outline-none focus:ring-2 focus:ring-yellow-500`}
              onChange={(e) =>
                handleChange("businessRegDetails", {
                  tinCertificate: e.target.files[0],
                })
              }
            />
            {errors?.businessRegDetails?.tinCertificate && (
              <p className="text-red-500 text-sm">
                {errors.businessRegDetails.tinCertificate}
              </p>
            )}
          </div>

          {/* Registration Certificate Upload */}
          <div className="lg:col-span-2">
            <label className="block text-sm font-medium text-gray-700">
              Upload Registration Certificate{" "}
              <span className="text-red-500">*</span>
            </label>
            <input
              type="file"
              className={`${styles.input} focus:outline-none focus:ring-2 focus:ring-yellow-500`}
              onChange={(e) =>
                handleChange("businessRegDetails", {
                  registrationCertificate: e.target.files[0],
                })
              }
            />
            {errors?.businessRegDetails?.registrationCertificate && (
              <p className="text-red-500 text-sm">
                {errors.businessRegDetails.registrationCertificate}
              </p>
            )}
          </div>
        </div>

        {/* Navigation Buttons */}
        <div className="flex justify-between mt-6">
          <button
            className="px-4 py-2 bg-gray-500 text-white rounded-md hover:bg-gray-600 transition"
            onClick={handleBack}
          >
            Back
          </button>
          <button
            className="px-4 py-2 bg-yellow-600 text-white rounded-md hover:bg-yellow-700 transition"
            onClick={handleNext}
          >
            Next
          </button>
        </div>
      </div>
    </div>
  );
};

export default RegDetailsStep;
