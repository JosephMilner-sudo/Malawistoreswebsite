import React from "react";
import { useShopFormContext } from "./../../hooks/useShopFormContext";
import BasicDetailsStep from "./BasicDetailsStep";
import ContactDetailsStep from "./ContactDetailsStep";
import RegDetailsStep from "./RegDetailsStep";
import OwnerDetailsStep from "./OwnerDetailsStep";
import SecurityDetailsStep from "./SecurityDetailsStep";
import ConfirmationStep from "./ConfirmationStep";
import { Link } from "react-router-dom";
import { Logo } from "../../static/data";

const ShopCreate = () => {
  const { currentStep } = useShopFormContext();
  const totalSteps = 6;

  return (
    <div className="flex flex-col items-center w-full mb-10 p-2">
      {/* Centered and margin-added Header */}
      <div className="mt-4 mb-6 flex justify-between items-center w-full 800px:px-[150px] px-3">
        <Link to={"/"} className="">
          <img
            src={Logo}
            alt="Logo"
            className="w-[60px] h-[60px] object-cover"
          />
        </Link>
        <h2 className="text-center 800px:text-2xl text-lg font-bold">
          Create a Shop
        </h2>
        <Link
          to={"/login-shop"}
          className="px-4 py-2 border border-yellow-500 rounded bg-white shadow-lg font-[500]"
        >
          Login
        </Link>
      </div>

      {/* Step Indicator */}
      <div className="mb-4 w-full max-w-[80%]">
        <p className="mb-2 text-lg">
          Step {currentStep} of {totalSteps}
        </p>
        <div className="w-full h-2 bg-white rounded border border-yellow-500">
          <div
            className="h-2 bg-yellow-600 rounded"
            style={{ width: `${(currentStep / totalSteps) * 100}%` }}
          />
        </div>
      </div>

      {/* Show Current Step */}
      {currentStep === 1 && <BasicDetailsStep />}
      {currentStep === 2 && <ContactDetailsStep />}
      {currentStep === 3 && <RegDetailsStep />}
      {currentStep === 4 && <OwnerDetailsStep />}
      {currentStep === 5 && <SecurityDetailsStep />}
      {currentStep === 6 && <ConfirmationStep />}
    </div>
  );
};

export default ShopCreate;
