import React, { useEffect, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { toast } from "react-toastify";
import { loadUser, updateUserInfo } from "../../redux/actions/user";
import axios from "axios";
import { backendUrl, server } from "../../server";
import { BiCamera } from "react-icons/bi";
import styles from "../../styles/styles";
import { AiFillEye, AiFillEyeInvisible } from "react-icons/ai";
import Spinner from "../Spinner";

const Profile = () => {
  const { user, error, success } = useSelector((state) => state.user);
  const dispatch = useDispatch();

  const [name, setName] = useState(user?.name || "");
  const [email, setEmail] = useState(user?.email || "");
  const [phoneNumber, setPhoneNumber] = useState(user?.phoneNumber || "");
  const [avatar, setAvatar] = useState(null);
  const [password, setPassword] = useState("");
  const [togglePassword, setTogglePassword] = useState(false);

  useEffect(() => {
    if (error) {
      toast.error(error);
    }
    if (success) {
      toast.success("User information updated successfully");
      dispatch({type: "ResetSuccess"})
    }
  }, [error, success]);

  const handleSubmit = async (e) => {
    e.preventDefault();

    dispatch(
      updateUserInfo({ email, password, phoneNumber, name, id: user?._id })
    );
  };

  const handleImage = async (e) => {
    const file = e.target.files[0];
    if (!file) return;

    setAvatar(file);

    const formData = new FormData();
    formData.append("image", file);

    try {
      await axios.put(`${server}/user/update-avatar`, formData, {
        headers: {
          "Content-Type": "multipart/form-data",
        },
        withCredentials: true,
      });
      toast.success("Avatar updated successfully!");
      setTimeout(() => {
        dispatch(loadUser());
      }, 1500);
    } catch (err) {
      toast.error(err?.response?.data?.message || "Error updating avatar.");
    }
  };

  if (!user) {
    return <Spinner />;
  }

  return (
    <div>
      <div className="w-full flex justify-center">
        <div className="relative">
          <img
            src={backendUrl + "/" + user?.avatar}
            alt="Profile"
            className="w-[140px] h-[140px] rounded-full border-[2px] border-yellow-500 object-cover"
          />
          <div className="absolute bottom-3 right-0 bg-white rounded-full p-2 shadow-md cursor-pointer border">
            <input
              type="file"
              id="image"
              className="hidden"
              accept="image/*"
              onChange={handleImage}
            />
            <label htmlFor="image" className="cursor-pointer">
              <BiCamera size={20} />
            </label>
          </div>
        </div>
      </div>

      <div className="mt-9 w-full px-4">
        <form
          onSubmit={handleSubmit}
          className="w-full flex flex-col gap-4 items-start"
        >
          <div className="w-full flex 800px:flex-row flex-col 800px:gap-1 gap-4">
            <div className="800px:w-[50%] w-[95%] block">
              <label htmlFor="name">Full name</label>
              <input
                type="text"
                required
                className={`${styles.input} mt-[1px] !w-[95%]`}
                value={name}
                onChange={(e) => setName(e.target.value)}
              />
            </div>
            <div className="800px:w-[50%] w-[95%] block">
              <label htmlFor="name">Email address</label>
              <input
                required
                type="email"
                className={`${styles.input} !w-[95%] mt-[1px]`}
                value={email}
                onChange={(e) => setEmail(e.target.value)}
              />
            </div>
          </div>

          <div className="w-full flex 800px:flex-row flex-col 800px:gap-1 gap-4">
            <div className="800px:w-[50%] w-[95%] block">
              <label htmlFor="phone">Phone number</label>
              <input
                type="text"
                required
                className={`${styles.input} mt-[1px] !w-[95%]`}
                value={phoneNumber}
                onChange={(e) => setPhoneNumber(e.target.value)}
              />
            </div>
            <div className="800px:w-[50%] w-[95%] block relative">
              <label htmlFor="password">Password</label>
              <input
                type={togglePassword ? "text" : "password"}
                className={`${styles.input} !w-[95%] mt-[1px]`}
                value={password}
                required
                onChange={(e) => setPassword(e.target.value)}
              />
              {togglePassword ? (
                <AiFillEye
                  size={20}
                  className="absolute right-9 top-9 cursor-pointer"
                  onClick={() => setTogglePassword(false)}
                />
              ) : (
                <AiFillEyeInvisible
                  size={20}
                  className="absolute right-9 top-9 cursor-pointer"
                  onClick={() => setTogglePassword(true)}
                />
              )}
            </div>
          </div>

          <button
            className="px-5 py-2 border border-green-500 rounded-md bg-white shadow-sm"
            type="submit"
          >
            Update
          </button>
        </form>
      </div>
    </div>
  );
};

export default Profile;
