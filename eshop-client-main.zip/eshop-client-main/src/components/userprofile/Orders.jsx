import { useEffect, useState } from "react";
import { AiOutlineArrowRight } from "react-icons/ai";
import { useDispatch, useSelector } from "react-redux";
import { Link } from "react-router-dom";
import { getAllOrdersForUser } from "../../redux/actions/order";
import { toKwacha } from "../../utils/toKwacha.jsx";
import { Spinner } from "../../components";

const useIsMobile = () => {
  const [isMobile, setIsMobile] = useState(window.innerWidth <= 768);

  useEffect(() => {
    const handleResize = () => setIsMobile(window.innerWidth <= 768);
    window.addEventListener("resize", handleResize);
    return () => window.removeEventListener("resize", handleResize);
  }, []);

  return isMobile;
};

const AllOrders = () => {
  const { orders, loading } = useSelector((state) => state.order);
  const dispatch = useDispatch();
  const { user } = useSelector((state) => state.user);
  const isMobile = useIsMobile();
  const [search, setSearch] = useState("");

  useEffect(() => {
    if (user) {
      dispatch(getAllOrdersForUser(user._id));
    }
  }, [user, dispatch]);

  const filteredOrders = orders?.filter((order) => {
    const searchLower = search.toLowerCase();
    return (
      order._id.toLowerCase().includes(searchLower) ||
      order.status.toLowerCase().includes(searchLower)
    );
  });

  if (loading) return <Spinner />;

  return (
    <div className="px-4 pt-2">
      <h1 className="text-center font-semibold text-lg mb-4">Your Orders</h1>

      <div className="max-w-md mx-auto mb-4">
        <input
          type="text"
          placeholder="Search by Order ID or Status..."
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          className="w-full border border-gray-300 rounded-md px-4 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
        />
      </div>

      {!orders || filteredOrders.length === 0 ? (
        <p className="text-center text-gray-500">No orders found.</p>
      ) : isMobile ? (
        <div className="flex flex-col gap-4">
          {filteredOrders.map((order) => (
            <div
              key={order._id}
              className="bg-white shadow rounded-lg p-4 border hover:shadow-md transition"
            >
              <div className="flex justify-between text-sm mb-2">
                <span className="text-gray-600">Order ID:</span>
                <span className="font-medium">{order._id}</span>
              </div>
              <div className="flex justify-between text-sm mb-2">
                <span className="text-gray-600">Status:</span>
                <span
                  className={`font-semibold ${
                    order.status === "Delivered"
                      ? "text-green-600"
                      : "text-red-500"
                  }`}
                >
                  {order.status}
                </span>
              </div>
              <div className="flex justify-between text-sm mb-2">
                <span className="text-gray-600">Items:</span>
                <span>{order.cart.length}</span>
              </div>
              <div className="flex justify-between text-sm mb-4">
                <span className="text-gray-600">Total Price:</span>
                <span className="font-medium">
                  {toKwacha(order.totalPrice)}
                </span>
              </div>
              <Link to={`/user/order/${order._id}`}>
                <button className="w-full bg-blue-600 text-white py-2 rounded-md flex items-center justify-center gap-2 hover:bg-blue-700 transition">
                  View Details <AiOutlineArrowRight />
                </button>
              </Link>
            </div>
          ))}
        </div>
      ) : (
        <div className="overflow-x-auto">
          <table className="min-w-full bg-white border border-gray-200 rounded-lg overflow-hidden">
            <thead className="bg-gray-100">
              <tr className="text-left text-sm font-semibold text-gray-700">
                <th className="p-3">Order ID</th>
                <th className="p-3">Status</th>
                <th className="p-3">Items</th>
                <th className="p-3">Total Price</th>
                <th className="p-3 text-center">Action</th>
              </tr>
            </thead>
            <tbody>
              {filteredOrders.map((order) => (
                <tr
                  key={order._id}
                  className="border-t border-gray-200 hover:bg-gray-50 text-sm"
                >
                  <td className="p-3">{order._id}</td>
                  <td className="p-3">
                    <span
                      className={`font-medium ${
                        order.status === "Delivered"
                          ? "text-green-600"
                          : "text-red-500"
                      }`}
                    >
                      {order.status}
                    </span>
                  </td>
                  <td className="p-3">{order.cart.length}</td>
                  <td className="p-3">{toKwacha(order.totalPrice)}</td>
                  <td className="p-3 text-center">
                    <Link to={`/user/order/${order._id}`}>
                      <button className="bg-blue-600 text-white py-1 px-3 rounded-md flex items-center justify-center gap-1 hover:bg-blue-700 transition">
                        View <AiOutlineArrowRight size={16} />
                      </button>
                    </Link>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
};

export default AllOrders;
