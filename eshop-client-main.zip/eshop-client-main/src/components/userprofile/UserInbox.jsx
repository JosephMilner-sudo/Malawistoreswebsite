import axios from "axios";
import React, { useEffect, useRef, useState } from "react";
import { useSelector } from "react-redux";
import { backendUrl, server, socket } from "../../server";
import { toast } from "react-toastify";
import { Link, useSearchParams } from "react-router-dom";
import { MdArrowBackIos } from "react-icons/md";
import { TfiGallery } from "react-icons/tfi";
import styles from "../../styles/styles";
import { AiOutlineSend } from "react-icons/ai";
import socketIO from "socket.io-client";
import { format } from "timeago.js";
import { Logo } from "../../static/data";
import Spinner from "../Spinner";

const socketId = socketIO(socket, { transports: ["websocket"] });

const UserInbox = () => {
  const { user } = useSelector((state) => state.user);
  const [conversations, setConversations] = useState([]);
  const [open, setOpen] = useState(false);
  const [arrivalMessage, setArrivalMessage] = useState(null);
  const [currentChat, setCurrentChat] = useState(null);
  const [messages, setMessages] = useState([]);
  const [newMessage, setNewMessage] = useState("");
  const [userData, setUserData] = useState(null);
  const [onlineUsers, setOnlineUsers] = useState([]);
  const [onlineStatus, setOnlineStatus] = useState(false);
  const scrollRef = useRef(null);
  const [searchParams] = useSearchParams();
  const conversationId = searchParams.get("conversationId");
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (conversationId && conversationId !== "") {
      if (conversations?.length > 0) {
        setCurrentChat(
          conversations.find((conv) => conv._id === conversationId)
        );
        setOpen(true);
      }
    }
  }, [conversationId, conversations]);

  useEffect(() => {
    if (user) {
      console.log(user);
      socketId.emit("addUser", user?._id);
      socketId.on("getUsers", (users) => {
        setOnlineUsers(users);
      });
    }
  }, [user]);

  useEffect(() => {
    const handleGetMessage = (data) => {
      setArrivalMessage({
        sender: data.sender,
        text: data.text,
        createdAt: Date.now(),
        conversationId: data.conversationId,
      });
    };

    const handleNewMessage = (data) => {
      if (currentChat?._id === data.conversationId) {
        setMessages((prev) => [...prev, data]);
      }
    };

    const handleGetLastMessage = (data) => {
      setConversations((prevConversations) =>
        prevConversations.map((conv) =>
          conv._id === data.conversationId &&
          conv.lastMessage !== data.lastMessage
            ? {
                ...conv,
                lastMessage: data.lastMessage,
                lastMessageId: data.lastMessageId,
              }
            : conv
        )
      );

      // Avoid unnecessary `currentChat` updates
      if (
        currentChat?._id === data.conversationId &&
        currentChat.lastMessage !== data.lastMessage
      ) {
        setCurrentChat((prev) => ({
          ...prev,
          lastMessage: data.lastMessage,
          lastMessageId: data.lastMessageId,
        }));
      }
    };

    socketId.off("getLastMessage", handleGetLastMessage);
    socketId.off("getMessage", handleGetMessage);
    socketId.off("newMessage", handleNewMessage);

    socketId.on("getMessage", handleGetMessage);
    socketId.on("newMessage", handleNewMessage);
    socketId.on("getLastMessage", handleGetLastMessage);

    return () => {
      socketId.off("getLastMessage", handleGetLastMessage);
      socketId.off("getMessage", handleGetMessage);
      socketId.off("newMessage", handleNewMessage);
    };
  }, [currentChat]);

  useEffect(() => {
    if (
      arrivalMessage &&
      currentChat?.members.includes(arrivalMessage.sender) &&
      arrivalMessage.sender !== user?._id // Ignore own messages
    ) {
      setMessages((prev) => [...prev, arrivalMessage]);
    }
  }, []);

  useEffect(() => {
    const getConversations = async () => {
      try {
        setLoading(true);
        const res = await axios.get(
          `${server}/conversation/get-user-conversations/${user?._id}`,
          { withCredentials: true }
        );
        setConversations(res.data.conversations);
      } catch (err) {
        toast.error(err.response?.data?.message);
      } finally {
        setLoading(false);
      }
    };
    getConversations();
  }, [user?._id]);

  useEffect(() => {
    const getMessages = async () => {
      try {
        if (!currentChat?._id || messages.length > 0) return; // Prevent redundant API calls
        setLoading(true);
        const res = await axios.get(
          `${server}/message/get-all-messages/${currentChat._id}`
        );
        setMessages(res.data.messages);
        socketId.emit("joinConversation", currentChat._id);
      } catch (err) {
        toast.error(err.response?.data?.message);
      } finally {
        setLoading(false);
      }
    };
    getMessages();
  }, [currentChat]);

  useEffect(() => {
    if (user) {
      socketId.emit("addUser", user?._id);
      socketId.on("getUsers", (users) => {
        setOnlineUsers(users);
      });
    }
  }, [user]);

  useEffect(() => {
    scrollRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages, open]);

  const sendMessageHandler = async (e) => {
    e.preventDefault();
    if (!newMessage.trim() || !currentChat) return;

    const message = {
      sender: user?._id,
      text: newMessage,
      conversationId: currentChat._id,
    };

    const receiverId = currentChat.members.find(
      (member) => member !== user?._id
    );

    try {
      // Socket emit first
      socketId.emit("sendMessage", {
        sender: user?._id,
        receiverId,
        text: newMessage,
        conversationId: currentChat?._id,
      });

      // Save to database
      await axios.post(`${server}/message/create-message`, message);

      //setMessages((prev) => [...prev, res.data.message]);

      // Update last message
      await axios.put(
        `${server}/conversation/update-last-message/${currentChat._id}`,
        {
          lastMessage: newMessage,
          lastMessageId: user._id,
        }
      );

      socketId.emit("updateLastMessage", {
        lastMessage: newMessage,
        lastMessageId: user._id,
        conversationId: currentChat._id,
      });

      setNewMessage("");
    } catch (err) {
      toast.error("Failed to send message");
    }
  };

  const onlineUserCheck = (chat) => {
    const chatMembers = chat.members.find((member) => member !== user?._id);
    const online = onlineUsers.find((user) => user.userId === chatMembers);

    return online ? true : false;
  };

  return (
    <>
      {/* <Header /> */}
      <div className="relative font-Poppins 800px:max-w-[1140px] m-auto">
        {!open && (
          <div className="flex justify-between items-center p-2 bg-white">
            <Link to={"/"}>
              <img
                src={Logo}
                alt="Logo"
                className="w-[60px] h-[55px] object-cover"
              />
            </Link>
            <h1
              className="text-center cursor-pointer py-4 md:text-xl text-lg font-[600]"
              onClick={() => {
                window.location.reload();
              }}
            >
              Chat Box
            </h1>
            <Link to={"/profile"} title="Back to your profile">
              <img
                alt="Profile"
                src={backendUrl + "/" + user?.avatar}
                className="border border-primary rounded-full w-[60px] h-[60px] object-cover"
              />
            </Link>
          </div>
        )}

        <div className="w-full border-t h-full">
          {!open && (
            <>
              {" "}
              {conversations &&
                conversations.map((chat, index) => {
                  return (
                    <ChatList
                      chat={chat}
                      key={index}
                      loading={loading}
                      setOpen={setOpen}
                      setCurrentChat={setCurrentChat}
                      user={user}
                      setLoading={setLoading}
                      setUserData={setUserData}
                      online={onlineUserCheck(chat)}
                      setOnlineStatus={setOnlineStatus}
                      me={user?._id}
                    />
                  );
                })}
            </>
          )}
        </div>

        {open && (
          <Inbox
            setOpen={setOpen}
            loading={loading}
            newMessage={newMessage}
            setNewMessage={setNewMessage}
            sendMessageHandler={sendMessageHandler}
            messages={messages}
            me={user?._id}
            user={userData}
            onlineStatus={onlineStatus}
            scrollRef={scrollRef}
          />
        )}
      </div>
    </>
  );
};

const ChatList = ({
  chat,
  key,
  setOpen,
  setCurrentChat,
  me,
  setUserData,
  online,
  setOnlineStatus,
  loading,
  setLoading,
}) => {
  const [active, setActive] = useState(0);
  const [shop, setShop] = useState([]);

  useEffect(() => {
    setOnlineStatus(online);

    const shopId = chat?.members?.find((user) => user !== me);

    const getUser = async () => {
      setLoading(true);
      await axios
        .get(`${server}/shop/get-shop-info/${shopId}`, {
          withCredentials: true,
        })
        .then((res) => {
          setLoading(false);
          setShop(res.data.shop);
          setUserData(res.data.shop);
        })
        .catch((err) => {
          setLoading(false);
          toast.error(err.response.data.message);
        });
    };

    getUser();
  }, [chat, me]);

  const handleClick = () => {
    setOpen(true);
  };

  if (loading) {
    return <Spinner />;
  } else {
    return (
      <div
        className={`flex w-full gap-2 p-2 items-center border-t border-white cursor-pointer hover:bg-white py-4 ${
          active === key ? "bg-gray-200" : " bg-gray-200"
        }`}
        onClick={() =>
          setActive(key) ||
          handleClick(chat?._id) ||
          setCurrentChat(chat) ||
          setUserData(shop) ||
          setOnlineStatus(online)
        }
      >
        <div className="w-[60px] h-[60px] relative">
          <img
            src={`${backendUrl}/${shop?.logo}`}
            alt=""
            className="w-full h-full object-cover rounded-full"
          />
          {online ? (
            <div className="absolute rounded-full p-2 bg-green-600 top-[1px] right-[1px]" />
          ) : (
            <div className="absolute rounded-full p-2 bg-gray-200 top-[1px] right-[1px]" />
          )}
        </div>

        <div className="flex-1 flex flex-col gap-1">
          <h4 className="font-[500]">{shop?.name}</h4>
          <p className="text-primary text-sm">
            {chat.lastMessageId === shop?._id
              ? `${shop?.name?.split(" ")[0]}: `
              : "You:"}{" "}
            {chat?.lastMessage?.length > 25
              ? chat?.lastMessage?.slice(0, 25) + "..."
              : chat?.lastMessage}
          </p>
        </div>
      </div>
    );
  }
};

const Inbox = ({
  setOpen,
  newMessage,
  setNewMessage,
  sendMessageHandler,
  messages,
  scrollRef,
  user,
  me,
  onlineStatus,
  loading,
}) => {
  return (
    <div className="w-full flex flex-col min-h-full pb-2 relative">
      <div className="flex w-full items-center justify-between p-2 border-b gap-4 bg-slate-200 sticky top-0 left-0">
        <div className="cursor-pointer" onClick={() => setOpen(false)}>
          <MdArrowBackIos size={24} />
        </div>
        <div className="flex gap-2 items-center flex-1">
          <Link to={`/seller/${user?._id}`}>
            {" "}
            <img
              src={`${backendUrl}/${user?.logo}`}
              alt=""
              className="object-cover rounded-full w-[60px] h-[60px]"
            />
          </Link>
          <div>
            <h4>{user?.name}</h4>
            <h5 className="text-gray-500">
              {onlineStatus ? "Active now" : ""}
            </h5>
          </div>
        </div>
      </div>

      {loading ? (
        <Spinner />
      ) : (
        <div className="flex-1 p-4 overflow-y-auto flex flex-col gap-4">
          {messages && messages.length > 0 ? (
            messages.map((message, index) => (
              <div key={index} ref={scrollRef}>
                <div
                  className={`flex items-center gap-1 w-full ${
                    message?.sender === me ? " justify-end" : "justify-start"
                  }`}
                >
                  {message.sender !== me && (
                    <Link to={`/seller/${user?._id}`}>
                      <img
                        src={`${backendUrl}/${user?.logo}`}
                        alt="Mike"
                        className="rounded-full w-[50px] h-[50px] border border-slate-500 object-cover"
                      />
                    </Link>
                  )}
                  <div className="flex flex-col gap-1">
                    <div
                      className={`px-4 py-2 max-w-[%] whitespace-pre-wrap break-all ${
                        message.sender !== me
                          ? "bg-slate-200 self-start"
                          : "bg-green-300 self-end"
                      } rounded`}
                    >
                      {message?.text}
                    </div>

                    <p className="text-sm text-gray-500 text-right pr-2">
                      {format(message?.createdAt)}
                    </p>
                  </div>
                </div>
              </div>
            ))
          ) : (
            <div className="h-full w-full flex items-center justify-center">
              <h1 className="text-lg font-[500]">No messages in chat</h1>
            </div>
          )}
        </div>
      )}

      <form
        className="px-3 sticky bottom-1 left-0 z-60 bg-white flex gap-2 items-center"
        onSubmit={sendMessageHandler}
      >
        <div className="">
          <input type="file" name="" id="images" hidden accept="image/*" />
          <label htmlFor="images">
            {" "}
            <TfiGallery size={20} />
          </label>
        </div>
        <div className="flex-1">
          <input
            className={`${styles.input} !pr-10`}
            type="text"
            name=""
            value={newMessage}
            onChange={(e) => setNewMessage(e.target.value)}
            placeholder="Enter your message ..."
          />
          <input type="submit" id="submit" hidden />
          <label
            className="absolute right-5 top-3 cursor-pointer z-20"
            htmlFor="submit"
          >
            <AiOutlineSend size={20} />
          </label>
        </div>
      </form>
    </div>
  );
};

export default UserInbox;
