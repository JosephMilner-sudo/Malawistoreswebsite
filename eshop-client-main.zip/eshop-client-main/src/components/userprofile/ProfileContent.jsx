import React from "react";
import Addresses from "./Addresses";
import PaymentMethods from "./PaymentMethods";
import AllOrders from "./Orders";
import Refunds from "./Refunds";
import TrackOrder from "./TrackOrder";
import Profile from "./Profile";
import UpdatePassword from "./UpdatePassword";
import UserInbox from "./UserInbox";

const ProfileContent = ({ active }) => {
  return (
    <div className="w-full 800px:ml-0 ml-[40px]">
      {active === 1 && <Profile />}

      {active === 2 && (
        <div>
          <AllOrders />
        </div>
      )}

      {active === 3 && (
        <div>
          <Refunds />
        </div>
      )}

      {active === 4 && (
        <div>
          <UserInbox />
        </div>
      )}

      {active === 5 && (
        <div>
          <TrackOrder />
        </div>
      )}

      {active === 6 && (
        <div>
          <PaymentMethods />
        </div>
      )}

      {active === 7 && (
        <div>
          <Addresses />
        </div>
      )}

      {active === 8 && (
        <div>
          <UpdatePassword />
        </div>
      )}
    </div>
  );
};

export default ProfileContent;
