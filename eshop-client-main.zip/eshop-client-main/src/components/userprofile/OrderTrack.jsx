import React, { useEffect } from "react";
import { useDispatch, useSelector } from "react-redux";
import { getAllOrdersForUser } from "./../../redux/actions/order.js";
import { useParams } from "react-router-dom";

const OrderTrack = () => {
  const { orders } = useSelector((state) => state.order);
  const { user } = useSelector((state) => state.user);
  const dispatch = useDispatch();
  const { orderId } = useParams();

  useEffect(() => {
    dispatch(getAllOrdersForUser(user._id));
  }, [dispatch, user._id]);

  const data = orders && orders.find((item) => item._id === orderId);

  const statusMessages = {
    Processing: "Your order is currently being processed in the shop.",
    "Transferred to delivery partner":
      "Your order is on its way to the delivery partner.",
    Shipping: "Your order is on the way with our delivery partner.",
    Received:
      "Your order has arrived in your city. Our delivery man will deliver it soon.",
    "On the way": "Our delivery man is on the way to deliver your order.",
    Delivered: "Your order has been successfully delivered!",
    "Processing Refund": "Your refund is currently being processed.",
    "Refund Successful": "Your refund has been successfully processed!",
  };

  return (
    <div className="w-full h-[80vh] flex justify-center items-center bg-gray-50">
      <div className="bg-white p-6 rounded-lg shadow-lg w-[80%] max-w-3xl text-center">
        {data ? (
          <h1 className="text-2xl font-semibold text-gray-800">
            {statusMessages[data.status] ||
              "Status unknown, please check back later."}
          </h1>
        ) : (
          <h1 className="text-xl font-semibold text-gray-700">
            Order details could not be found.
          </h1>
        )}
      </div>
    </div>
  );
};

export default OrderTrack;
