import { AiOutlineDelete } from "react-icons/ai";
import { BiLogoVisa } from "react-icons/bi";
import { CgAdd } from "react-icons/cg";

const PaymentMethods = () => {
  return (
    <div className="w-full px-5">
      <div className="w-full flex justify-between items-center">
        <h1 className="text-lg font-[600]">Payment History</h1>
      </div>

      <div className="mt-6 w-full">
        <div className="w-full bg-white rounded-md border justify-between 800px:flex-row flex-col py-5 px-7 flex items-center pr-10 800px:gap-1 gap-4 ">
          <div className="flex gap-6 items-center">
            <BiLogoVisa size={36} color="blue" />
            <h3 className="font-semibold">TransId: <span className="font-light">20203030</span></h3>
          </div>

          <div className="flex gap-4 items-center">
            <p>4500 **** **** ****</p>
            <p>08/25</p>
          </div>

          <div>
            <button>
              <AiOutlineDelete color="red" size={24} />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default PaymentMethods;
