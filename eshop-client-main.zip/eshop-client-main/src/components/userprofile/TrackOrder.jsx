import { useEffect, useState } from "react";
import { MdTrackChanges } from "react-icons/md";
import { useDispatch, useSelector } from "react-redux";
import { Link } from "react-router-dom";
import { getAllOrdersForUser } from "../../redux/actions/order";
import { toKwacha } from "../../utils/toKwacha";
import Spinner from "../Spinner";

const TrackOrder = () => {
  const { orders, loading } = useSelector((state) => state.order);
  const dispatch = useDispatch();
  const { user } = useSelector((state) => state.user);
  const [isMobile, setIsMobile] = useState(window.innerWidth <= 768);
  const [searchQuery, setSearchQuery] = useState("");

  useEffect(() => {
    if (user) {
      dispatch(getAllOrdersForUser(user?._id));
    }
  }, [user, dispatch]);

  useEffect(() => {
    const handleResize = () => {
      setIsMobile(window.innerWidth <= 768);
    };
    window.addEventListener("resize", handleResize);
    return () => window.removeEventListener("resize", handleResize);
  }, []);

  const filteredOrders = orders?.filter((order) => {
    const search = searchQuery.toLowerCase();
    return (
      order._id.toLowerCase().includes(search) ||
      order.status.toLowerCase().includes(search)
    );
  });

  return (
    <>
      {loading ? (
        <Spinner />
      ) : (
        <div className="pl-4 pr-4 pt-1">
          <h1 className="text-center font-semibold text-lg mb-4">
            Track Orders
          </h1>

          <div className="mb-4 max-w-md mx-auto">
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search by Order ID or Status..."
              className="w-full px-4 py-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-indigo-500"
            />
          </div>

          {!orders ? (
            <p className="text-center text-gray-500">Loading...</p>
          ) : isMobile ? (
            <div className="flex flex-col gap-4">
              {filteredOrders?.length > 0 ? (
                filteredOrders.map((order) => (
                  <div
                    key={order._id}
                    className="bg-white shadow rounded-lg p-4 border hover:shadow-md transition"
                  >
                    <div className="flex justify-between text-sm mb-2">
                      <span className="text-gray-600">Order ID:</span>
                      <span className="font-medium">{order._id}</span>
                    </div>
                    <div className="flex justify-between text-sm mb-2">
                      <span className="text-gray-600">Status:</span>
                      <span
                        className={`font-semibold ${
                          order.status === "Delivered"
                            ? "text-green-600"
                            : "text-red-600"
                        }`}
                      >
                        {order.status}
                      </span>
                    </div>
                    <div className="flex justify-between text-sm mb-2">
                      <span className="text-gray-600">Items:</span>
                      <span>{order.cart?.length}</span>
                    </div>
                    <div className="flex justify-between text-sm mb-4">
                      <span className="text-gray-600">Total:</span>
                      <span className="font-medium">
                        {toKwacha(order.totalPrice)}
                      </span>
                    </div>
                    <Link to={`/user/track/order/${order._id}`}>
                      <button className="bg-indigo-600 hover:bg-indigo-700 text-white text-sm font-medium py-2 px-4 rounded flex items-center justify-center w-full gap-2">
                        <MdTrackChanges />
                        Track Order
                      </button>
                    </Link>
                  </div>
                ))
              ) : (
                <p className="text-center text-gray-500">
                  No matching orders found.
                </p>
              )}
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="min-w-full bg-white rounded-lg shadow">
                <thead>
                  <tr className="bg-gray-100 text-left text-sm font-medium text-gray-700">
                    <th className="px-4 py-2">Order ID</th>
                    <th className="px-4 py-2">Status</th>
                    <th className="px-4 py-2">Items Qty</th>
                    <th className="px-4 py-2">Total</th>
                    <th className="px-4 py-2">Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {filteredOrders?.length > 0 ? (
                    filteredOrders.map((order) => (
                      <tr key={order._id} className="border-t text-sm">
                        <td className="px-4 py-2">{order._id}</td>
                        <td className="px-4 py-2 font-semibold text-sm">
                          <span
                            className={
                              order.status === "Delivered"
                                ? "text-green-600"
                                : "text-red-600"
                            }
                          >
                            {order.status}
                          </span>
                        </td>
                        <td className="px-4 py-2">{order.cart?.length}</td>
                        <td className="px-4 py-2">
                          {toKwacha(order.totalPrice)}
                        </td>
                        <td className="px-4 py-2">
                          <Link to={`/user/track/order/${order._id}`}>
                            <button className="bg-indigo-600 hover:bg-indigo-700 text-white text-sm px-3 py-1 rounded flex items-center gap-1">
                              <MdTrackChanges />
                              Track
                            </button>
                          </Link>
                        </td>
                      </tr>
                    ))
                  ) : (
                    <tr>
                      <td
                        colSpan="5"
                        className="text-center py-4 text-gray-500"
                      >
                        No matching orders found.
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
          )}
        </div>
      )}
    </>
  );
};

export default TrackOrder;
