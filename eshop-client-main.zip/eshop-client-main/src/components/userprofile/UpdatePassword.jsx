import { useState } from "react";
import styles from "../../styles/styles";
import { BsEye, BsEyeSlash } from "react-icons/bs";
import { toast } from "react-toastify";
import axios from "axios";
import { server } from "../../server";
import { ClipLoader } from "react-spinners";

const UpdatePassword = () => {
  const formDefaults = {
    oldPassword: "",
    newPassword: "",
    confirmPassword: "",
  };
  const [formData, setFormData] = useState(formDefaults);

  const [loading, setLoading] = useState(false);

  const [showPassword, setShowPassword] = useState({
    oldPassword: false,
    newPassword: false,
    confirmPassword: false,
  });

  const [errors, setErrors] = useState({
    newPassword: "",
    confirmPassword: "",
  });

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));

    // Password validation
    if (
      (name === "newPassword" || name === "confirmPassword") &&
      value.length < 6
    ) {
      setErrors((prev) => ({
        ...prev,
        [name]: "Password must be at least 6 characters.",
      }));
    } else {
      setErrors((prev) => ({ ...prev, [name]: "" }));
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    if (
      formData.newPassword.length < 6 ||
      formData.confirmPassword.length < 6
    ) {
      toast.error("Passwords must be at least 6 characters.");
      return;
    }

    if (formData.newPassword !== formData.confirmPassword) {
      toast.error("New password and confirm password do not match.");
      return;
    }

    setLoading(true);

    await axios
      .put(`${server}/user/update-user-password`, formData, {
        withCredentials: true,
      })
      .then((res) => {
        toast.success(res.data.message);
        setLoading(false);
        setFormData(formDefaults);
      })
      .catch((err) => {
        toast.error(err.response.data.message);
        setLoading(false);
      });
  };

  const togglePasswordVisibility = (field) => {
    setShowPassword((prev) => ({ ...prev, [field]: !prev[field] }));
  };

  return (
    <div className="w-full px-5">
      <div className="w-full flex items-center justify-center">
        <h1 className="text-lg font-[600] text-center">Change Password</h1>
      </div>

      <div className="mt-6 w-full justify-center flex">
        <form
          className="800px:w-[45%] w-[98%] bg-white flex px-3 py-6 gap-4 flex-col"
          onSubmit={handleSubmit}
        >
          {/* Old Password */}
          <div className="w-full relative">
            <label htmlFor="oldPassword">Old Password</label>
            <input
              type={showPassword.oldPassword ? "text" : "password"}
              name="oldPassword"
              className={`${styles.input} pr-10`}
              value={formData.oldPassword}
              onChange={handleChange}
              required
            />
            <span
              className="absolute right-3 top-[60%] cursor-pointer"
              onClick={() => togglePasswordVisibility("oldPassword")}
            >
              {showPassword.oldPassword ? (
                <BsEye size={18} />
              ) : (
                <BsEyeSlash size={18} />
              )}
            </span>
          </div>

          {/* New Password */}
          <div className="w-full relative">
            <label htmlFor="newPassword">New Password</label>
            <input
              type={showPassword.newPassword ? "text" : "password"}
              name="newPassword"
              className={`${styles.input} pr-10`}
              value={formData.newPassword}
              onChange={handleChange}
              required
            />
            <span
              className="absolute right-3 top-[60%] cursor-pointer"
              onClick={() => togglePasswordVisibility("newPassword")}
            >
              {showPassword.newPassword ? (
                <BsEye size={18} />
              ) : (
                <BsEyeSlash size={18} />
              )}
            </span>
            {errors.newPassword && (
              <p className="text-red-500 text-sm">{errors.newPassword}</p>
            )}
          </div>

          {/* Confirm Password */}
          <div className="w-full mt-2 relative">
            <label htmlFor="confirmPassword">
              Confirm/Re-enter the new password
            </label>
            <input
              type={showPassword.confirmPassword ? "text" : "password"}
              name="confirmPassword"
              className={`${styles.input} pr-10`}
              value={formData.confirmPassword}
              onChange={handleChange}
              required
            />
            <span
              className="absolute right-3 top-[60%] cursor-pointer"
              onClick={() => togglePasswordVisibility("confirmPassword")}
            >
              {showPassword.confirmPassword ? (
                <BsEye size={18} />
              ) : (
                <BsEyeSlash size={18} />
              )}
            </span>
            {errors.confirmPassword && (
              <p className="text-red-500 text-sm">{errors.confirmPassword}</p>
            )}
          </div>

          <button
            className={`${styles.button}`}
            type="submit"
            disabled={loading}
          >
            {loading ? <ClipLoader color="white" size={20} /> : "Update"}
          </button>
        </form>
      </div>
    </div>
  );
};

export default UpdatePassword;
