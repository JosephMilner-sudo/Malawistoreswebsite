import { AiOutlineArrowRight } from "react-icons/ai";
import { useDispatch, useSelector } from "react-redux";
import { Link } from "react-router-dom";
import { getAllOrdersForUser } from "../../redux/actions/order";
import { useEffect, useState } from "react";
import { toKwacha } from "../../utils/toKwacha";
import Spinner from "../Spinner";

const Refunds = () => {
  const { orders, loading } = useSelector((state) => state.order);
  const dispatch = useDispatch();
  const { user } = useSelector((state) => state.user);
  const [searchTerm, setSearchTerm] = useState("");

  useEffect(() => {
    if (user) {
      dispatch(getAllOrdersForUser(user._id));
    }
  }, [user, dispatch]);

  const eligibleOrders = orders?.filter(
    (order) => order.status.toLowerCase().includes("refund")
  );

  const filteredOrders = eligibleOrders?.filter((order) => {
    const search = searchTerm.toLowerCase();
    return (
      order._id.toLowerCase().includes(search) ||
      order.status.toLowerCase().includes(search) ||
      toKwacha(order.totalPrice).toLowerCase().includes(search)
    );
  });

  return (
    <div className="p-4">
      {loading ? (
        <Spinner />
      ) : (
        <>
          <h1 className="text-center text-xl font-semibold mb-4">Refunds</h1>

          {/* Search */}
          <div className="mb-4 flex justify-center">
            <input
              type="text"
              placeholder="Search by Order ID, Status, or Total"
              className="border border-gray-300 p-2 rounded-md w-full md:w-1/2"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>

          {/* Responsive layout */}
          <div className="block md:hidden">
            {/* Mobile View */}
            {filteredOrders?.length ? (
              filteredOrders.map((order) => (
                <div
                  key={order._id}
                  className="bg-white p-4 rounded shadow mb-4"
                >
                  <div className="text-sm mb-2">
                    <strong>Order ID:</strong> {order._id}
                  </div>
                  <div className="text-sm mb-2">
                    <strong>Status:</strong>{" "}
                    <span className="text-yellow-600 font-semibold">
                      {order.status}
                    </span>
                  </div>
                  <div className="text-sm mb-2">
                    <strong>Items:</strong> {order.cart?.length}
                  </div>
                  <div className="text-sm mb-4">
                    <strong>Total:</strong> {toKwacha(order.totalPrice)}
                  </div>
                  <Link to={`/user/order/${order._id}`}>
                    <button className="w-full flex justify-center items-center gap-1 bg-indigo-600 text-white py-2 rounded hover:bg-indigo-700 transition">
                      View Details <AiOutlineArrowRight />
                    </button>
                  </Link>
                </div>
              ))
            ) : (
              <p className="text-center text-gray-500">No refunds found.</p>
            )}
          </div>

          <div className="hidden md:block">
            {/* Desktop Table */}
            {filteredOrders?.length ? (
              <div className="overflow-x-auto">
                <table className="min-w-full bg-white shadow rounded">
                  <thead>
                    <tr className="bg-gray-100 text-left text-sm font-semibold text-gray-700">
                      <th className="p-3">Order ID</th>
                      <th className="p-3">Status</th>
                      <th className="p-3">Items Qty</th>
                      <th className="p-3">Total</th>
                      <th className="p-3 text-center">Actions</th>
                    </tr>
                  </thead>
                  <tbody>
                    {filteredOrders.map((order) => (
                      <tr
                        key={order._id}
                        className="border-t hover:bg-gray-50 text-sm"
                      >
                        <td className="p-3">{order._id}</td>
                        <td className="p-3">
                          <span
                            className={`font-semibold ${
                              order.status === "Delivered"
                                ? "text-green-600"
                                : "text-yellow-600"
                            }`}
                          >
                            {order.status}
                          </span>
                        </td>
                        <td className="p-3">{order.cart?.length}</td>
                        <td className="p-3">{toKwacha(order.totalPrice)}</td>
                        <td className="p-3 text-center">
                          <Link to={`/user/order/${order._id}`}>
                            <button className="text-indigo-600 hover:text-indigo-800 transition">
                              <AiOutlineArrowRight size={20} />
                            </button>
                          </Link>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            ) : (
              <p className="text-center text-gray-500">No refunds found.</p>
            )}
          </div>
        </>
      )}
    </div>
  );
};

export default Refunds;
