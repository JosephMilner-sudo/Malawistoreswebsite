import { useEffect, useState } from "react";
import { AiOutlineDelete } from "react-icons/ai";
import { CgAdd, CgClose } from "react-icons/cg";
import { useDispatch, useSelector } from "react-redux";
import { toast } from "react-toastify";
import styles from "./../../styles/styles";
import { Country, State } from "country-state-city";
import {
  deleteUserAddressInfo,
  updateUserAddressInfo,
} from "../../redux/actions/user";

const Addresses = () => {
  const { user, error, success } = useSelector((state) => state.user);
  const [open, setOpen] = useState(false);
  const [country, setCountry] = useState("");
  const [city, setCity] = useState("");
  // const [zipCode, setZipCode] = useState("");
  const [address1, setAddress1] = useState("");
  const [address2, setAddress2] = useState("");
  const [addressType, setAddressType] = useState("");
  const dispatch = useDispatch();

  useEffect(() => {
    if (error) {
      toast.error(error);
      dispatch({ type: "ClearState" });
    }

    if (success) {
      toast.success("Successfully updated");
      dispatch({ type: "ClearState" });
      setOpen(false);

      setCountry("");
      setCity("");
      setAddress1("");
      setAddress2("");
      setAddressType("");
    }
  }, [error, success, dispatch]);

  const addressTypeData = [
    {
      name: "Default",
    },
    {
      name: "Home",
    },
    {
      name: "Office",
    },
  ];

  const handleDelete = (addressId) => {
    dispatch(deleteUserAddressInfo(addressId));
  };

  const handleSubmit = (e) => {
    e.preventDefault();

    if (country === "" || city === "" || addressType === "") {
      toast.error("Please enter all the required fields indicated by *");
    } else {
      //insert to db
      dispatch(
        updateUserAddressInfo({
          country,
          city,
          addressType,
          address1,
          address2,
        })
      );
    }
  };

  return (
    <div className="w-full px-5">
      {open && (
        <div className="fixed w-full h-screen bg-[#0000005b] top-0 left-0 flex items-center justify-center z-20">
          <div className="800px:w-[40%] w-[95%] h-[80vh] bg-white rounded-md p-3 overflow-y-auto">
            <div className="w-full flex justify-between border-b py-2 items-center">
              <h1 className="text-lg font-[500]">New Address</h1>
              <CgClose
                size={30}
                color="red"
                className="cursor-pointer"
                onClick={() => setOpen(false)}
              />
            </div>
            <form
              onSubmit={handleSubmit}
              className="pt-4 px-2 flex flex-col gap-4"
            >
              <div className="flex flex-col">
                <label htmlFor="country">
                  Country <span className="text-red-400">*</span>
                </label>
                <select
                  name="country"
                  id="country"
                  value={country}
                  className={`${styles.input}`}
                  onChange={(e) => setCountry(e.target.value)}
                  required
                >
                  <option value="">Select country</option>
                  {Country &&
                    Country.getAllCountries().map((i) => (
                      <option key={i.isoCode} value={i.isoCode}>
                        {i.name}
                      </option>
                    ))}
                </select>
              </div>
              <div className="flex flex-col">
                <label htmlFor="country">
                  City <span className="text-red-400">*</span>
                </label>
                <select
                  name="city"
                  id="city"
                  value={city}
                  className={`${styles.input}`}
                  onChange={(e) => setCity(e.target.value)}
                  required
                >
                  <option value="">Select City</option>
                  {State &&
                    State.getStatesOfCountry(country).map((i) => (
                      <option key={i.isoCode} value={i.isoCode}>
                        {i.name}
                      </option>
                    ))}
                </select>
              </div>
              <div className="flex flex-col">
                <label>Address 1</label>
                <input
                  name="address1"
                  value={address1}
                  placeholder="Enter you first address"
                  className={`${styles.input}`}
                  onChange={(e) => setAddress1(e.target.value)}
                />
              </div>
              <div className="flex flex-col">
                <label>Address 2</label>
                <input
                  name="address2"
                  value={address2}
                  placeholder="Enter you second address"
                  className={`${styles.input}`}
                  onChange={(e) => setAddress2(e.target.value)}
                />
              </div>
              <div className="flex flex-col">
                <label htmlFor="country">
                  Address Type <span className="text-red-400">*</span>
                </label>
                <select
                  name="addressType"
                  id="addressType"
                  value={addressType}
                  className={`${styles.input}`}
                  onChange={(e) => setAddressType(e.target.value)}
                  required
                >
                  <option value="">Select City</option>
                  {addressTypeData &&
                    addressTypeData.map((i) => (
                      <option key={i.name} value={i.name}>
                        {i.name}
                      </option>
                    ))}
                </select>
              </div>
              <div className="flex items-center justify-center mt-2">
                <button className={`${styles.button}`} type="submit">
                  Submit
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
      <div className="w-full flex justify-between items-center">
        <h1 className="text-lg font-[600]">My Addresses</h1>
        <button
          className="px-4 py-2 bg-yellow-600 text-white flex items-center gap-1 rounded-md"
          onClick={() => setOpen(true)}
        >
          <CgAdd size={20} /> Address
        </button>
      </div>

      {user && user?.addresses?.length > 0 ? (
        user?.addresses.map((address, key) => (
          <div className="mt-6 w-full" key={key}>
            <div className="w-full bg-white rounded-md border justify-between 800px:flex-row flex-col py-5 px-7 flex items-center pr-10 800px:gap-1 gap-4 ">
              <div className="flex items-center">
                <h3 className="font-semibold">{address?.addressType}</h3>
              </div>

              <div className="flex gap-4 items-center">
                <p>{address.address1 + ", " + address.address2}</p>
              </div>

              <div className="flex gap-4 items-center">
                <p>{user?.phoneNumber}</p>
              </div>

              <div>
                <button>
                  <AiOutlineDelete
                    color="red"
                    size={24}
                    onClick={() => handleDelete(address?._id)}
                  />
                </button>
              </div>
            </div>
          </div>
        ))
      ) : (
        <div className="w-full py-10 flex items-center justify-center text-lg font-light text-center">
          <p>
            Addresses not found. <br /> <br /> Click new address button to add
            address
          </p>
        </div>
      )}
    </div>
  );
};

export default Addresses;
