import React, { useEffect, useState } from "react";
import styles from "../../styles/styles";
import { useNavigate, useParams } from "react-router-dom";
import { useDispatch, useSelector } from "react-redux";
import { getAllOrdersForUser } from "../../redux/actions/order";
import { backendUrl, server } from "../../server";
import { toKwacha } from "../../utils/toKwacha";
import { FaShoppingBag } from "react-icons/fa";
import { RxCross1 } from "react-icons/rx";
import { AiOutlineStar, AiFillStar } from "react-icons/ai";
import axios from "axios";
import { toast } from "react-toastify";

const UserOrderDetails = () => {
  const { user } = useSelector((state) => state.user);
  const { orders } = useSelector((state) => state.order);
  const { orderId } = useParams();
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const [open, setOpen] = useState(false);
  const [selectedItem, setSelectedItem] = useState(null);
  const [rating, setRating] = useState(1);
  const [comment, setComment] = useState("");

  useEffect(() => {
    dispatch(getAllOrdersForUser(user?._id));
  }, [dispatch, user]);

  const refundHandler = async () => {
    await axios
      .put(
        `${server}/order/order-refund/${orderId}`,
        { status: "Processing Refund" },
        { withCredentials: true }
      )
      .then((res) => {
        toast.success(res.data.message);
        dispatch(getAllOrdersForUser(user?._id));
      })
      .catch((err) => {
        toast.error(err.response.data.message);
      });
  };

  const handleSubmitReview = async () => {
    await axios
      .put(
        `${server}/product/modify-product-review`,
        { rating, comment, user, productId: selectedItem._id, orderId },
        { withCredentials: true }
      )
      .then((res) => {
        toast.success("Product reviewed successfully");
        dispatch(getAllOrdersForUser(user?._id));
        setComment("");
        setRating(null);
        setOpen(false);
      })
      .catch((err) => {
        console.log(err);
        toast.error(err.response.data.message);
      });
  };

  const data = orders && orders.find((item) => item._id === orderId);

  return (
    <div className={`${styles.section} min-h-screen py-4`}>
      <div className="flex items-center justify-between border-b gap-2 py-4">
        <div className="flex items-center gap-2">
          <FaShoppingBag size={38} className="text-yellow-700" />
          <h1 className="800px:text-xl font-bold">Order Details</h1>
        </div>
        <h3 className="text-gray-500 italic font-light text-sm">
          Status: <span className="font-semibold">{data?.status}</span>
        </h3>
      </div>

      <div className="flex items-center justify-between pt-5  md:text-md text-sm">
        <h5 className="text-gray-500">
          Order ID:{" "}
          <span className="font-semibold">#{data?._id?.slice(0, 8)}</span>
        </h5>
        <h5 className="text-gray-500">
          Placed On:{" "}
          <span className="font-semibold">{data?.createdAt?.slice(0, 10)}</span>
        </h5>
      </div>

      <div className="pt-6">
        {data?.cart?.map((item, index) => (
          <div key={index} className="flex items-center mb-5 border-b pb-4">
            <img
              src={`${backendUrl}/${item.images[0]}`}
              className="w-[80px] h-[80px] object-contain"
              alt={item.name}
            />
            <div className="ml-4 flex-1">
              <h5 className="font-semibold 800px:text-md text-sm">
                {item?.name}
              </h5>
              <h6 className="text-gray-600  800px:text-md text-sm">
                {toKwacha(item?.discountPrice || item?.originalPrice)} x{" "}
                {item.quantity}
              </h6>
            </div>
            {data?.status === "Delivered" && !item?.isReviewed && (
              <button
                className={`${styles.button} ml-4 text-white`}
                onClick={() => {
                  setSelectedItem(item);
                  setOpen(true);
                }}
              >
                Review
              </button>
            )}
          </div>
        ))}
      </div>

      <div className="w-full border-t text-right pt-2  800px:text-md text-sm">
        <h5 className="font-semibold">
          Total Price: <strong>{toKwacha(data?.totalPrice)}</strong>
        </h5>
      </div>

      <div className="pt-5 flex flex-col md:flex-row gap-6  800px:text-md text-sm">
        <div className="w-full md:w-[60%]">
          <h4 className="text-lg font-semibold">Shipping Address</h4>
          <p className="mt-2 text-gray-700">
            {data?.shippingAddress?.address1} {data?.shippingAddress?.address2}
          </p>
          <p className="mt-1 text-gray-700">
            {data?.shippingAddress?.city}, {data?.shippingAddress?.country}
          </p>
          <p className="mt-1 text-gray-700">{data?.user?.phoneNumber}</p>
        </div>
        <div className="w-full md:w-[40%]">
          <h4 className="text-lg font-semibold">Payment Info</h4>
          <p className="mt-2 text-gray-700">Type: {data?.paymentInfo?.type}</p>
          <p className="mt-1 text-gray-700">
            Status: {data?.paymentInfo?.status || "Not Paid"}
          </p>

          {data?.status === "Delivered" && (
            <button
              onClick={refundHandler}
              className={`${styles.button} mt-6 w-full`}
            >
              Request Refund
            </button>
          )}
        </div>
      </div>

      <button
        onClick={() => navigate("/inbox")}
        className={`${styles.button} mt-6 w-full`}
      >
        Send Message
      </button>

      {/* Product review pop-up */}
      {open && (
        <div className="fixed inset-0 flex items-center justify-center bg-black/30 z-50 overflow-auto">
          <div className="bg-white rounded-md w-[90%] md:w-[50%] p-6">
            <div className="flex items-center justify-between">
              <h1 className="text-xl font-bold">Provide a Review</h1>
              <RxCross1
                size={26}
                color="red"
                className="cursor-pointer"
                onClick={() => {
                  setOpen(false);
                  setSelectedItem(null);
                }}
              />
            </div>

            <div className="mt-5 flex items-center gap-4">
              <img
                src={`${backendUrl}/${selectedItem?.images[0]}`}
                className="w-[80px] h-[80px] object-contain"
                alt={selectedItem?.name}
              />
              <p className="flex-1 text-sm">{selectedItem?.name}</p>
            </div>

            <div className="mt-5">
              <h3 className="font-semibold">
                Give a Rating <span className="text-red-500">*</span>
              </h3>
              <div className="flex gap-1 mt-2">
                {[1, 2, 3, 4, 5].map((i) =>
                  rating >= i ? (
                    <AiFillStar
                      key={i}
                      className="text-red-500 cursor-pointer"
                      size={24}
                      onClick={() => setRating(i)}
                    />
                  ) : (
                    <AiOutlineStar
                      key={i}
                      className="cursor-pointer"
                      size={24}
                      onClick={() => setRating(i)}
                    />
                  )
                )}
              </div>
            </div>

            <div className="mt-6">
              <label htmlFor="comment" className="block text-sm font-medium">
                Write a Comment (Optional)
              </label>
              <textarea
                id="comment"
                className={`${styles.input} mt-2`}
                rows={5}
                value={comment}
                onChange={(e) => setComment(e.target.value)}
                placeholder="What do you think about the product?"
              ></textarea>
            </div>

            <button
              onClick={rating > 1 ? handleSubmitReview : null}
              className={`${styles.button} mt-4 w-full`}
            >
              Submit Review
            </button>
          </div>
        </div>
      )}
    </div>
  );
};

export default UserOrderDetails;
