import React, { useEffect, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { getAllOrdersForShop } from "../../redux/actions/order";
import { ClipLoader } from "react-spinners";
import { Link } from "react-router-dom";
import { toast } from "react-toastify";
import { CgArrowRight } from "react-icons/cg";
import { toKwacha } from "../../utils/toKwacha";
import styles from "../../styles/styles";

const AllShopOrders = () => {
  const dispatch = useDispatch();
  const { orders, loading, error } = useSelector((state) => state.order);
  const { shop } = useSelector((state) => state.shop);

  const [searchTerm, setSearchTerm] = useState("");
  const [currentPage, setCurrentPage] = useState(1);
  const [ordersPerPage, setOrdersPerPage] = useState(10);

  useEffect(() => {
    dispatch(getAllOrdersForShop(shop?._id));

    if (error !== "Invalid shopId format") {
      toast.error(error);
    }
  }, []);

  const handleSearch = (e) => {
    setSearchTerm(e.target.value.toLowerCase());
    setCurrentPage(1); // Reset to first page when searching
  };

  const handleOrdersPerPageChange = (e) => {
    const value = parseInt(e.target.value);
    if (!isNaN(value) && value > 0) {
      setOrdersPerPage(value);
      setCurrentPage(1);
    }
  };

  const filteredOrders = orders?.filter((item) => {
    const totalPrice = toKwacha(item.totalPrice).toLowerCase();
    return (
      item._id.toLowerCase().includes(searchTerm) ||
      item.status.toLowerCase().includes(searchTerm) ||
      totalPrice.includes(searchTerm)
    );
  });

  const totalPages = Math.ceil(filteredOrders?.length / ordersPerPage);
  const indexOfLastOrder = currentPage * ordersPerPage;
  const indexOfFirstOrder = indexOfLastOrder - ordersPerPage;
  const currentOrders = filteredOrders?.slice(
    indexOfFirstOrder,
    indexOfLastOrder
  );

  if (loading) {
    return (
      <div className="w-full h-[80vh] flex items-center justify-center">
        <ClipLoader size={100} color="blue" />
      </div>
    );
  }

  return (
    <div className="bg-white w-full pt-1 800px:mt-7 px-2">
      <div className="flex justify-between 800px:flex-row flex-col  gap-4 items-center py-4 pl-2">
        <h1 className="800px:text-xl text-lg font-semibold mb-2 800px:mb-0">
          All Orders
        </h1>

        <input
          type="text"
          placeholder="Search by ID, status, or price..."
          className={`${styles.input} 800px:!w-[40%]`}
          value={searchTerm}
          onChange={handleSearch}
        />

        <div className="flex items-center gap-2">
          <label className="text-sm font-medium">Orders per page:</label>
          <input
            type="number"
            min="1"
            value={ordersPerPage}
            onChange={handleOrdersPerPageChange}
            className={`${styles.input}`}
          />
        </div>
      </div>

      <div className="w-full overflow-x-auto shadow-sm border border-gray-200">
        <table className="min-w-[900px] w-full text-sm text-left text-gray-700">
          <thead className="bg-white border-b">
            <tr className="text-xs font-semibold text-gray-600 uppercase tracking-wider">
              <th className="px-6 py-4 border-r text-left ">Order ID</th>
              <th className="px-6 py-4 text-left border-r">Status</th>
              <th className="px-6 py-4 text-right border-r">Quantity</th>
              <th className="px-6 py-4 text-right border-r">Total Price</th>
              <th className="px-6 py-4 text-center">Action</th>
            </tr>
          </thead>

          <tbody>
            {currentOrders && currentOrders.length > 0 ? (
              currentOrders.map((item) => (
                <tr
                  key={item._id}
                  className="border-b hover:bg-gray-100 transition duration-200"
                >
                  <td className="px-6 py-4 font-medium text-gray-800">
                    {item._id}
                  </td>
                  <td className="px-6 py-4">
                    <span
                      className={`inline-block px-2 py-1 rounded-full text-xs font-medium ${
                        item.status === "Delivered"
                          ? "bg-green-100 text-green-700"
                          : item.status === "Processing"
                          ? "bg-yellow-100 text-yellow-700"
                          : "bg-red-100 text-red-700"
                      }`}
                    >
                      {item.status}
                    </span>
                  </td>
                  <td className="px-6 py-4 text-right">{item?.cart?.length}</td>
                  <td className="px-6 py-4 text-right">
                    {toKwacha(item?.totalPrice)}
                  </td>
                  <td className="px-6 py-4">
                    <Link
                      to={`/order/${item._id}`}
                      className="text-blue-600 hover:text-blue-800 transition w-full flex justify-center"
                    >
                      <CgArrowRight size={22} />
                    </Link>
                  </td>
                </tr>
              ))
            ) : (
              <tr>
                <td colSpan="5" className="px-6 py-8 text-center text-gray-500">
                  No matching orders found.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>

      {filteredOrders && filteredOrders.length > 0 && (
        <div className="flex flex-wrap justify-end items-center mt-4 gap-2">
          <button
            onClick={() => setCurrentPage(1)}
            disabled={currentPage === 1}
            className="px-3 py-1 text-sm bg-gray-200 rounded hover:bg-gray-300 disabled:opacity-50"
          >
            First
          </button>
          <button
            onClick={() => setCurrentPage((prev) => Math.max(prev - 1, 1))}
            disabled={currentPage === 1}
            className="px-3 py-1 text-sm bg-gray-200 rounded hover:bg-gray-300 disabled:opacity-50"
          >
            Prev
          </button>

          {[...Array(totalPages)].map((_, index) => (
            <button
              key={index}
              onClick={() => setCurrentPage(index + 1)}
              className={`px-3 py-1 text-sm rounded ${
                currentPage === index + 1
                  ? "bg-blue-600 text-white"
                  : "bg-gray-100 hover:bg-gray-200"
              }`}
            >
              {index + 1}
            </button>
          ))}

          <button
            onClick={() =>
              setCurrentPage((prev) => Math.min(prev + 1, totalPages))
            }
            disabled={currentPage === totalPages}
            className="px-3 py-1 text-sm bg-gray-200 rounded hover:bg-gray-300 disabled:opacity-50"
          >
            Next
          </button>
          <button
            onClick={() => setCurrentPage(totalPages)}
            disabled={currentPage === totalPages}
            className="px-3 py-1 text-sm bg-gray-200 rounded hover:bg-gray-300 disabled:opacity-50"
          >
            Last
          </button>
        </div>
      )}
    </div>
  );
};

export default AllShopOrders;
