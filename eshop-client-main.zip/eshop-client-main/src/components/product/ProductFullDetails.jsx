import React, { useState } from "react";
import styles from "../../styles/styles";
import { Link, useNavigate } from "react-router-dom";
import { BiMessage } from "react-icons/bi";
import {
  AiFillDelete,
  AiFillHeart,
  AiOutlineHeart,
  AiOutlineShoppingCart,
} from "react-icons/ai";
import RelatedProducts from "../route/RelatedProducts";
import { backendUrl, server } from "../../server";
import { useDispatch, useSelector } from "react-redux";
import { useEffect } from "react";
import { getAllProductsForShop } from "../../redux/actions/product";
import { toKwacha } from "../../utils/toKwacha";
import { addToList, removeFromList } from "../../redux/actions/wishlist";
import { toast } from "react-toastify";
import { addTocart } from "../../redux/actions/cart";
import Ratings from "../route/Ratings";
import axios from "axios";
import { ClipLoader } from "react-spinners";
import Spinner from "../Spinner";
import { format } from "timeago.js";
import { CgClose } from "react-icons/cg";

const ProductFullDetails = ({ data, eventTag }) => {
  const [select, setSelect] = useState(0);
  const { cart } = useSelector((state) => state.cart);
  const { wishlist } = useSelector((state) => state.wishlist);
  const { user, isAuthenticated } = useSelector((state) => state.user);
  const system = useSelector((state) => state.system);
  const [count, setCount] = useState(1);
  const [approveLoading, setApproveLoading] = useState(false);
  const [deleteTag, setDeleteTag] = useState(false);
  const [click, setClick] = useState(false);
  const dispatch = useDispatch();
  const [loading, setLoading] = useState(false);
  const [averageRatings, setAverageRatings] = useState(null);
  const navigate = useNavigate();

  useEffect(() => {
    const isWishList = wishlist && wishlist.find((i) => data?._id === i._id);
    setClick(isWishList);
  }, [wishlist, data]);

  const decrementCount = () => {
    if (count > 1) {
      setCount(count - 1);
    }
  };

  const incrementCount = () => {
    setCount(count + 1);
  };

  const addToWishlistHandler = (data) => {
    dispatch(addToList(data));
    setClick(true);
  };

  const removeFromWishlistHandler = (data) => {
    setClick(!click);
    dispatch(removeFromList(data));
  };

  const addToCartHandler = (id) => {
    const itemExist = cart && cart.find((i) => i._id === id);

    if (itemExist) {
      toast.error("Item already exist in cart");
    } else {
      if (data?.stock < count) {
        toast.error("Product stock is limited");
      } else {
        const cartData = { ...data, quantity: count };

        dispatch(addTocart(cartData));

        toast.success("Item added to cart successfully ");
      }
    }
  };

  const handleSendMessage = async () => {
    if (!isAuthenticated) {
      toast.error("Login to iniate a conversation with our shop");
      return;
    }

    setLoading(true);

    const groupTitle = data?.shop?._id + user?._id;
    const userId = user?._id;
    const shopId = data?.shop?._id;

    await axios
      .post(`${server}/conversation/create-conversation`, {
        groupTitle,
        userId,
        shopId,
      })
      .then((res) => {
        setLoading(false);
        navigate(`/inbox?conversationId=${res.data.conversation._id}`);
      })
      .catch((err) => {
        setLoading(false);
        toast.error(err.response.data.message);
      });
  };

  // delete product --- admin
  const deleteProduct = async () => {
    if (!eventTag) {
      setApproveLoading(true);
      await axios
        .delete(`${server}/product/admin/${data._id}`, {
          withCredentials: true,
        })
        .then((res) => {
          setDeleteTag(false);
          setApproveLoading(false);
          toast.success("Product Deleted Successfully");
          setTimeout(() => {
            navigate("/products");
          }, 1500);
        })
        .catch((err) => {
          toast.error(err.response ? err.response.data.message : err.message);
          setApproveLoading(false);
          console.log(err);
        });
    } else {
      setApproveLoading(true);
      await axios
        .delete(`${server}/event/admin/${data._id}`, { withCredentials: true })
        .then((res) => {
          setDeleteTag(false);
          setApproveLoading(false);
          toast.success("Product Deleted Successfully");
          setTimeout(() => {
            navigate("/events");
          }, 1500);
        })
        .catch((err) => {
          toast.error(err.response ? err.response.data.message : err.message);
          setApproveLoading(false);
          console.log(err);
        });
    }
  };

  return (
    <div className="bg-white font-Poppins">
      {data ? (
        <div className={`${styles.section} w-[90%] 800px:w-[80%] `}>
          {system.isAuthenticated && (
            <div className="flex w-full items-end justify-end p-4 bg-slate-100 gap-4">
              <button
                className="flex items-center gap-1 px-4 py-2 bg-red-500 text-white rounded"
                onClick={() => setDeleteTag(true)}
              >
                <AiFillDelete size={20} />
                Delete
              </button>
            </div>
          )}
          <div className="w-full py-5">
            <div className="block w-full 800px:flex items-start">
              <div className="w-full 800px:w-[50%] flex flex-row-reverse">
                <img
                  src={
                    data?.images?.[select]
                      ? `${backendUrl}/${data.images[select]}`
                      : "fallback_image_url_here"
                  }
                  alt=""
                  className="w-[80%] object-contain"
                />
                <div className="w-full flex flex-col gap-2">
                  {data?.images?.length > 0 && (
                    <>
                      {data.images?.map((item, index) => (
                        <img
                          onKeyDown={index}
                          src={`${backendUrl}/${data?.images[index]}`}
                          alt=""
                          className={`h-[70px] w-[70px] object-contain cursor-pointer border p-1 border-black rounded-md ${
                            select === index &&
                            " border-2 !border-yellow-400 h-[75px] w-[75px]"
                          }`}
                          onClick={() => setSelect(index)}
                        />
                      ))}
                    </>
                  )}
                </div>
              </div>

              <div className="w-full 800px:w-[50%] pt-5 800px:pl-6 pl-2">
                <h1 className={`${styles.productTitle}`}>{data.name}</h1>
                <p className="800px:text-md text-sm 800px:mt-0 mt-3">
                  {data?.description?.slice(0, 200)}{" "}
                  {data?.description?.length > 200 && "..."}{" "}
                </p>
                <div className="flex pt-3 800px:pr-8 pr-2 w-full flex-row items-center">
                  <h4 className={`${styles.productDiscountPrice}`}>
                    {data?.discountPrice
                      ? toKwacha(data.discountPrice)
                      : toKwacha(data.originalPrice)}
                  </h4>
                  <h3 className={`${styles.price}`}>
                    {data.discountPrice ? toKwacha(data.originalPrice) : null}
                  </h3>

                  <p className="text-right w-full text-red-500">
                    ({data?.soldOut}) Sold
                  </p>
                </div>

                <div className="flex items-center mt-12 justify-between pr-3">
                  <div>
                    <button
                      className="bg-gradient-to-r from-gray-400 to-gray-500 text-white font-bold rounded-l px-4 py-2 shadow-lg hover:opacity-75 transition duration-300 ease-in-out"
                      onClick={decrementCount}
                    >
                      -
                    </button>
                    <span className="bg-gray-100 text-gray-800 font-medium px-4 py-[11px]">
                      {count}
                    </span>
                    <button
                      className="bg-gradient-to-r from-gray-400 to-gray-500 text-white font-bold rounded-l px-4 py-2 shadow-lg hover:opacity-75 transition duration-300 ease-in-out"
                      onClick={incrementCount}
                    >
                      +
                    </button>
                  </div>
                  <div>
                    {click ? (
                      <AiFillHeart
                        size={30}
                        className="cursor-pointer"
                        onClick={() => removeFromWishlistHandler(data)}
                        color={click ? "red" : "#333"}
                        title="Remove from wishlist"
                      />
                    ) : (
                      <AiOutlineHeart
                        size={30}
                        className="cursor-pointer"
                        onClick={() => addToWishlistHandler(data)}
                        title="Add to wishlist"
                      />
                    )}
                  </div>
                </div>

                <div
                  className={`${styles.button}  !bg-white shadow-md border-yellow-400 border-2`}
                  onClick={() => addToCartHandler(data?._id)}
                >
                  <span className="text-primary">Add to cart</span>
                  <AiOutlineShoppingCart size={20} className="text-white" />
                </div>
                <div className="flex mt-5 items-center gap-4 w-full">
                  <Link to={`/seller/${data?.shop?._id}`}>
                    {" "}
                    <img
                      src={`${backendUrl}/${data?.shop?.logo}`}
                      alt=""
                      className="w-[50px] h-[50px] rounded-full object-cover"
                    />
                  </Link>

                  <div className="flex flex-col">
                    <Link to={`/seller/${data?.shop?._id}`}>
                      <h3 className={`${styles.shop_name}`}>
                        {data?.shop?.name}
                      </h3>
                    </Link>
                    <p className="text-sm text-gray-500">
                      ({averageRatings}/5) ratings
                    </p>
                  </div>
                  {isAuthenticated && (
                    <button
                      disabled={loading}
                      className={`${styles.button} ml-6`}
                      onClick={handleSendMessage}
                    >
                      <span className="text-white flex items-center gap-2">
                        {loading ? (
                          <ClipLoader size={24} text={"white"} />
                        ) : (
                          <>
                            Send message <BiMessage size={20} />
                          </>
                        )}
                      </span>
                    </button>
                  )}
                </div>
              </div>
            </div>
            <br />
            <br />
            <ProductInfo data={data} setAverageRatings={setAverageRatings} />
          </div>
          {/* Delete Modal */}
          {deleteTag && (
            <div className="absolute w-full h-[100%] bg-black/30 top-0 items-start left-0 flex justify-center">
              <div className="800px:w-[30%] w-[95%] pb-5 pt-3 bg-white mt-[150px] rounded px-4">
                <button
                  className="w-full flex justify-end p-1 rounded-full"
                  onClick={() => setDeleteTag(false)}
                >
                  <CgClose size={24} />
                </button>
                <h1 className="text-lg font-[600] w-full border-b text-red-500 animate-pulse">
                  Deleting a product !
                </h1>
                <div className="mt-6">
                  <h4 className="text-sm font-[400]">
                    Are you sure about this delete action?
                  </h4>
                  <p className="text-sm text-red-400 mt-2">
                    Take note that this action is irreversible and destructive!
                  </p>
                </div>
                <div className="flex items-center gap-4 mt-4">
                  <button
                    onClick={() => setDeleteTag(false)}
                    className="px-4 py-2 bg-green-500 rounded text-white text-sm mt-1"
                  >
                    Cancel
                  </button>
                  <button
                    disabled={approveLoading}
                    onClick={deleteProduct}
                    className="px-4 py-2 bg-red-500 rounded text-white text-sm mt-1"
                  >
                    Delete
                  </button>
                </div>
              </div>
            </div>
          )}
        </div>
      ) : (
        <Spinner />
      )}

      <RelatedProducts data={data} eventTag={eventTag} />
    </div>
  );
};

const ProductInfo = ({ data, setAverageRatings }) => {
  const { products } = useSelector((state) => state.product);
  const dispatch = useDispatch();

  useEffect(() => {
    if (data?.shop?._id) {
      dispatch(getAllProductsForShop(data.shop._id));
    }
  }, [dispatch, data?.shop?._id]);

  const [active, setActive] = useState(1);

  const totalReviews =
    products &&
    products.reduce((acc, product) => acc + product.reviews.length, 0);

  const totalRatings =
    products &&
    products.reduce(
      (acc, product) =>
        acc + product.reviews.reduce((sum, review) => sum + review.rating, 0),
      0
    );

  const avgRating = totalRatings / totalReviews || 0;

  useEffect(() => {
    setAverageRatings(avgRating);
  }, [avgRating]);

  return (
    <div className=" bg-gray-100 px-3 py-2 rounded 800px:px-10 relative">
      <div className="w-full flex justify-between border-b border-gray-300 pt-10 pb-2">
        <div className="relative ">
          <h5
            className="px-1 leading-5 font-[600] cursor-pointer 800px:text-[20px] text-[15px] text-[#000]"
            onClick={() => setActive(1)}
          >
            Product details
          </h5>
          {active === 1 ? (
            <div className={`${styles.active_indicator}`}></div>
          ) : null}
        </div>

        <div className="relative ">
          <h5
            className="px-1 leading-5 font-[600] cursor-pointer 800px:text-[20px] text-[15px] text-[#000]"
            onClick={() => setActive(2)}
          >
            Product Reviews
          </h5>
          {active === 2 ? (
            <div className={`${styles.active_indicator}`}></div>
          ) : null}
        </div>

        <div className="relative ">
          <h5
            className="px-1 leading-5 font-[600] cursor-pointer 800px:text-[20px] text-[15px] text-[#000]"
            onClick={() => setActive(3)}
          >
            Seller Information
          </h5>
          {active === 3 ? (
            <div className={`${styles.active_indicator}`}></div>
          ) : null}
        </div>
      </div>

      {active === 1 && (
        <div className="md:text-[16px] text-sm">
          <p className="py-2 leading-9 pb-10 whitespace-pre-line">
            {data?.description}
          </p>
        </div>
      )}

      {active === 2 && (
        <div className="mt-6 md:text-[16px] text-sm">
          {" "}
          {data && data.reviews?.length > 0 ? (
            <div className="w-full flex flex-col gap-4 p-3">
              {data.reviews?.map((item, index) => (
                <div className="flex gap-2" key={index}>
                  <img
                    src={`${backendUrl}/${item?.user?.avatar}`}
                    className="w-[60px] h-[60px] rounded-full object-cover border border-yellow-500"
                    alt={item?.user?.name}
                  />
                  <div className="flex flex-col gap-2">
                    <div className="flex gap-4 items-center">
                      <h4 className="font-[500]">{item?.user?.name}</h4>{" "}
                      <Ratings rating={item?.rating} />
                    </div>
                    <p className="text-sm">"{item.comment}"</p>
                    <p className="text-xs text-gray-500 mt-[-5px]">
                      {format(item?.createdAt)}
                    </p>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="w-full flex items-center justify-center py-5">
              <p>No reviews for this product</p>
            </div>
          )}
        </div>
      )}

      {active === 3 && (
        <div className="w-full 800px:flex p-4 block ">
          <div className="800px:w-[50%] flex flex-col gap-3 w-full">
            <div className="flex mt-5 items-center gap-4 w-full">
              <Link to={`/seller/${data?.shop?._id}`}>
                {" "}
                <img
                  src={`${backendUrl}/${data?.shop?.logo}`}
                  alt=""
                  className="w-[50px] h-[50px] rounded-full object-cover"
                />
              </Link>
              <div className="flex flex-col">
                <h3 className={`${styles.shop_name}`}>{data.shop.name}</h3>
                <p className="text-sm text-gray-500">({avgRating}/5) ratings</p>
              </div>
            </div>
            <p className="800px:text-[12pt] text-[11pt] mt-3">
              {data?.shop?.description}
            </p>
          </div>

          <div className="800px:w-[50%] md:flex flex-col gap-3 w-full items-end mt-5 md:text-[12pt] text-[11pt]">
            <div className="flex flex-col gap-2 items-start">
              <p>
                <span className="font-bold">Joined On:</span>{" "}
                {data?.shop?.createdAt.slice(0, 10)}
              </p>
              <p>
                <span className="font-bold">Total Products:</span>{" "}
                {products && products.length}
              </p>
              <p>
                <span className="font-bold">Total reviews:</span> {totalReviews}
              </p>

              <Link to={`/seller/${data?.shop?._id}`} className="mt-2">
                <div className="px-4 py-[9px] rounded-md bg-primary text-white">
                  Visit Shop
                </div>
              </Link>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default ProductFullDetails;
