import React, { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import styles from "../../styles/styles";
import {
  AiFillHeart,
  AiOutlineEye,
  AiOutlineHeart,
  AiOutlineShoppingCart,
} from "react-icons/ai";
import ProductDetails from "./ProductDetails";
import Ratings from "../route/Ratings";
import { backendUrl } from "../../server";
import { toKwacha } from "../../utils/toKwacha";
import { useDispatch, useSelector } from "react-redux";
import { toast } from "react-toastify";
import { addTocart } from "../../redux/actions/cart";
import { addToList, removeFromList } from "../../redux/actions/wishlist";

const ProductCard = ({ data, isEvent, products }) => {
  const [open, setOpen] = useState(false);
  const { cart } = useSelector((state) => state.cart);
  const { wishlist } = useSelector((state) => state.wishlist);
  const [count, setCount] = useState(1);
  const [click, setClick] = useState(false);
  const dispatch = useDispatch();

  useEffect(() => {
    const isWishList = wishlist && wishlist.find((i) => data?._id === i._id);
    setClick(isWishList);
  }, [wishlist, data]);

  const addToWishlistHandler = (data) => {
    dispatch(addToList(data));
    setClick(true);
  };

  const removeFromWishlistHandler = () => {
    setClick(!click);
    dispatch(removeFromList(data));
  };

  const addToCartHandler = (id) => {
    const itemExist = cart && cart.find((i) => i._id === id);

    if (itemExist) {
      toast.error("Item already exist in cart");
    } else {
      const cartData = { ...data, quantity: count };

      dispatch(addTocart(cartData));
      toast.success("Item added to cart successfully");
    }
  };

  return (
    <>
      <div className="w-full h-[430px] bg-white rounded-lg shadow-sm p-3 relative cursor-pointer font-Poppins">
        {/* side options */}
        <div className="flex justify-evenly py-1">
          {click ? (
            <AiFillHeart
              size={22}
              className="cursor-pointer"
              onClick={() => removeFromWishlistHandler(data)}
              color={click ? "red" : "#333"}
              title="Remove from wishlist"
            />
          ) : (
            <AiOutlineHeart
              size={22}
              className="cursor-pointer "
              onClick={() => addToWishlistHandler(data)}
              color={click ? "red" : "#333"}
              title="Add to wishlist"
            />
          )}
          <AiOutlineEye
            size={22}
            className="cursor-pointer"
            onClick={() => setOpen(!open)}
            color="#333"
            title="Quick view"
          />
          <AiOutlineShoppingCart
            size={25}
            className="cursor-pointer"
            onClick={() => addToCartHandler(data?._id)}
            color="#444"
            title="Add to cart"
          />
          {open ? <ProductDetails setOpen={setOpen} data={data && data} productsTemp={products}/> : null}
        </div>

        <Link
          to={
            isEvent
              ? `/product/${data._id}?isEvent=true`
              : `/product/${data._id}`
          }
        >
          <img
            src={data.images && `${backendUrl}/${data.images[0]}`}
            alt=""
            className="w-full h-[170px] object-contain"
          />
        </Link>

        <Link to={`/seller/${data?.shop?._id}`}>
          <h5 className={`${styles.shop_name}`}>{data.shop.name}</h5>
        </Link>

        <Link
          to={
            isEvent
              ? `/product/${data._id}?isEvent=true`
              : `/product/${data._id}`
          }
        >
          <h4 className="pb-3 font-[500]">
            {data.name.length > 40 ? data.name.slice(0, 40) + "..." : data.name}
          </h4>

          <div className="flex">
            <Ratings rating={data?.ratings} />
          </div>

          {/* Price section */}
          <div className="py-2 flex items-center justify-between">
            <div className="flex gap-2 items-center">
              <h5 className={`${styles.productDiscountPrice}`}>
                {data?.discountPrice
                  ? toKwacha(data.discountPrice)
                  : toKwacha(data.originalPrice)}
              </h5>
              {data.discountPrice && (
                <h4 className={`${styles.price}`}>
                  {toKwacha(data.originalPrice)}
                </h4>
              )}
            </div>
          </div>

          {/* Sold & Stock section */}
          <div className="text-right text-[14px] font-medium">
            <p className="text-[#68d284]">{data?.soldOut} sold</p>
            {data?.stock > 0 ? (
              <p className="text-green-600">In Stock ({data?.stock})</p>
            ) : (
              <p className="text-red-500">Out of Stock</p>
            )}
          </div>
        </Link>
      </div>
    </>
  );
};

export default ProductCard;
