import React, { useEffect, useState } from "react";
import { RxCross1 } from "react-icons/rx";
import { Link, useNavigate } from "react-router-dom";
import styles from "../../styles/styles";
import {
  AiFillHeart,
  AiOutlineHeart,
  AiOutlineMessage,
  AiOutlineShoppingCart,
} from "react-icons/ai";
import { backendUrl, server } from "../../server";
import { toKwacha } from "../../utils/toKwacha";
import { useDispatch, useSelector } from "react-redux";
import { toast } from "react-toastify";
import { addTocart } from "../../redux/actions/cart";
import { addToList, removeFromList } from "../../redux/actions/wishlist";
import { getAllProductsForShop } from "../../redux/actions/product";
import axios from "axios";
import { ClipLoader } from "react-spinners";

const ProductDetails = ({ data, setOpen, productsTemp }) => {
  const { cart } = useSelector((state) => state.cart);
  const { user, isAuthenticated } = useSelector((state) => state.user);
  const { wishlist } = useSelector((state) => state.wishlist);
  const [count, setCount] = useState(1);
  const [click, setClick] = useState(false);
  const { products } = useSelector((state) => state.product);
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const [loading, setLoading] = useState(false);
  const [shopProducts, setShopProducts] = useState(null);

  useEffect(() => {
    setShopProducts(productsTemp);
    if (data) {
      if (!productsTemp) {
        dispatch(getAllProductsForShop(data?.shop?._id));
      }
    }
  }, [data]);

  useEffect(() => {
    if (products) {
      setShopProducts(products);
    }
  }, [products]);

  useEffect(() => {
    const isWishList = wishlist && wishlist.find((i) => data?._id === i._id);
    setClick(isWishList);
  }, [wishlist, data]);

  const handleMessageSubmit = async () => {
    if (!isAuthenticated) {
      toast.error("Login to iniate a conversation with our shop");
      return;
    }

    setLoading(true);

    const groupTitle = data?.shop?._id + user?._id;
    const userId = user?._id;
    const shopId = data?.shop?._id;

    await axios
      .post(`${server}/conversation/create-conversation`, {
        groupTitle,
        userId,
        shopId,
      })
      .then((res) => {
        setLoading(false);
        navigate(`/inbox?conversationId=${res.data.conversation._id}`);
      })
      .catch((err) => {
        setLoading(false);
        toast.error(err.response.data.message);
      });
  };

  const decrementCount = () => {
    if (count > 1) {
      setCount(count - 1);
    }
  };

  const incrementCount = () => {
    setCount(count + 1);
  };

  const addToWishlistHandler = (data) => {
    dispatch(addToList(data));
    setClick(true);
  };

  const removeFromWishlistHandler = (data) => {
    setClick(!click);
    dispatch(removeFromList(data));
  };

  const addToCartHandler = (id) => {
    const itemExist = cart && cart.find((i) => i._id === id);

    if (itemExist) {
      toast.error("Item already exist in cart");
    } else {
      if (data?.stock < count) {
        toast.error("Product stock is limited");
      } else {
        const cartData = { ...data, quantity: count };

        dispatch(addTocart(cartData));

        toast.success("Item added to cart successfully ");
      }
    }
  };

  const totalReviews =
    shopProducts &&
    shopProducts.reduce((acc, product) => acc + product.reviews.length, 0);

  const totalRatings =
    shopProducts &&
    shopProducts.reduce(
      (acc, product) =>
        acc + product.reviews.reduce((sum, review) => sum + review.rating, 0),
      0
    );

  const avgRatings = totalRatings / totalReviews || 0;

  return (
    <div className="bg-[#fff]">
      {data ? (
        <div className="fixed w-full h-screen top-0 left-0 bg-[#00000030] z-40 flex items-center justify-center">
          <div className="w-[90%] 800px:w-[60%] h-[90vh] overflow-y-scroll 800px:h-[75vh] bg-white rounded-md shadow-sm relative p-4">
            <RxCross1
              size={30}
              className="absolute right-3 top-3 z-50 p-1 bg-red-500 rounded-full text-white animate-pulse"
              onClick={() => setOpen(false)}
            />

            <div className="block w-full 800px:flex gap-2">
              <div className="w-full 800px:w-[50%]">
                <img
                  src={data.images && `${backendUrl}/${data.images[0]}`}
                  alt=""
                />
                <div className="flex mt-4 items-center">
                  <Link
                    to={`/seller/${data?.shop?._id}`}
                    className="flex items-center"
                  >
                    <img
                      src={`${backendUrl}/${data?.shop?.logo}`}
                      alt=""
                      className="w-[50px] h-[50px] rounded-full mr-2 object-cover"
                    />
                    <div>
                      <Link
                        to={`/seller/${data?.shop?._id}`}
                        className={`${styles.shop_name}`}
                      >
                        {data.shop.name}
                      </Link>
                      <h5 className="pb-2 text-[15px]">
                        {shopProducts && <>({avgRatings}/5) Ratings</>}
                      </h5>
                    </div>
                  </Link>
                </div>
                <button
                  disabled={loading}
                  className={`${styles.button} bg-[#000] mt-4 rounded-[4px] h-11`}
                  onClick={handleMessageSubmit}
                >
                  <span className="text-[#fff] flex items-center">
                    {loading ? (
                      <ClipLoader size={24} color="white" />
                    ) : (
                      <>
                        Send Message <AiOutlineMessage className="ml-1" />
                      </>
                    )}
                  </span>
                </button>
                <h5 className="text-[11pt] text-[red] mt-5">
                  ({data.soldOut}) Sold out
                </h5>
              </div>

              <div className="w-full 800px:w-[50%] pt-5 pl-[5px] pr-[5px]">
                <h1 className={`${styles.productTitle} text-[14pt]`}>
                  {data?.name}
                </h1>
                <p className="text-[11pt]">
                  {data?.description.length > 200
                    ? `${data?.description?.slice(0, 200)} ...`
                    : data?.description}
                </p>

                <div className="flex pt-3">
                  <h4 className={`${styles.productDiscountPrice}`}>
                    {data?.discountPrice
                      ? toKwacha(data?.discountPrice)
                      : toKwacha(data?.originalPrice)}
                  </h4>
                  <h3 className={`${styles.price}`}>
                    {data?.discountPrice ? toKwacha(data?.originalPrice) : null}
                  </h3>
                </div>
                <div className="flex items-center mt-12 justify-between pr-3">
                  <div>
                    <button
                      className="bg-gradient-to-r from-gray-400 to-gray-500 text-white font-bold rounded-l px-4 py-2 shadow-lg hover:opacity-75 transition duration-300 ease-in-out"
                      onClick={decrementCount}
                    >
                      -
                    </button>
                    <span className="bg-gray-100 text-gray-800 font-medium px-4 py-[11px]">
                      {count}
                    </span>
                    <button
                      className="bg-gradient-to-r from-gray-400 to-gray-500 text-white font-bold rounded-l px-4 py-2 shadow-lg hover:opacity-75 transition duration-300 ease-in-out"
                      onClick={incrementCount}
                    >
                      +
                    </button>
                  </div>
                  <div>
                    {click ? (
                      <AiFillHeart
                        size={30}
                        className="cursor-pointer"
                        onClick={() => removeFromWishlistHandler(data)}
                        color={click ? "red" : "#333"}
                        title="Remove from wishlist"
                      />
                    ) : (
                      <AiOutlineHeart
                        size={30}
                        className="cursor-pointer"
                        onClick={() => addToWishlistHandler(data)}
                        title="Add to wishlist"
                      />
                    )}
                  </div>
                </div>
                <div
                  className={`${styles.button} mt-6 rounded-[4px] h-11 flex items-center`}
                  onClick={() => addToCartHandler(data?._id)}
                >
                  <span className="text-[#fff] flex items-center">
                    Add to cart <AiOutlineShoppingCart className="ml-1" />
                  </span>
                </div>
              </div>
            </div>
          </div>
        </div>
      ) : null}
    </div>
  );
};

export default ProductDetails;
