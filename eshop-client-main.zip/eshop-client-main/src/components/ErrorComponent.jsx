import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";

const ErrorComponent = ({ error }) => {
  const [countdown, setCountdown] = useState(5);
  const navigate = useNavigate();

  useEffect(() => {
    const interval = setInterval(() => {
      setCountdown((prev) => prev - 1);
    }, 1000);

    // Navigate when countdown reaches 0
    if (countdown === 0) {
      navigate("/");
    }

    return () => clearInterval(interval); // Cleanup interval
  }, [countdown, navigate]);

  return (
    <div className="flex w-full h-[100vh] items-center justify-center flex-col gap-5">
      <h5 className="font-[700] text-red-400">{error}</h5>
      <p className="font-light text-lg">
        Redirecting you to Home page in {countdown} seconds
      </p>
    </div>
  );
};

export default ErrorComponent;
