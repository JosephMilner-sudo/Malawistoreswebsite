import React, { useEffect, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { deleteCoupon, getAllCouponsForShop } from "../../redux/actions/coupon";
import { ClipLoader } from "react-spinners";
import { Link } from "react-router-dom";
import { AiOutlineDelete } from "react-icons/ai";
import { CgEye } from "react-icons/cg";
import { toast } from "react-toastify";
import styles from "../../styles/styles";
import { CreateCoupon } from "..";

const AllShopCoupons = () => {
  const dispatch = useDispatch();
  const { coupons, loading, error } = useSelector((state) => state.coupon);
  const { shop } = useSelector((state) => state.shop);

  const [open, setOpen] = useState(false);
  const [search, setSearch] = useState("");
  const [currentPage, setCurrentPage] = useState(1);
  const recordsPerPage = 10;

  useEffect(() => {
    if (shop?._id) dispatch(getAllCouponsForShop(shop._id));
    if (error) toast.error(error);
  }, [dispatch, error, shop]);

  const handleDelete = (couponId) => {
    dispatch(deleteCoupon(couponId));
  };

  const filteredCoupons = coupons?.filter((coupon) =>
    coupon.name.toLowerCase().includes(search.toLowerCase())
  );

  const totalPages = Math.ceil((filteredCoupons?.length || 0) / recordsPerPage);
  const indexOfLastRecord = currentPage * recordsPerPage;
  const indexOfFirstRecord = indexOfLastRecord - recordsPerPage;
  const currentRecords = filteredCoupons?.slice(
    indexOfFirstRecord,
    indexOfLastRecord
  );

  if (loading) {
    return (
      <div className="w-full h-[80vh] flex items-center justify-center">
        <ClipLoader size={100} color="blue" />
      </div>
    );
  }

  return (
    <div className="bg-white w-full pt-1 mt-10 800px:mx-8 mx-2">
      <div className="flex justify-between items-center mb-4">
        <input
          type="text"
          placeholder="Search by coupon name"
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          className={`${styles.input} !w-[50%]`}
        />
        <button
          className={`${styles.button} !text-white`}
          onClick={() => setOpen(true)}
        >
          Add Coupon Code
        </button>
      </div>

      <div className="overflow-x-auto">
        <table className="w-full text-sm text-left border border-gray-200">
          <thead className=" bg-white uppercase">
            <tr>
              <th className="px-4 py-3 border">Coupon ID</th>
              <th className="px-4 py-3 border">Name</th>
              <th className="px-4 py-3 border">Discount %</th>
              <th className="px-4 py-3 border">Min Amount</th>
              <th className="px-4 py-3 border">Max Amount</th>
              <th className="px-4 py-3 border">Product</th>
              <th className="px-4 py-3 border">Preview</th>
              <th className="px-4 py-3 border">Delete</th>
            </tr>
          </thead>
          <tbody>
            {currentRecords?.map((item) => (
              <tr key={item._id} className="hover:bg-gray-50">
                <td className="px-4 py-3 ">{item._id}</td>
                <td className="px-4 py-3 ">{item.name}</td>
                <td className="px-4 py-3 ">{item.value}</td>
                <td className="px-4 py-3 ">{item.minAmout}</td>
                <td className="px-4 py-3 ">{item.maxAmout}</td>
                <td className="px-4 py-3 ">
                  {item?.product?.name.length > 60
                    ? item.product.name.slice(0, 60) + " ..."
                    : item?.product?.name || "-"}
                </td>
                <td className="px-4 py-3">
                  <Link to={`/coupon/${item._id}`}>
                    <CgEye size={20} className="text-blue-500" />
                  </Link>
                </td>
                <td className="px-4 py-3">
                  <button onClick={() => handleDelete(item._id)}>
                    <AiOutlineDelete size={20} className="text-red-600" />
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* Pagination */}
      <div className="flex justify-center mt-4">
        <button
          className="px-4 py-2 mx-1 border rounded disabled:opacity-50"
          disabled={currentPage === 1}
          onClick={() => setCurrentPage(currentPage - 1)}
        >
          Previous
        </button>
        {Array.from({ length: totalPages }, (_, i) => i + 1).map((number) => (
          <button
            key={number}
            onClick={() => setCurrentPage(number)}
            className={`px-4 py-2 mx-1 border rounded ${
              currentPage === number ? "bg-blue-500 text-white" : ""
            }`}
          >
            {number}
          </button>
        ))}
        <button
          className="px-4 py-2 mx-1 border rounded disabled:opacity-50"
          disabled={currentPage === totalPages}
          onClick={() => setCurrentPage(currentPage + 1)}
        >
          Next
        </button>
      </div>

      {open && <CreateCoupon setOpen={setOpen} />}
    </div>
  );
};

export default AllShopCoupons;
