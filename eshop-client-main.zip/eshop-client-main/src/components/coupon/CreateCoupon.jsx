import React, { useEffect, useState } from "react";
import { CgClose } from "react-icons/cg";
import styles from "../../styles/styles";
import { useDispatch, useSelector } from "react-redux";
import { createCoupon } from "../../redux/actions/coupon";
import { toast } from "react-toastify";
import { getAllProductsForShop } from "../../redux/actions/product";

const CreateCoupon = ({ setOpen }) => {
  const formDataDefaults = {
    name: "",
    value: "",
    minAmount: "",
    maxAmount: "",
    productId: "",
  };
  const [formData, setFormData] = useState(formDataDefaults);
  const [errors, setErrors] = useState({});
  const { products } = useSelector((state) => state.product);
  const { shop } = useSelector((state) => state.shop);
  const dispatch = useDispatch();
  const { error, success } = useSelector((state) => state.coupon);

  useEffect(() => {
    dispatch(getAllProductsForShop(shop?._id));
  }, [products]);

  useEffect(() => {
    if (error) {
      toast.error(error);
    }

    if (success) {
      toast.success("Coupon created successfully");
      setFormData(formDataDefaults);
      setOpen(false);
    }
  }, [dispatch, error, success]);

  const validate = () => {
    let newErrors = {};
    if (!formData.name) newErrors.name = "Coupon code name is required.";
    if (!formData.value)
      newErrors.value = "Coupon percentage value is required.";
    setErrors(newErrors);

    return Object.keys(newErrors).length === 0;
  };

  const handleChange = (e) => {
    const { name, value } = e.target;
    let formattedValue = value;
    let newErrors = { ...errors }; // Create a copy of the current errors to modify

    if (name === "minAmount" || name === "maxAmount") {
      // Remove non-numeric characters and reformat the price
      formattedValue = value
        .replace(/\D/g, "")
        .replace(/\B(?=(\d{3})+(?!\d))/g, ",");
    }

    // Update the form data and errors state
    setFormData((prev) => ({ ...prev, [name]: formattedValue }));
    setErrors(newErrors);
  };

  const handleSubmit = (e) => {
    e.preventDefault();

    if (validate()) {
      // Remove commas from originalPrice and discountPrice
      const cleanedFormData = {
        ...formData,
        minAmount: formData.minAmount.replace(/,/g, ""), // Remove commas
        maxAmount: formData.maxAmount.replace(/,/g, ""), // Remove commas
      };

      dispatch(createCoupon(cleanedFormData));
    }
  };

  return (
    <div className="fixed w-full h-screen bg-black/40 top-0 left-0 z-[200] flex items-center justify-center font-Poppins ">
      <div className="lg:w-[40%] w-[90%] h-[82vh] bg-white rounded-md shadow-md overflow-y-auto">
        <div className="w-full flex justify-between items-center px-2 py-3">
          <h1 className="text-xl font-[600] p-1">Create Coupon Code</h1>
          <CgClose
            className="mr-3 cursor-pointer hover:bg-gray-300 rounded-full"
            size={30}
            color={"red"}
            onClick={() => setOpen(false)}
          />
        </div>
        <form
          onSubmit={handleSubmit}
          className="flex flex-col w-full p-3 lg:gap-5 gap-4 mt-2"
        >
          {/* Product Name */}
          <div className="w-full">
            <label htmlFor="name">
              Coupon Code Name <span className="text-red-500">*</span>
            </label>
            <input
              type="text"
              id="name"
              name="name"
              className={`${styles.input} ${
                errors.name ? "border-red-500" : ""
              }`}
              value={formData.name}
              onChange={handleChange}
              placeholder="i.e. Enter coupons code "
              required
            />
            {errors.name && (
              <p className="text-red-500 text-sm">{errors.name}</p>
            )}
          </div>

          {/* value */}
          <div className="w-full">
            <label htmlFor="value">
              Discount Percentage Value <span className="text-red-500">*</span>
            </label>
            <input
              placeholder="Enter a percentage value for the discount"
              id="value"
              name="value"
              type="number"
              className={`${styles.input} ${
                errors.value ? "border-red-500" : ""
              }`}
              value={formData.value}
              onChange={handleChange}
              required
            />
            {errors.value && (
              <p className="text-red-500 text-sm">{errors.value}</p>
            )}
          </div>

          {/* Min Amount Price */}
          <div className="w-full relative">
            <label htmlFor="minAmount">Minimum Amount</label>
            <input
              type="text"
              id="minAmount"
              name="minAmount"
              className={`${styles.input} !pl-[42px] ${
                errors.minAmount ? "border-red-500" : ""
              }`}
              value={formData.minAmount}
              onChange={handleChange}
            />
            <div className="absolute bottom-0 left-0 flex justify-center items-center bg-yellow-500 py-[5px] px-2 rounded-sm">
              <p className="text-white">MK</p>
            </div>
            {errors.minAmount && (
              <p className="text-red-500 text-sm">{errors.minAmount}</p>
            )}
          </div>

          {/* Min Amount Price */}
          <div className="w-full relative">
            <label htmlFor="maxAmount">Maximum Amount</label>
            <input
              type="text"
              id="maxAmount"
              name="maxAmount"
              className={`${styles.input} !pl-[42px] ${
                errors.maxAmount ? "border-red-500" : ""
              }`}
              value={formData.maxAmount}
              onChange={handleChange}
            />
            <div className="absolute bottom-0 left-0 flex justify-center items-center bg-yellow-500 py-[5px] px-2 rounded-sm">
              <p className="text-white">MK</p>
            </div>
            {errors.minAmount && (
              <p className="text-red-500 text-sm">{errors.maxAmount}</p>
            )}
          </div>

          {/* Products */}
          {products && (
            <div className="w-full">
              <label htmlFor="category">Product</label>
              <select
                id="productId"
                name="productId"
                className={`${styles.input} ${
                  errors.productId ? "border-red-500" : ""
                }`}
                value={formData.productId}
                onChange={handleChange}
                required
              >
                <option value="">Select product</option>
                {products?.map((item) => (
                  <option key={item?._id} value={item?._id}>
                    {item?.name}
                  </option>
                ))}
              </select>
              {errors.productId && (
                <p className="text-red-500 text-sm">{errors.productId}</p>
              )}
            </div>
          )}

          {/* Submit Button */}
          <div className="w-full col-span-2">
            <button
              type="submit"
              className={`${styles.button} !w-full !text-white`}
            >
              Create
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default CreateCoupon;
