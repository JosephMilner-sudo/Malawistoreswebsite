import React, { useEffect } from "react";
import Lottie from "react-lottie";
import animationData from "../assets/animation/success.json";

const Success = () => {
  const defaultOptions = {
    loop: true,
    autoplay: true,
    animationData: animationData,
    rendererSettings: {
      preserveAspectRatio: "xMidYMid slice",
    },
  };

  useEffect(() => {
    window.scrollTo(0, 0);
  }, []);
  return (
    <div className="w-full h-screen flex items-center flex-col gap-3 font-Poppins mt-5">
      <Lottie options={defaultOptions} width={300} height={300} />
      <h4 className="text-xl font-semibold uppercase text-green-800">
        Processed Succefully !
      </h4>
    </div>
  );
};

export default Success;
