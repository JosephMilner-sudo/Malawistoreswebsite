import { useEffect, useState } from "react";
import {
  CardNumberElement,
  CardCvcElement,
  CardExpiryElement,
  useStripe,
  useElements,
} from "@stripe/react-stripe-js";
import { useDispatch, useSelector } from "react-redux";
import styles from "./../../styles/styles";
import axios from "axios";
import { server } from "./../../server";
import { toast } from "react-toastify";
import { RxCross1 } from "react-icons/rx";
import { PayPalButtons, PayPalScriptProvider } from "@paypal/react-paypal-js";

const PaymentGateways = ({ orderData, setOrderData, setActive }) => {
  const [select, setSelect] = useState(0);
  const { user } = useSelector((state) => state.user);
  const [open, setOpen] = useState(false);
  const stripe = useStripe();
  const elements = useElements();
  const dispatch = useDispatch();

  useEffect(() => {
    const orderedData = JSON.parse(localStorage.getItem("latestOrder"));
    setOrderData(orderedData);
  }, []);

  const createOrder = (data, actions) => {
    return actions.order
      .create({
        purchase_units: [
          {
            description: "Mandasi",
            amount: {
              currency_code: "USD",
              value: orderData?.totalPrice,
            },
          },
        ],
        application_context: {
          shipping_preference: "NO_SHIPPING",
        },
      })
      .then((orderId) => {
        return orderId;
      });
  };

  const onApprove = async (data, actions) => {
    return actions.order.capture().then((details) => {
      const { payer } = details;
      let paymentInfo = payer;

      if (paymentInfo) {
        payPalPaymentHandler(paymentInfo);
      }
    });
  };

  const payPalPaymentHandler = async (paymentInfo) => {
    try {
      const config = {
        headers: {
          "Content-Type": "application/json",
        },
        withCredentials: true,
      };

      order.paymentInfo = {
        id: paymentInfo.payer_id,
        status: "succeeded",
        type: "Paypal",
      };

      await axios
        .post(`${server}/order/create-order`, order, config)
        .then((res) => {
          setOpen(false);
          setActive(3);
          toast.success("Order is Successful!");
          localStorage.setItem("cartItems", JSON.stringify([]));
          localStorage.setItem("latestOrder", JSON.stringify([]));

          setTimeout(() => {
            dispatch({ type: "restoreCart" });
          }, 3000);
        });
    } catch (error) {
      toast.error(error.response.data.message);
    }
  };

  const paymentData = {
    amount: Math.round(orderData?.totalPrice * 100),
  };

  const order = {
    cart: orderData?.cart,
    shippingAddress: orderData?.shippingAddress,
    user: user && user,
    totalPrice: orderData?.totalPrice,
  };

  const paymentHandler = async (e) => {
    e.preventDefault();

    try {
      const config = {
        headers: {
          "Content-Type": "application/json",
        },
        withCredentials: true,
      };

      const { data } = await axios.post(
        `${server}/payment/process`,
        paymentData,
        config
      );

      const clientSecret = data?.clientSecret;

      if (!stripe || !elements) return;

      const result = await stripe.confirmCardPayment(clientSecret, {
        payment_method: {
          card: elements.getElement(CardNumberElement),
        },
      });

      if (result.error) {
        toast.error(result.error.message);
      } else {
        if (result.paymentIntent.status === "succeeded") {
          order.paymentInfo = {
            id: result.paymentIntent.id,
            status: result.paymentIntent.status,
            type: "Credit Card",
          };
        }

        await axios
          .post(`${server}/order/create-order`, order, config)
          .then((res) => {
            setOpen(false);
            setActive(3);
            toast.success("Order is Successful!");
            localStorage.setItem("cartItems", JSON.stringify([]));
            localStorage.setItem("latestOrder", JSON.stringify([]));

            setTimeout(() => {
              dispatch({ type: "restoreCart" });
            }, 3000);
          });
      }
    } catch (error) {
      toast.error(error.response.data.message);
    }
  };

  const cashOnDeliveryHandler = async (e) => {
    e.preventDefault();

    try {
      const config = {
        headers: {
          "Content-Type": "application/json",
        },
        withCredentials: true,
      };

      order.paymentInfo = {
        type: "Cash on Delivery",
      };

      await axios
        .post(`${server}/order/create-order`, order, config)
        .then((res) => {
          setOpen(false);
          setActive(3);
          toast.success("Order is Successful!");
          localStorage.setItem("cartItems", JSON.stringify([]));
          localStorage.setItem("latestOrder", JSON.stringify([]));
          setTimeout(() => {
            dispatch({ type: "restoreCart" });
          }, 3000);
        });
    } catch (error) {
      toast.error(error.response.data.message);
    }
  };

  return (
    <div className="800px:w-[40%] py-7 flex flex-col bg-white px-4 rounded-sm">
      <div className="border-b pb-1">
        <h3 className="text-lg font-semibold">Payments Methods</h3>
      </div>

      <div className="w-full flex flex-col gap-5 mt-5">
        <div>
          <div className="flex w-full gap-3 items-center">
            <div
              className={`w-[20px] h-[20px]  rounded-full border-2 border-black flex items-center justify-center cursor-pointer`}
              onClick={() => setSelect(1)}
            >
              {select === 1 && (
                <div className="w-[12px] h-[12px] bg-black rounded-full" />
              )}
            </div>
            Pay with Debit/Credit Card
          </div>
          {select === 1 && (
            <form
              className="w-full py-2 grid 800px:grid-cols-2 grid-cols-1 gap-3 text-sm border-t mt-1 rounded-md"
              onSubmit={paymentHandler}
            >
              <div>
                <label htmlFor="">Name on Card</label>
                <input
                  type="text"
                  className={`${styles.input} !text-[#444]`}
                  placeholder={user && user?.name}
                  value={user && user?.name}
                />
              </div>

              <div>
                <label htmlFor="">Exp Date</label>
                <CardExpiryElement
                  className={`${styles.input}`}
                  options={{
                    style: {
                      base: {
                        fontSize: "15px",
                        lineHeight: 1.5,
                        color: "#444",
                      },
                      empty: {
                        color: "#3a120a",
                        backgroundColor: "transparent",
                        "::placeholder": {
                          color: "#444",
                        },
                      },
                    },
                  }}
                />
              </div>

              <div>
                <label htmlFor="">Card Number</label>
                <CardNumberElement
                  className={`${styles.input}`}
                  options={{
                    style: {
                      base: {
                        fontSize: "15px",
                        lineHeight: 1.5,
                        color: "#444",
                      },
                      empty: {
                        color: "#3a120a",
                        backgroundColor: "transparent",
                        "::placeholder": {
                          color: "#444",
                        },
                      },
                    },
                  }}
                />
              </div>

              <div>
                <label htmlFor="">CVC</label>
                <CardCvcElement
                  className={`${styles.input}`}
                  options={{
                    style: {
                      base: {
                        fontSize: "15px",
                        lineHeight: 1.5,
                        color: "#444",
                      },
                      empty: {
                        color: "#3a120a",
                        backgroundColor: "transparent",
                        "::placeholder": {
                          color: "#444",
                        },
                      },
                    },
                  }}
                />
              </div>

              <button type="submit" className={`${styles.button}`}>
                Proceed
              </button>
            </form>
          )}
        </div>

        {/*
        <div>
          <div className="flex w-full gap-3 items-center">
            <div
              className={`w-[20px] h-[20px]  rounded-full border-2 border-black flex items-center justify-center cursor-pointer`}
              onClick={() => setSelect(2)}
            >
              {select === 2 && (
                <div className="w-[12px] h-[12px] bg-black rounded-full" />
              )}
            </div>
            Pay with Airtel Money
          </div>

          {select === 2 && <div className="">Airtel money form here</div>}
        </div> */}

        <div>
          <div className="flex w-full gap-3 items-center">
            <div
              className={`w-[20px] h-[20px]  rounded-full border-2 border-black flex items-center justify-center cursor-pointer`}
              onClick={() => setSelect(3)}
            >
              {select === 3 && (
                <div className="w-[12px] h-[12px] bg-black rounded-full" />
              )}
            </div>
            Pay with Paychangu
          </div>

          {select === 3 && <div className="">Paychangu form here</div>}
        </div>

        <div>
          <div className="flex w-full gap-3 items-center">
            <div
              className={`w-[20px] h-[20px]  rounded-full border-2 border-black flex items-center justify-center cursor-pointer`}
              onClick={() => setSelect(4)}
            >
              {select === 4 && (
                <div className="w-[12px] h-[12px] bg-black rounded-full" />
              )}
            </div>
            Pay with Paypal
          </div>

          {select === 4 && (
            <div className="py-1  px-2">
              <div>
                <button
                  className={`${styles.button}`}
                  onClick={() => setOpen(true)}
                >
                  Pay Now
                </button>

                {open && (
                  <div className="fixed top-0 left-0 w-full h-screen bg-black/20 flex items-center justify-center">
                    <div className="800px:w-[40%] h-[80vh] bg-white rounded-md flex flex-col gap-3 p-4 overflow-auto">
                      <div className="w-full flex items-end justify-end">
                        <RxCross1
                          title="Close"
                          size={30}
                          color="red"
                          className="cursor-pointer"
                          onClick={() => setOpen(false)}
                        />
                      </div>
                      <div className="w-full h-full flex items-center justify-center">
                        <PayPalScriptProvider
                          options={{
                            clientId:
                              "AczdPFAJTSMAKRjxF-eqSJdsV1chIiVOpZKijQlxWpwxA6jpwG6ABqG36Qu-lVi0ij5kXiz_F6vgG8pP",
                          }}
                        >
                          <PayPalButtons
                            style={{
                              layout: "vertical",
                            }}
                            onApprove={onApprove}
                            createOrder={createOrder}
                          />
                        </PayPalScriptProvider>
                      </div>
                    </div>
                  </div>
                )}
              </div>
            </div>
          )}
        </div>

        <div>
          <div className="flex w-full gap-3 items-center">
            <div
              className={`w-[20px] h-[20px]  rounded-full border-2 border-black flex items-center justify-center cursor-pointer`}
              onClick={() => setSelect(5)}
            >
              {select === 5 && (
                <div className="w-[12px] h-[12px] bg-black rounded-full" />
              )}
            </div>
            Cash on Delivery
          </div>

          {select === 5 && (
            <div className="py-1  px-2">
              <div>
                <button
                  className={`${styles.button}`}
                  onClick={cashOnDeliveryHandler}
                >
                  Confirm
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default PaymentGateways;
