import React from "react";

const CheckoutSteps = ({ active }) => {
  return (
    <div className="w-full mt-2 flex items-center justify-center 800px:text-md text-sm">
      <div className="flex items-center">
        <div
          className={`rounded-xl px-6 py-2 ${
            active === 1 ? "bg-red-500" : "bg-red-300"
          } text-white font-[500]`}
        >
          1. Shipping
        </div>
        <span
          className={`800px:w-[100px] w-[20px] h-0.5 ${
            active === 1 ? "bg-red-500" : "bg-red-300"
          }`}
        ></span>
        <div
          className={`rounded-xl px-6 py-2 ${
            active === 2 ? "bg-red-500" : "bg-red-300"
          } text-white font-[500]`}
        >
          2. Payment
        </div>
        <span
          className={`800px:w-[100px] w-[20px] h-0.5 ${
            active === 2 ? "bg-red-500" : "bg-red-300"
          }`}
        ></span>
        <div
          className={`rounded-xl px-6 py-2 ${
            active === 3 ? "bg-red-500" : "bg-red-300"
          } text-white font-[500]`}
        >
          3. Success
        </div>
      </div>
    </div>
  );
};

export default CheckoutSteps;
