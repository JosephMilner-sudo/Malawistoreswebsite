import { useEffect, useState } from "react";
import { useSelector } from "react-redux";
import { toKwacha } from "../../utils/toKwacha";
import styles from "../../styles/styles";
import { toast } from "react-toastify";
import axios from "axios";
import { server } from "../../server";
import { ClipLoader } from "react-spinners";

const CartInfo = ({ formData, setActive, active, orderData }) => {
  const { cart } = useSelector((state) => state.cart);
  const { user } = useSelector((state) => state.user);
  const [discountCode, setDiscountCode] = useState("");
  const [discountData, setDiscountData] = useState(null);
  const [discountPrice, setDiscountPrice] = useState(null);
  const [loading, setLoading] = useState(false);

  const subTotal =
    cart &&
    cart.reduce(
      (acc, item) =>
        acc +
        item.quantity *
          (item.discountPrice ? item.discountPrice : item.originalPrice),
      0
    );

  const shippingPrice = subTotal * 0.1;

  const discountPercentage = discountData ? discountPrice : "";

  const totalPrice = discountData
    ? subTotal + shippingPrice - discountPercentage
    : subTotal + shippingPrice;

  useEffect(() => {
    setDiscountPrice(null);
  }, [cart]);

  const handleCodeSubmit = async (e) => {
    e.preventDefault();

    if (discountCode === "") {
      toast.error("Please enter discount code");
      return;
    }

    setLoading(true);

    await axios
      .get(`${server}/coupon/get-discount-code/${discountCode}`)
      .then((res) => {
        setLoading(false);

        if (!res.data.discountCode) {
          toast.error("Coupon code does not exist");
          setDiscountCode("");
        } else {
          const discountCodeValue = res.data?.discountCode?.value;
          const isCouponValidForShop =
            cart &&
            cart.filter(
              (item) => item?.shop._id === res.data.discountCode.shop._id
            );

          if (isCouponValidForShop.length === 0) {
            toast.error("Coupon code is not valid for this shop");
            setDiscountCode("");
          } else {
            const eligiblePrice = isCouponValidForShop.reduce(
              (acc, item) =>
                acc +
                item.quantity *
                  (item.discountPrice
                    ? item.discountPrice
                    : item.originalPrice),
              0
            );

            const discountPrice = (eligiblePrice * discountCodeValue) / 100;

            setDiscountPrice(discountPrice);
            setDiscountData(res.data.discountCode);
          }
        }
      })
      .catch((err) => {
        setLoading(false);
        toast.error(err.response.data.message);
      });
  };

  const goToPayment = () => {
    if (
      ["name", "phoneNumber", "country", "city", "address1"].some(
        (key) => formData[key] === ""
      )
    ) {
      toast.error(
        "Make sure you fill all the required fields represent by a *"
      );
    } else {
      const shippingAddress = formData;

      const orderData = {
        cart,
        totalPrice,
        subTotal,
        shippingPrice,
        discountPrice,
        shippingAddress,
        user,
      };

      //update local storage
      localStorage.setItem("latestOrder", JSON.stringify(orderData));
      setActive(2);
    }
  };

  return (
    <div className="800px:w-[25%]">
      <div className="w-full flex flex-col bg-white rounded-sm px-4 py-7 gap-3">
        <div className="w-full flex justify-between items-center">
          <p>subtotal:</p>
          <h4 className="text-lg font-semibold">
            {!orderData ? toKwacha(subTotal) : toKwacha(orderData?.subTotal)}
          </h4>
        </div>
        <div className="w-full flex justify-between items-center">
          <p>shipping:</p>
          <h4 className="text-lg font-semibold">
            {!orderData
              ? toKwacha(shippingPrice)
              : toKwacha(orderData?.shippingPrice)}
          </h4>
        </div>
        <div className="w-full flex justify-between items-center">
          <p>discount:</p>
          <h4 className="text-lg font-semibold">
            {!orderData
              ? discountPrice
                ? ` -${toKwacha(discountPrice.toString())}`
                : "-"
              : orderData?.discountPrice
              ? ` -${toKwacha(orderData?.discountPrice.toString())}`
              : "-"}
          </h4>
        </div>
        <hr />
        <div className="self-end">
          <h4 className="text-lg font-semibold">
            {!orderData
              ? toKwacha(totalPrice)
              : toKwacha(orderData?.totalPrice)}
          </h4>
        </div>

        {active === 1 && (
          <form action="" className="mt-2 w-full" onSubmit={handleCodeSubmit}>
            <input
              type="text"
              placeholder="Discount code"
              className={`${styles.input}`}
              value={discountCode}
              onChange={(e) => setDiscountCode(e.target.value)}
            />

            <button
              type={"submit"}
              disabled={loading}
              className="px-4 py-2 mt-4 text-red-400 text-center w-full border-red-400 border items-center justify-center flex"
            >
              {loading ? (
                <ClipLoader size={20} color={"green"} />
              ) : (
                "Apply Code"
              )}
            </button>
          </form>
        )}
      </div>

      {active === 1 && (
        <div className="flex items-center justify-center w-full mt-5">
          <button className={`${styles.button}`} onClick={goToPayment}>
            Proceed to Payment
          </button>
        </div>
      )}

      {active === 2 && (
        <div className="w-full flex items-end justify-end p-2">
          <button
            className="px-4 py-2 rounded-md bg-red-500 text-white"
            onClick={() => setActive(1)}
          >
            Back
          </button>
        </div>
      )}
    </div>
  );
};

export default CartInfo;
