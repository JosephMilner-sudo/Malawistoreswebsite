import React, { useEffect, useState } from "react";
import { useSelector } from "react-redux";
import ShippingInfo from "./ShippingInfo";
import CartInfo from "./CartInfo";
import PaymentGateways from "./PaymentGateways";
import { useNavigate } from "react-router-dom";
import { toast } from "react-toastify";
import Success from "../Success";

const Checkout = ({ active, setActive }) => {
  const { user } = useSelector((state) => state.user);
  const { cart } = useSelector((state) => state.cart);
  const [orderData, setOrderData] = useState(null);
  const navigate = useNavigate();
  const [formData, setFormData] = useState({
    name: user?.name,
    email: user?.email,
    phoneNumber: user?.phoneNumber,
    zipCode: "",
    country: "",
    city: "",
    address1: "",
    address2: "",
  });

  useEffect(() => {
    if (cart && cart?.length === 0) {
      setTimeout(() => {
        toast.info("Nothing to checkout");
      }, 1500);
      navigate("/profile");
    }
  }, [cart]);

  return (
    <div className="w-full flex justify-center mt-6">
      {active === 1 && (
        <div className="flex flex-col w-full">
          <div className="flex gap-5 800px:flex-row flex-col w-full justify-center 800px:items-start">
            <ShippingInfo formData={formData} setFormData={setFormData} />
            <CartInfo
              formData={formData}
              setActive={setActive}
              active={active}
            />
          </div>
        </div>
      )}
      {active === 2 && (
        <div className="flex flex-col w-full">
          <div className="flex gap-5 800px:flex-row flex-col w-full justify-center 800px:items-start">
            <PaymentGateways
              setActive={setActive}
              orderData={orderData}
              setOrderData={setOrderData}
            />
            <CartInfo
              active={active}
              setActive={setActive}
              orderData={orderData}
            />
          </div>
        </div>
      )}

      {active === 3 && <Success />}
    </div>
  );
};

export default Checkout;
