import { useState } from "react";
import { useSelector } from "react-redux";
import styles from "../../styles/styles";
import { Country, State } from "country-state-city";

const ShippingInfo = ({ formData, setFormData }) => {
  const { user } = useSelector((state) => state.user);
  const [selectedAddress, setSelectedAddress] = useState(null);
  const [toggleAddress, setToggleAddress] = useState(false);

  const handleFormChange = (e) => {
    const { name, value } = e.target;

    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
  };

  return (
    <div className="800px:w-[40%] py-7 flex flex-col bg-white px-4 rounded-sm">
      <div className="border-b pb-1">
        <h3 className="text-lg font-semibold">Shipping Address</h3>
      </div>

      <form
        action=""
        onSubmit={handleSubmit}
        className="grid 800px:grid-cols-2 grid-cols-1 gap-4 mt-4"
      >
        <div>
          <label htmlFor="">Full Name</label>{" "}
          <span className="text-red-400">*</span>
          <input
            type="text"
            name="name"
            value={formData.name}
            onChange={handleFormChange}
            className={`${styles.input}`}
            required
          />
        </div>

        <div>
          <label htmlFor="">Email Address</label>
          <input
            type="email"
            name="email"
            value={formData.email}
            onChange={handleFormChange}
            className={`${styles.input}`}
          />
        </div>

        <div>
          <label htmlFor="">Phone Number</label>{" "}
          <span className="text-red-400">*</span>
          <input
            type="text"
            name="phoneNumber"
            value={formData.phoneNumber}
            className={`${styles.input}`}
            onChange={handleFormChange}
            required
          />
        </div>

        <div>
          <label htmlFor="">Zip Code</label>
          <input
            type="number"
            name="zipCode"
            value={formData.zipCode}
            className={`${styles.input}`}
            onChange={handleFormChange}
          />
        </div>

        <div className="flex flex-col">
          <label htmlFor="country">
            Country <span className="text-red-400">*</span>
          </label>
          <select
            name="country"
            id="country"
            value={formData.country}
            className={`${styles.input}`}
            onChange={handleFormChange}
            required
          >
            <option value="">Select your country</option>
            {Country &&
              Country.getAllCountries().map((i) => (
                <option key={i.isoCode} value={i.isoCode}>
                  {i.name}
                </option>
              ))}
          </select>
        </div>
        <div className="flex flex-col">
          <label htmlFor="country">
            City <span className="text-red-400">*</span>
          </label>
          <select
            name="city"
            id="city"
            value={formData.city}
            className={`${styles.input}`}
            onChange={handleFormChange}
            required
          >
            <option value="">Select your city</option>
            {State &&
              State.getStatesOfCountry(formData.country).map((i) => (
                <option key={i.isoCode} value={i.isoCode}>
                  {i.name}
                </option>
              ))}
          </select>
        </div>

        <div>
          <label htmlFor="">
            Address1 <span className="text-red-400">*</span>
          </label>
          <input
            type="text"
            name="address1"
            value={formData.address1}
            className={`${styles.input}`}
            onChange={handleFormChange}
            required
          />
        </div>

        <div>
          <label htmlFor="">Address2</label>
          <input
            type="text"
            name="address2"
            value={formData.address2}
            className={`${styles.input}`}
            onChange={handleFormChange}
          />
        </div>
      </form>

      <div>
        <button
          className={`inline-block mt-4 font-[500] border py-1 px-1 border-yellow-400 bg-yellow-100 ${
            !toggleAddress ? "animate-pulse" : " px-4"
          }`}
          onClick={() => setToggleAddress(!toggleAddress)}
        >
          {!toggleAddress ? "Or choose from saved addresses" : "Your Addresses"}
        </button>

        {toggleAddress &&
          user &&
          user?.addresses.length > 0 &&
          user.addresses.map((item, index) => (
            <div className="w-full flex mt-1.5" key={index}>
              <input
                id={item.addressType}
                type="checkbox"
                className="mr-2"
                value={item?.addressType}
                checked={selectedAddress === item?.addressType}
                onChange={() => {
                  setSelectedAddress(item?.addressType);
                  setFormData((prev) => ({
                    ...prev,
                    country: item?.country,
                    city: item?.city,
                    address1: item?.address1,
                    address2: item?.address2,
                    zipCode: item?.zipCode,
                  }));
                }}
              />
              <label htmlFor={item.addressType} className="font-light">
                {item?.addressType}
              </label>
            </div>
          ))}
      </div>
    </div>
  );
};

export default ShippingInfo;
