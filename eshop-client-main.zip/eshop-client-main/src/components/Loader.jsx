import React from "react";
import Lottie from "react-lottie";
import animationData from "./../assets/animation/24151-ecommerce-animation.json";

const Loader = () => {
  const defaultOptions = {
    loop: true,
    autoplay: true,
    animationData: animationData,
    rendererSettings: {
      preserveAspectRatio: "xMidYMid slice",
    },
  };
  return (
    <div className="w-full h-screen flex items-center justify-center flex-col gap-3 font-Poppins">
      <Lottie options={defaultOptions} width={300} height={300} />
      <h4 className="text-lg">Loading ...</h4>
    </div>
  );
};

export default Loader;
