import axios from "axios";
import { server } from "../../server";

export const createProduct = (newFormData) => async (dispatch) => {
  try {
    dispatch({
      type: "createProductRequest",
    });

    const configs = {
      headers: { "Contect-Type": "multipart/form-data" },
      withCredentials: true,
    };

    const { data } = await axios.post(
      `${server}/product/create-product`,
      newFormData,
      configs
    );

    dispatch({
      type: "createProductSuccess",
      payload: data.product,
    });
  } catch (error) {
    dispatch({
      type: "createProductFail",
      payload: error.response.data.message,
    });
  }
};

export const getAllProductsForShop = (shopId) => async (dispatch) => {
  try {
    dispatch({
      type: "getAllProductsForShopRequest",
    });

    const { data } = await axios.get(
      `${server}/product/get-products-shop/${shopId}`
    );

    dispatch({
      type: "getAllProductsForShopSuccess",
      payload: data.products,
    });
  } catch (error) {
    dispatch({
      type: "getAllProductsForShopFailed",
      payload: error.response.data.message,
    });
  }
};

// get all products
export const getAllProducts = () => async (dispatch) => {
  try {
    dispatch({
      type: "getAllProductsRequest",
    });

    const { data } = await axios.get(`${server}/product/get-all-products`);
    dispatch({
      type: "getAllProductsSuccess",
      payload: data.products,
    });
  } catch (error) {
    dispatch({
      type: "getAllProductsFailed",
      payload: error.response.data.message,
    });
  }
};

export const deleteProduct = (productId) => async (dispatch) => {
  try {
    dispatch({
      type: "deleteProductRequest",
    });

    await axios.delete(`${server}/product/delete-shop-product/${productId}`, {
      withCredentials: true,
    });

    dispatch({
      type: "deleteProductSuccess",
      payload: productId, // Send only productId back
    });
  } catch (error) {
    dispatch({
      type: "deleteProductFailed",
      payload: error.response.data.message,
    });
  }
};
