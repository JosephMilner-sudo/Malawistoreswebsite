import axios from "axios";
import { server } from "../../server";

export const getAllOrdersForUser = (userId) => async (dispatch) => {
  try {
    dispatch({
      type: "loadUserOrdersRequest",
    });

    const { data } = await axios.get(
      `${server}/order/get-all-orders/${userId}`,
      { withCredentials: true }
    );

    dispatch({
      type: "loadUserOrdersSuccess",
      payload: data.orders,
    });
  } catch (error) {
    dispatch({
      type: "loadUserOrdersFail",
      payload: error.response.data.message,
    });
  }
};

export const getAllOrdersForShop = (shopId) => async (dispatch) => {
  try {
    dispatch({
      type: "loadShopOrdersRequest",
    });

    const { data } = await axios.get(
      `${server}/order/get-all-shop-orders/${shopId}`,
      { withCredentials: true }
    );

    dispatch({
      type: "loadShopOrdersSuccess",
      payload: data.orders,
    });
  } catch (error) {
    dispatch({
      type: "loadShopOrdersFail",
      payload: error.response.data.message,
    });
  }
};

//get all orders
export const getAllOrders = () => async (dispatch) => {
  try {
    dispatch({
      type: "loadAllOrdersRequest",
    });

    const { data } = await axios.get(`${server}/order/get-all-orders`, {
      withCredentials: true,
    });

    dispatch({
      type: "loadAllOrdersSuccess",
      payload: data.orders,
    });
  } catch (error) {
    dispatch({
      type: "loadAllOrdersFail",
      payload: error.response.data.message,
    });
  }
};
