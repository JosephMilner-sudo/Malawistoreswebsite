import axios from "axios";
import { server } from "../../server";

export const createEvent = (newFormData) => async (dispatch) => {
  try {
    dispatch({
      type: "createEventRequest",
    });

    const configs = {
      headers: { "Contect-Type": "multipart/form-data" },
      withCredentials: true,
    };

    const { data } = await axios.post(
      `${server}/event/create-event`,
      newFormData,
      configs
    );

    dispatch({
      type: "createEventSuccess",
      payload: data.event,
    });
  } catch (error) {
    dispatch({
      type: "createEventFail",
      payload: error.response.data.message,
    });
  }
};

export const getAllEvents = () => async (dispatch) => {
  try {
    dispatch({
      type: "getAllEventsRequest",
    });

    const { data } = await axios.get(`${server}/event/get-events`);

    dispatch({
      type: "getAllEventsSuccess",
      payload: data.events,
    });
  } catch (error) {
    dispatch({
      type: "getAllEventsFailed",
      payload: error.response.data.message,
    });
  }
};

export const getAllEventsForShop = (shopId) => async (dispatch) => {
  try {
    dispatch({
      type: "getAllEventsForShopRequest",
    });

    const { data } = await axios.get(
      `${server}/event/get-events-shop/${shopId}`
    );

    dispatch({
      type: "getAllEventsForShopSuccess",
      payload: data.events,
    });
  } catch (error) {
    dispatch({
      type: "getAllEventsForShopFailed",
      payload: error.response.data.message,
    });
  }
};

export const deleteEvent = (productId) => async (dispatch) => {
  try {
    dispatch({
      type: "deleteEventRequest",
    });

    await axios.delete(`${server}/event/delete-shop-event/${productId}`, {
      withCredentials: true,
    });

    dispatch({
      type: "deleteEventSuccess",
      payload: productId, // Send only productId back
    });
  } catch (error) {
    dispatch({
      type: "deleteEventFailed",
      payload: error.response.data.message,
    });
  }
};
