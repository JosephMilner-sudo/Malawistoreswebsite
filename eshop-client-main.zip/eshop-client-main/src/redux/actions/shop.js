import axios from "axios";
import { server } from "./../../server";

//load shop action
export const loadShop = () => async (dispatch) => {
  try {
    dispatch({
      type: "LoadShopRequest",
    });

    const { data } = await axios.get(`${server}/shop/get-shop`, {
      withCredentials: true,
    });

    dispatch({
      type: "LoadShopSuccess",
      payload: data.shop,
    });
  } catch (error) {
    dispatch({
      type: "LoadShopFail",
      payload: error.response.data.message,
    });
  }
};

//load shop action
export const loadShopPreview = (id) => async (dispatch) => {
  try {
    dispatch({
      type: "LoadShopPreviewRequest",
    });

    const { data } = await axios.get(`${server}/shop/get-shop-preview/${id}`);

    dispatch({
      type: "LoadShopPreviewSuccess",
      payload: data.shop,
    });
  } catch (error) {
    dispatch({
      type: "LoadShopPreviewFail",
      payload: error.response.data.message,
    });
  }
};
