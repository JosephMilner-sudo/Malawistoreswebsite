import axios from "axios";
import { server } from "./../../server";

//load user action
export const loadUser = () => async (dispatch) => {
  try {
    dispatch({
      type: "LoadUserRequest",
    });

    const { data } = await axios.get(`${server}/user/get-user`, {
      withCredentials: true,
    });

    dispatch({
      type: "LoadUserSuccess",
      payload: data ? data.user : {},
    });
  } catch (error) {
    dispatch({
      type: "LoadUserFail",
      payload: error.response.data.message,
    });
  }
};

//update user info
export const updateUserInfo = (userInfo) => async (dispatch) => {
  try {
    dispatch({
      type: "updateUserRequest",
    });

    const { data } = await axios.put(
      `${server}/user/update-user-info`,
      { ...userInfo },
      {
        withCredentials: true,
      }
    );

    dispatch({
      type: "updateUserSuccess",
      payload: data.user,
    });
  } catch (error) {
    dispatch({
      type: "updateUserFailed",
      payload: error.response.data.message,
    });
  }
};

//update user address info
export const updateUserAddressInfo = (addressInfo) => async (dispatch) => {
  try {
    dispatch({
      type: "updateUserAddressRequest",
    });

    const { data } = await axios.put(
      `${server}/user/update-user-addresses`,
      { ...addressInfo },
      {
        withCredentials: true,
      }
    );

    dispatch({
      type: "updateUserAddressSuccess",
      payload: data.user,
    });
  } catch (error) {
    dispatch({
      type: "updateUserAddressFailed",
      payload: error.response.data.message,
    });
  }
};

//delete user address info
export const deleteUserAddressInfo = (addressId) => async (dispatch) => {
  try {
    dispatch({
      type: "deleteUserAddressRequest",
    });

    const { data } = await axios.delete(
      `${server}/user/delete-user-address/${addressId}`,
      {
        withCredentials: true,
      }
    );

    dispatch({
      type: "deleteUserAddressSuccess",
      payload: data.user,
    });
  } catch (error) {
    dispatch({
      type: "deleteUserAddressFailed",
      payload: error.response.data.message,
    });
  }
};
