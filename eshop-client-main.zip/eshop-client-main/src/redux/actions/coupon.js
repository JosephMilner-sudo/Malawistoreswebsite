import axios from "axios";
import { server } from "../../server";

export const createCoupon = (newFormData) => async (dispatch) => {
  try {
    dispatch({
      type: "createCouponRequest",
    });

    const configs = {
      withCredentials: true,
    };

    const { data } = await axios.post(
      `${server}/coupon/create-coupon`,
      newFormData,
      configs
    );

    dispatch({
      type: "createCouponSuccess",
      payload: data.coupon,
    });
  } catch (error) {
    dispatch({
      type: "createCouponFail",
      payload: error.response.data.message,
    });
  }
};

export const getAllCouponsForShop = (shopId) => async (dispatch) => {
  try {
    dispatch({
      type: "getAllCouponsForShopRequest",
    });

    const { data } = await axios.get(
      `${server}/coupon/get-coupons-shop/${shopId}`
    );

    dispatch({
      type: "getAllCouponsForShopSuccess",
      payload: data.coupons,
    });
  } catch (error) {
    dispatch({
      type: "getAllCouponsForShopFailed",
      payload: error.response.data.message,
    });
  }
};

export const deleteCoupon = (id) => async (dispatch) => {
  try {
    dispatch({
      type: "deleteCouponRequest",
    });

    await axios.delete(`${server}/coupon/delete-shop-coupon/${id}`, {
      withCredentials: true,
    });

    dispatch({
      type: "deleteCouponSuccess",
      payload: id,
    });
  } catch (error) {
    dispatch({
      type: "deleteCouponFailed",
      payload: error.response.data.message,
    });
  }
};
