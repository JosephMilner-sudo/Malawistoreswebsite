import axios from "axios";
import { server } from "../../server";

//load user action
export const loadSystemUser = () => async (dispatch) => {
  try {
    dispatch({
      type: "LoadAdminRequest",
    });

    const { data } = await axios.get(`${server}/system/get-user`, {
      withCredentials: true,
    });

    dispatch({
      type: "LoadAdminSuccess",
      payload: data ? data.user : {},
    });
  } catch (error) {
    dispatch({
      type: "LoadAdminFail",
      payload: error.response.data.message,
    });
  }
};

//update user info
export const updateUserInfo = (userInfo) => async (dispatch) => {
  try {
    dispatch({
      type: "updateAdminRequest",
    });

    const { data } = await axios.put(
      `${server}/system/update-user-info`,
      { ...userInfo },
      {
        withCredentials: true,
      }
    );

    dispatch({
      type: "updateAdminSuccess",
      payload: data.user,
    });
  } catch (error) {
    dispatch({
      type: "updateAdminFailed",
      payload: error.response.data.message,
    });
  }
};
