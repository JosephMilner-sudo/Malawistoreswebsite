export const addToList = (data) => async (dispatch, getState) => {
  dispatch({
    type: "addToList",
    payload: data,
  });

  localStorage.setItem(
    "wishlistItems",
    JSON.stringify(getState().wishlist.wishlist)
  );
  return data;
};

export const removeFromList = (data) => async (dispatch, getState) => {
  dispatch({
    type: "removeFromList",
    payload: data._id,
  });

  localStorage.setItem(
    "wishlistItems",
    JSON.stringify(getState().wishlist.wishlist)
  );
  return data;
};
