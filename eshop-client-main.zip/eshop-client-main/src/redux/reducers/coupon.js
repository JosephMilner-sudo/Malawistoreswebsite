import { createReducer } from "@reduxjs/toolkit";

const initialState = {
  loading: false,
  success: false,
  coupon: null,
  error: null,
  coupons: null,
  message: null,
};

export const couponReducer = createReducer(initialState, (builder) => {
  builder
    //create product
    .addCase("createCouponRequest", (state) => {
      state.loading = true;
    })
    .addCase("createCouponSuccess", (state, action) => {
      state.loading = false;
      state.success = true;
      state.coupon = action.payload;
      state.coupons = [...state.coupons, state.coupon];
      state.error = null;
    })
    .addCase("createCouponFail", (state, action) => {
      state.loading = false;
      state.success = false;
      state.error = action.payload;
    })

    //get products for a shop
    .addCase("getAllCouponsForShopRequest", (state) => {
      state.loading = true;
    })
    .addCase("getAllCouponsForShopSuccess", (state, action) => {
      state.loading = false;
      state.coupons = action.payload;
      state.error = null;
    })
    .addCase("getAllCouponsForShopFailed", (state, action) => {
      state.loading = false;
      state.error = action.payload;
    })

    //delete product
    .addCase("deleteCouponRequest", (state) => {
      state.loading = true;
    })
    .addCase("deleteCouponSuccess", (state, action) => {
      state.loading = false;
      state.message = action.payload;
      state.error = null;
      state.coupons = state.coupons.filter(
        (coupon) => coupon._id !== action.payload
      );
    })
    .addCase("deleteCouponFailed", (state, action) => {
      state.loading = false;
      state.error = action.payload;
    })

    //other states
    .addCase("clearState", () => initialState) // Reset state to initial
    .addCase("clearError", (state) => {
      state.error = null;
    });
});
