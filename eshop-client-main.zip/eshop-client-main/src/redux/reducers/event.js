import { createReducer } from "@reduxjs/toolkit";

const initialState = {
  loading: false,
  success: false,
  event: null,
  error: null,
  events: null,
  allEvents: null,
  message: null,
};

export const eventReducer = createReducer(initialState, (builder) => {
  builder
    //create product
    .addCase("createEventRequest", (state) => {
      state.loading = true;
      state.error = null;
      state.success = false;
    })
    .addCase("createEventSuccess", (state, action) => {
      state.loading = false;
      state.success = true;
      state.event = action.payload;
    })
    .addCase("createEventFail", (state, action) => {
      state.loading = false;
      state.error = action.payload;
    })

    //get products for a shop
    .addCase("getAllEventsForShopRequest", (state) => {
      state.loading = true;
      state.error = null;
    })
    .addCase("getAllEventsForShopSuccess", (state, action) => {
      state.loading = false;
      state.events = action.payload;
    })
    .addCase("getAllEventsForShopFailed", (state, action) => {
      state.loading = false;
      state.error = action.payload;
    })

    //get all events
    .addCase("getAllEventsRequest", (state) => {
      state.loading = true;
      state.error = null;
    })
    .addCase("getAllEventsSuccess", (state, action) => {
      state.loading = false;
      state.allEvents = action.payload;
    })
    .addCase("getAllEventsFailed", (state, action) => {
      state.loading = false;
      state.error = action.payload;
    })

    //delete product
    .addCase("deleteEventRequest", (state) => {
      state.loading = true;
      state.error = null;
    })
    .addCase("deleteEventSuccess", (state, action) => {
      state.loading = false;
      state.message = action.payload;
      state.events = state.events.filter(
        (event) => event._id !== action.payload
      );
    })
    .addCase("deleteEventFailed", (state, action) => {
      state.loading = false;
      state.error = action.payload;
    })

    //other states
    .addCase("clearState", () => initialState) // Reset state to initial
    .addCase("clearError", (state) => {
      state.error = null;
    });
});
