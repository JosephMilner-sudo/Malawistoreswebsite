import { createReducer } from "@reduxjs/toolkit";

const initialState = {
  isAuthenticated: false,
  loading: true, // Add loading state here
  user: null, // Ensure user field is initialized
  error: null, // Initialize error field
  success: false,
};

export const userReducer = createReducer(initialState, (builder) => {
  builder
    .addCase("LoadUserRequest", (state) => {
      state.loading = true;
    })
    .addCase("LoadUserSuccess", (state, action) => {
      state.isAuthenticated = true;
      state.loading = false;
      state.user = action.payload;
    })
    .addCase("LoadUserFail", (state, action) => {
      state.isAuthenticated = false;
      state.loading = false;
      state.error = action.payload;
    })

    //update user info
    .addCase("updateUserRequest", (state) => {
      state.loading = true;
      state.success = false;
      state.error = null;
    })
    .addCase("updateUserSuccess", (state, action) => {
      state.loading = false;
      state.user = action.payload;
      state.success = true;
    })
    .addCase("updateUserFailed", (state, action) => {
      state.loading = false;
      state.error = action.payload;
    })

    //update user addresses info
    .addCase("updateUserAddressRequest", (state) => {
      state.addressLoading = true;
      state.success = false;
      state.error = null;
    })
    .addCase("updateUserAddressSuccess", (state, action) => {
      state.addressLoading = false;
      state.user = action.payload;
      state.success = true;
    })
    .addCase("updateUserAddressFailed", (state, action) => {
      state.addressLoading = false;
      state.error = action.payload;
    })

    //delete user addresses info
    .addCase("deleteUserAddressRequest", (state) => {
      state.addressLoading = true;
      state.success = false;
      state.error = null;
    })
    .addCase("deleteUserAddressSuccess", (state, action) => {
      state.addressLoading = false;
      state.user = action.payload;
      state.success = true;
    })
    .addCase("deleteUserAddressFailed", (state, action) => {
      state.addressLoading = false;
      state.error = action.payload;
    })

    .addCase("restoreLoading", (state) => {
      state.loading = false;
    })

    .addCase("ClearState", (state) => {
      state.error = null;
      state.success = false;
    })

    .addCase("ResetSuccess", (state) => {
      state.success = false;
    });

  // Reset state but keep loading unchanged
  //  .addCase("ResetState", (state) => {
  //   const currentLoading = state.loading;
  //   Object.assign(state, {
  //     ...initialState,
  //     loading: currentLoading, // Preserve the current loading state
  //   });
  // });
});
