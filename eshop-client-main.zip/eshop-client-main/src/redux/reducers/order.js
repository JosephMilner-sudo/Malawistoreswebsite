import { createReducer } from "@reduxjs/toolkit";

const initialState = {
  loading: false,
  success: false,
  orders: null,
  error: null,
  message: null,
  allOrders: null,
};

export const orderReducer = createReducer(initialState, (builder) => {
  builder
    //load user orders
    .addCase("loadUserOrdersRequest", (state) => {
      state.loading = true;
      state.error = null;
      state.success = false;
    })
    .addCase("loadUserOrdersSuccess", (state, action) => {
      state.loading = false;
      state.success = true;
      state.orders = action.payload;
    })
    .addCase("loadUserOrdersFail", (state, action) => {
      state.loading = false;
      state.error = action.payload;
    })

    //load shop orders
    .addCase("loadShopOrdersRequest", (state) => {
      state.loading = true;
      state.error = null;
      state.success = false;
    })
    .addCase("loadShopOrdersSuccess", (state, action) => {
      state.loading = false;
      state.success = true;
      state.orders = action.payload;
    })
    .addCase("loadShopOrdersFail", (state, action) => {
      state.loading = false;
      state.error = action.payload;
    })

    .addCase("loadAllOrdersRequest", (state) => {
      state.loading = true;
      state.error = null;
      state.success = false;
    })
    .addCase("loadAllOrdersSuccess", (state, action) => {
      state.loading = false;
      state.success = true;
      state.orders = action.payload;
    })
    .addCase("loadAllOrdersFail", (state, action) => {
      state.loading = false;
      state.error = action.payload;
    })

    //delete product
    .addCase("deleteUserOrdersRequest", (state) => {
      state.loading = true;
    })
    .addCase("deleteUserOrdersSuccess", (state, action) => {
      state.loading = false;
      state.message = action.payload;
      state.products = state.products.filter(
        (product) => product._id !== action.payload
      );
    })
    .addCase("deleteUserOrdersFailed", (state, action) => {
      state.loading = false;
      state.error = action.payload;
    })

    //other states
    .addCase("clearState", () => initialState) // Reset state to initial
    .addCase("clearError", (state) => {
      state.error = null;
    });
});
