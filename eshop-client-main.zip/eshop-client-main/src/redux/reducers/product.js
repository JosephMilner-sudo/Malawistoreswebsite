import { createReducer } from "@reduxjs/toolkit";

const initialState = {
  loading: false,
  success: false,
  product: null,
  error: null,
  products: null,
  message: null,
  allProducts: null,
};

export const productReducer = createReducer(initialState, (builder) => {
  builder
    //create product
    .addCase("createProductRequest", (state) => {
      state.loading = true;
      state.error = null;
      state.success = false;
    })
    .addCase("createProductSuccess", (state, action) => {
      state.loading = false;
      state.success = true;
      state.product = action.payload;
    })
    .addCase("createProductFail", (state, action) => {
      state.loading = false;
      state.error = action.payload;
    })

    //get products for a shop
    .addCase("getAllProductsForShopRequest", (state) => {
      state.loading = true;
      state.error = null;
    })
    .addCase("getAllProductsForShopSuccess", (state, action) => {
      state.loading = false;
      state.products = action.payload;
    })
    .addCase("getAllProductsForShopFailed", (state, action) => {
      state.loading = false;
      state.error = action.payload;
    })

    //get all products
    .addCase("getAllProductsRequest", (state) => {
      state.loading = true;
      state.error = null;
    })
    .addCase("getAllProductsSuccess", (state, action) => {
      state.loading = false;
      state.allProducts = action.payload;
    })
    .addCase("getAllProductsFailed", (state, action) => {
      state.loading = false;
      state.error = action.payload;
    })

    //delete product
    .addCase("deleteProductRequest", (state) => {
      state.loading = true;
    })
    .addCase("deleteProductSuccess", (state, action) => {
      state.loading = false;
      state.message = action.payload;
      state.products = state.products.filter(
        (product) => product._id !== action.payload
      );
    })
    .addCase("deleteProductFailed", (state, action) => {
      state.loading = false;
      state.error = action.payload;
    })

    //other states
    .addCase("clearState", () => initialState) // Reset state to initial
    .addCase("clearError", (state) => {
      state.error = null;
    });
});
