import { createReducer } from "@reduxjs/toolkit";

const initialState = {
  isAuthenticated: false,
  loading: true, // Add loading state here
  shop: null, // Ensure Shop field is initialized
  error: null, // Initialize error field
  shopPreview: null,
  previewLoading: true,
  shopPreviewError: null,
};

export const shopReducer = createReducer(initialState, (builder) => {
  builder
    .addCase("LoadShopRequest", (state) => {
      state.loading = true;
    })
    .addCase("LoadShopSuccess", (state, action) => {
      state.isAuthenticated = true;
      state.loading = false;
      state.shop = action.payload;
    })
    .addCase("LoadShopFail", (state, action) => {
      state.isAuthenticated = false;
      state.loading = false;
      state.error = action.payload;
    })

    .addCase("LoadShopPreviewRequest", (state) => {
      state.previewLoading = true;
    })
    .addCase("LoadShopPreviewSuccess", (state, action) => {
      state.previewLoading = false;
      state.shopPreview = action.payload;
      state.shopPreviewError = null;
    })
    .addCase("LoadShopPreviewFail", (state, action) => {
      state.previewLoading = false;
      state.shopPreviewError = action.payload;
    })

    .addCase("restoreLoading", (state) => {
      state.loading = false;
    })
    .addCase("ClearError", (state) => {
      state.error = null;
    });
});
