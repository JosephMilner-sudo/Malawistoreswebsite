import { createReducer } from "@reduxjs/toolkit";

const initialState = {
  isAuthenticated: false,
  loading: false, // Add loading state here
  admin: null, // Ensure admin field is initialized
  error: null, // Initialize error field
  success: false,
};

export const systemReducer = createReducer(initialState, (builder) => {
  builder
    .addCase("LoadAdminRequest", (state) => {
      state.loading = true;
    })
    .addCase("LoadAdminSuccess", (state, action) => {
      state.isAuthenticated = true;
      state.loading = false;
      state.admin = action.payload;
    })
    .addCase("LoadAdminFail", (state, action) => {
      state.isAuthenticated = false;
      state.loading = false;
      state.error = action.payload;
    })

    //update admin info
    .addCase("updateAdminRequest", (state) => {
      state.loading = true;
      state.success = false;
      state.error = null;
    })
    .addCase("updateAdminSuccess", (state, action) => {
      state.loading = false;
      state.admin = action.payload;
      state.success = true;
    })
    .addCase("updateAdminFailed", (state, action) => {
      state.loading = false;
      state.error = action.payload;
    })

    .addCase("restoreLoading", (state) => {
      state.loading = false;
    })

    .addCase("ClearState", (state) => {
      state.error = null;
      state.success = false;
    })

    .addCase("ResetSuccess", (state) => {
      state.success = false;
    });

  // Reset state but keep loading unchanged
  //  .addCase("ResetState", (state) => {
  //   const currentLoading = state.loading;
  //   Object.assign(state, {
  //     ...initialState,
  //     loading: currentLoading, // Preserve the current loading state
  //   });
  // });
});
