const mongoose = require("mongoose");

const eventSchema = new mongoose.Schema(
  {
    name: {
      type: String,
      required: [true, "Please enter product name"],
      trim: true,
    },
    description: {
      type: String,
      required: [true, "Please enter product description"],
      trim: true,
    },
    originalPrice: {
      type: Number,
      required: [true, "Please enter product original price"],
      min: 0,
    },
    discountPrice: {
      type: Number,
      min: 0,
      validate: {
        validator: function (v) {
          return v <= this.originalPrice; // Discount price cannot be greater than original price
        },
        message: "Discount price cannot be greater than the original price.",
      },
    },
    stock: {
      type: Number,
      required: true,
      min: [1, "Stock must be a positive integer greater than zero."],
    },
    startDate: {
      type: Date,
      required: true,
    },
    endDate: {
      type: Date,
      required: true,
    },
    status: {
      type: String,
      required: true,
      default: "Running",
    },
    images: [
      {
        type: String, // Path to the image file (e.g., URL or local path)
        required: true,
      },
    ],
    shop: {
      type: Object,
      required: true,
    },
    soldOut: {
      type: Number,
      default: 0,
    },
    createdAt: {
      type: Date,
      default: Date.now,
    },
    updatedAt: {
      type: Date,
      default: Date.now,
    },
  },
  {
    timestamps: true, // Automatically adds createdAt and updatedAt fields
  }
);

// Add a pre-save hook to update the updatedAt field before saving
eventSchema.pre("save", function (next) {
  this.updatedAt = Date.now();
  next();
});

// Create the model
const Event = mongoose.model("Event", eventSchema);

module.exports = Event;
