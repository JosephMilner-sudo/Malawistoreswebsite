const mongoose = require("mongoose");

const couponSchema = new mongoose.Schema(
  {
    name: {
      type: String,
      required: [true, "Please enter coupon code name"],
      trim: true,
      unique: true,
    },
    value: {
      type: Number,
      required: [true, "Please enter coupon value"],
    },
    minAmount: {
      type: Number,
    },
    maxAmount: {
      type: Number,
    },
    product: {
      type: Object,
    },
    shop: {
      type: Object,
      required: true,
    },
    createdAt: {
      type: Date,
      default: Date.now,
    },
    updatedAt: {
      type: Date,
      default: Date.now,
    },
  },
  {
    timestamps: true, // Automatically adds createdAt and updatedAt fields
  }
);

// Add a pre-save hook to update the updatedAt field before saving
couponSchema.pre("save", function (next) {
  this.updatedAt = Date.now();
  next();
});

// Create the model
const Coupon = mongoose.model("Coupon", couponSchema);

module.exports = Coupon;
