const mongoose = require("mongoose");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");

const shopSchema = new mongoose.Schema(
  {
    // Basic Details
    name: { type: String, required: true, trim: true },
    description: { type: String, trim: true },
    logo: { type: String }, // Store as URL

    // Contact Details
    email: {
      type: String,
      match: [/.+@.+\..+/, "Invalid email"],
      index: true,
    },
    phone: {
      type: String,
      required: true,
      match: [/^\+?[0-9]{7,15}$/, "Invalid phone number"],
    },
    physicalAddress: { type: String, trim: true },
    city: { type: String, trim: true },
    country: { type: String, trim: true },
    postalCode: { type: String, trim: true },

    // Business Registration
    businessType: { type: String, required: true },
    tinCertificate: { type: String, required: true }, // Store as URL
    registrationCertificate: { type: String, required: true }, // Store as URL

    // Owner Details
    ownerName: { type: String, required: true, trim: true },
    ownerPhoneNumber: {
      type: String,
      required: true,
      match: [/^\+?[0-9]{7,15}$/, "Invalid phone number"],
    },
    ownerEmail: {
      type: String,
      required: true,
      unique: true,
      match: [/.+@.+\..+/, "Invalid owner email"],
      index: true,
    },
    nationalID: { type: String, required: true }, // Store as URL
    dateOfBirth: { type: Date, required: true }, // Date format
    gender: { type: String, enum: ["Male", "Female", "Other"], required: true }, // Gender options

    // Security Details
    password: { type: String, required: true, minLength: 6, select: false },
    securityQuestion: { type: String, select: false },
    securityAnswer: { type: String, select: false },

    // Approval Status
    isApproved: { type: Boolean, default: false }, // Admin approval status
    comment: { type: String },

    resetPasswordToken: String,
    resetPasswordTime: Date,
  },
  { timestamps: true } // Automatically adds createdAt and updatedAt fields
);

// Hash password before saving
shopSchema.pre("save", async function (next) {
  if (!this.isModified("password")) return next();
  this.password = await bcrypt.hash(this.password, 10);
  next();
});

// Generate JWT Token
shopSchema.methods.getJwtToken = function () {
  return jwt.sign({ id: this._id }, process.env.JWT_SECRET_KEY, {
    expiresIn: process.env.JWT_EXPIRES,
  });
};

// Compare Passwords
shopSchema.methods.comparePasswords = async function (inputPassword) {
  return await bcrypt.compare(inputPassword, this.password);
};

module.exports = mongoose.model("Shop", shopSchema);
