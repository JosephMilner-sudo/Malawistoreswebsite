const mongoose = require("mongoose");

const productSchema = new mongoose.Schema(
  {
    name: {
      type: String,
      required: [true, "Please enter product name"],
      trim: true,
    },
    description: {
      type: String,
      required: [true, "Please enter product description"],
      trim: true,
    },
    originalPrice: {
      type: Number,
      required: [true, "Please enter product original price"],
      min: 0,
    },
    category: {
      type: String,
      required: [true, "Please enter Category"],
    },
    discountPrice: {
      type: Number,
      min: 0,
      validate: {
        validator: function (v) {
          return v <= this.originalPrice; // Discount price cannot be greater than original price
        },
        message: "Discount price cannot be greater than the original price.",
      },
    },
    stock: {
      type: Number,
      required: true,
      min: [1, "Stock must be a positive integer greater than zero."],
    },
    reviews: [
      {
        user: {
          type: Object,
        },
        rating: {
          type: Number,
        },
        comment: {
          type: String,
        },
        productId: {
          type: String,
        },
        createdAt: {
          type: Date,
          default: Date.now(),
        },
      },
    ],
    ratings: {
      type: Number,
    },
    images: [
      {
        type: String, // Path to the image file (e.g., URL or local path)
        required: true,
      },
    ],
    shop: {
      type: Object,
      required: true,
    },
    soldOut: {
      type: Number,
      default: 0,
    },
    createdAt: {
      type: Date,
      default: Date.now(),
    },
    updatedAt: {
      type: Date,
      default: Date.now(),
    },
  },
  {
    timestamps: true, // Automatically adds createdAt and updatedAt fields
  }
);

// Add a pre-save hook to update the updatedAt field before saving
productSchema.pre("save", function (next) {
  this.updatedAt = Date.now();
  next();
});

// Create the model
const Product = mongoose.model("Product", productSchema);

module.exports = Product;
