const nodemailer = require("nodemailer");

module.exports = async ({ receiver, subject, htmlMessage }) => {
  var transporter = nodemailer.createTransport({
    service: process.env.MAIL_SERVICE,
    auth: {
      user: process.env.SERVER_EMAIL,
      pass: process.env.EMAIL_SECURITY_KEY,
    },
  });

  var mailOptions = {
    from: process.env.SERVER_EMAIL,
    to: receiver,
    subject: subject, 
    html: htmlMessage,
  };

  transporter.sendMail(mailOptions, function (error, info) {
    if (error) {
      console.log(error);
    } else {
      console.log("Email sent: " + info.response);
    }
  });
};
