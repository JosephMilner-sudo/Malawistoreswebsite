const sendAdminTokenToCookie = (admin, statusCode, res) => {
  const adminToken = admin.getJwtToken();

  const isProduction = process.env.NODE_ENV === "production";

  const options = {
    expires: new Date(Date.now() + 3 * 24 * 60 * 60 * 1000), // 3 days
    httpOnly: true,
    secure: isProduction,
    sameSite: isProduction ? "None" : "Lax",
  };

  return res.status(statusCode).cookie("adminToken", adminToken, options).json({
    success: true,
    admin,
    adminToken,
  });
};

module.exports = sendAdminTokenToCookie;
