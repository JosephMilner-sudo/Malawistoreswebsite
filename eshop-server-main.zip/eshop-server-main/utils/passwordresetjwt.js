const jwt = require("jsonwebtoken");

const sendCustomerPwdResetToken = (user, statusCode, res) => {
  //generate a random 4 digit integer
  const generatedInteger = generateRandomFourDigit();

  const token = jwt.sign({ token: generatedInteger }, "XCCDKDKDOEO", {
    expiresIn: "10m",
  });

  const isProduction = process.env.NODE_ENV === "production";

  const options = {
    expires: new Date(Date.now() + 10 * 60 * 1000), //10 minutes
    httpOnly: true,
    secure: isProduction,
    sameSite: isProduction ? "None" : "Lax",
  };

  return res
    .status(statusCode)
    .cookie("customerPwdToken", token, options)
    .json({
      success: true,
      user,
      token,
    });
};

function generateRandomFourDigit() {
  return Math.floor(1000 + Math.random() * 9000);
}

module.exports = {
  sendCustomerPwdResetToken,
};
