/**
 * Async Error Handler Middleware
 *
 * This higher-order function simplifies error handling in asynchronous
 * Express route handlers or middleware functions by automatically catching
 * errors and passing them to the next middleware.
 *
 * Usage:
 * const asyncHandler = require('./asyncHandler');
 * app.get('/example', asyncHandler(async (req, res, next) => {
 *   const data = await someAsyncOperation();
 *   res.json(data);
 * }));
 *
 * @param {Function} theFunc - An Express route handler or middleware function
 * @returns {Function} - A wrapped function that catches errors
 */

module.exports = (theFunc) => {
  // Validate that theFunc is a function
  if (typeof theFunc !== "function") {
    throw new TypeError("Expected theFunc to be a function");
  }

  // Return the wrapped function
  return (req, res, next) => {
    Promise.resolve(theFunc(req, res, next)).catch((error) => {
      // Log the error for debugging (optional, can be removed in production)
      console.error("Error caught in asyncHandler:", error);
      // Forward the error to the next middleware
      next(error);
    });
  };
};
