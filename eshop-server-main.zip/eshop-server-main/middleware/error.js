const ErrorHandler = require("../utils/ErrorHandler");

module.exports = (err, req, res, next) => {
  err.statusCode = err.statusCode || 500;
  err.message = err.message || "An unexpected error occurred on the server.";

  // Invalid MongoDB Object ID Error
  if (err.name === "CastError") {
    const message = `Resource not found. The ID '${err.value}' provided in the '${err.path}' field is invalid.`;
    err = new ErrorHandler(message, 400);
  }

  // Duplicate Key Error (MongoDB)
  if (err.code === 11000) {
    const duplicateField = Object.keys(err.keyValue)[0];
    const message = `Duplicate value detected. The field '${duplicateField}' must be unique, but '${err.keyValue[duplicateField]}' is already in use.`;
    err = new ErrorHandler(message, 400);
  }

  // Duplicate Key Error (MongoDB)
  if (err.code === 404) {
    const message = `Route not found`;
    err = new ErrorHandler(message, 404);
  }

  // Invalid JWT Error
  if (err.name === "JsonWebTokenError") {
    const message =
      "The provided token is invalid. Please ensure you are using a valid token and try again.";
    err = new ErrorHandler(message, 401);
  }

  // Expired JWT Error
  if (err.name === "TokenExpiredError") {
    const message =
      "Your session has expired. Please log in again to continue.";
    err = new ErrorHandler(message, 401);
  }

  // Default Error Response
  return res.status(err.statusCode).json({
    success: false,
    message: err.message,
  });
};
