const asyncHandler = require("./asyncHandler");
const ErrorHandler = require("../utils/ErrorHandler");
const jwt = require("jsonwebtoken");
const User = require("./../models/user");
const Shop = require("./../models/shop");
const System = require("./../models/system");

exports.isAuthenticated = asyncHandler(async (req, res, next) => {
  const { token } = req.cookies;

  if (!token) {
    return next(new ErrorHandler("Please login to continue", 400));
  }

  const decoded = jwt.verify(token, process.env.JWT_SECRET_KEY);

  req.user = await User.findById(decoded.id);

  next();
});

exports.isShopAuthenticated = asyncHandler(async (req, res, next) => {
  const { shopToken } = req.cookies;

  if (!shopToken) {
    return next(new ErrorHandler("Please login to continue", 400));
  }

  const decoded = jwt.verify(shopToken, process.env.JWT_SECRET_KEY);

  req.shop = await Shop.findById(decoded.id);

  next();
});

exports.isAdmin = asyncHandler(async (req, res, next) => {
  const { adminToken } = req.cookies;

  if (!adminToken) {
    return next(new ErrorHandler("Please login to continue", 400));
  }

  const decoded = jwt.verify(adminToken, process.env.JWT_SECRET_KEY);

  req.admin = await System.findById(decoded.id);

  next();
});
