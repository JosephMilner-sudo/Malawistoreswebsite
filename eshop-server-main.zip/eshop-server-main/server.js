const app = require("./app");
const connectDB = require("./db/Database");

require("dotenv").config()

const PORT = process.env.PORT || 8000;

//handling uncaught exception
process.on("uncaughtException", (err) => {
  console.log(`Error: ${err.message}`);
  console.log(
    "Shutting down server for the cost of handling uncaught expection"
  );
});

//connect db
connectDB()

//server creation
const server = app.listen(PORT, () => {
  console.log(`Server started on http://localhost:${PORT}`);
});

//unhandled promise rejection
process.on("unhandledRejection", (err) => {
  console.log(`Error: ${err.message}`);
  console.log("shutting down server");
  server.close(() => {
    process.exit(1);
  });
});
