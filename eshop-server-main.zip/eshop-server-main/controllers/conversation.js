const express = require("express");
const router = express.Router();
const Conversation = require("./../models/conversation");
const asyncHandler = require("../middleware/asyncHandler");
const ErrorHandler = require("../utils/ErrorHandler");
const {
  isShopAuthenticated,
  isAuthenticated,
} = require("./../middleware/auth");
const mongoose = require("mongoose");

//new conversation
router.post(
  "/create-conversation",
  asyncHandler(async (req, res, next) => {
    try {
      const { userId, shopId, groupTitle } = req.body;

      const isConversationExist = await Conversation.findOne({ groupTitle });

      if (isConversationExist) {
        const conversation = isConversationExist;

        return res.status(201).json({
          success: true,
          conversation,
        });
      }

      const conversation = await Conversation.create({
        members: [userId, shopId],
        groupTitle,
      });

      return res.status(201).json({
        success: true,
        conversation,
      });
    } catch (error) {
      return next(new ErrorHandler(error, 500));
    }
  })
);

//get shop conversations
router.get(
  "/get-shop-conversations/:shopId",
  isShopAuthenticated,
  asyncHandler(async (req, res, next) => {
    try {
      const conversations = await Conversation.find({
        members: { $in: [req.params.shopId] },
      }).sort({ updatedAt: -1, createdAt: -1 });

      return res.status(201).json({
        success: true,
        conversations,
      });
    } catch (error) {
      return next(new ErrorHandler(error, 500));
    }
  })
);

//get shop conversations
router.get(
  "/get-user-conversations/:userId",
  isAuthenticated,
  asyncHandler(async (req, res, next) => {
    try {
      const conversations = await Conversation.find({
        members: { $in: [req.params.userId] },
      }).sort({ updatedAt: -1, createdAt: -1 });

      return res.status(201).json({
        success: true,
        conversations,
      });
    } catch (error) {
      return next(new ErrorHandler(error, 500));
    }
  })
);

router.put(
  "/update-last-message/:id",
  asyncHandler(async (req, res, next) => {
    try {
      const { id } = req.params;
      const { lastMessage, lastMessageId } = req.body;

      console.log(id);

      // Check if ID is provided and valid
      if (!id || !mongoose.Types.ObjectId.isValid(id)) {
        return next(new ErrorHandler("Invalid conversation ID", 400));
      }

      const conversation = await Conversation.findByIdAndUpdate(
        id,
        { lastMessage, lastMessageId },
        { new: true, runValidators: true } // Ensures updated data is returned
      );

      if (!conversation) {
        return res.status(404).json({
          success: false,
          message: "Conversation not found",
        });
      }

      return res.status(200).json({
        success: true,
        conversation,
      });
    } catch (error) {
      return next(new ErrorHandler(error.message, 500));
    }
  })
);

module.exports = router;
