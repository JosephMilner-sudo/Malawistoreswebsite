const express = require("express");
const router = express.Router();
const Product = require("./../models/product");
const Order = require("./../models/order");
const {
  isShopAuthenticated,
  isAuthenticated,
  isAdmin,
} = require("../middleware/auth");
const { upload } = require("./../multer");
const asyncHandler = require("../middleware/asyncHandler");
const ErrorHandler = require("../utils/ErrorHandler");
const mongoose = require("mongoose");

const fs = require("fs");
const sendMail = require("../utils/sendMail");

//create product
router.post(
  "/create-product",
  isShopAuthenticated,
  upload.array("images"),
  asyncHandler(async (req, res, next) => {
    try {
      const shop = req.shop;

      if (!shop) {
        return next(new ErrorHandler("Shop not found", 400));
      }

      const files = req.files;
      const imgUrls = files.map((file) => `${file.filename}`);
      const productData = req.body;
      productData.images = imgUrls;
      productData.shop = shop;

      const product = await Product.create(productData);

      return res.status(201).json({ success: true, product });
    } catch (err) {
      return next(new ErrorHandler(err, 400));
    }
  })
);

router.get(
  "/get-products-shop/:shopId",
  asyncHandler(async (req, res, next) => {
    try {
      const { shopId } = req.params;

      // Validate ObjectId format before converting
      if (!mongoose.isValidObjectId(shopId)) {
        return next(new ErrorHandler("Invalid shopId format", 400));
      }

      const shopObjectId = new mongoose.Types.ObjectId(shopId);
      const products = await Product.find({ "shop._id": shopObjectId }).sort({
        createdAt: -1,
      });

      return res.status(200).json({ success: true, products });
    } catch (error) {
      return next(new ErrorHandler(error.message, 400));
    }
  })
);

// get all products
router.get(
  "/get-all-products",
  asyncHandler(async (req, res, next) => {
    try {
      const products = await Product.find().sort({ createdAt: -1 });

      res.status(201).json({
        success: true,
        products,
      });
    } catch (error) {
      return next(new ErrorHandler(error, 400));
    }
  })
);

router.put(
  "/modify-product-review",
  isAuthenticated,
  asyncHandler(async (req, res, next) => {
    try {
      const { user, comment, rating, productId, orderId } = req.body;
      const product = await Product.findById(productId);

      if (!product) {
        return next(new ErrorHandler("Product not found", 400));
      }

      const isReviewed = product.reviews.find(
        (rev) => rev.user._id.toString() === req.user._id.toString()
      );

      if (isReviewed) {
        isReviewed.rating = rating;
        isReviewed.comment = comment;
      } else {
        product.reviews.push({ user, comment, rating, productId });
      }

      // Recalculate average rating
      let avg = product.reviews.reduce((sum, rev) => sum + rev.rating, 0);
      product.ratings = avg / product.reviews.length;

      product.markModified("reviews"); // Ensure Mongoose detects changes
      await product.save({ validateBeforeSave: false });

      await Order.findByIdAndUpdate(
        orderId, // Find the order by its ID
        { $set: { "cart.$[elem].isReviewed": true } }, // Update the matching element's isReviewed field to true
        { arrayFilters: [{ "elem._id": productId }], new: true } // Filter elements where elem._id matches productId
      );

      return res.status(201).json({
        success: true,
        product,
      });
    } catch (error) {
      return next(new ErrorHandler(error, 500));
    }
  })
);

router.delete(
  "/delete-shop-product/:productId",
  isShopAuthenticated,
  asyncHandler(async (req, res, next) => {
    try {
      const productId = req.params.productId;
      const productData = await Product.findById(productId);

      if (!productData) {
        return next(new ErrorHandler("Product not found", 400));
      }

      productData.images.forEach((img) => {
        const filePath = `uploads/${img}`;

        fs.unlink(filePath, (error) => console.log(error));
      });

      const product = await Product.findByIdAndDelete(productId);

      return res.status(201).json({
        success: true,
        product,
      });
    } catch (err) {
      return next(new ErrorHandler(err, 400));
    }
  })
);

//delete product --- admin
router.delete(
  "/admin/:productId",
  isAdmin,
  asyncHandler(async (req, res, next) => {
    try {
      const productId = req.params.productId;

      // Populate shop details to access ownerEmail
      const productData = await Product.findById(productId);

      if (!productData) {
        return next(new ErrorHandler("Product not found", 400));
      }

      // Delete images from storage
      productData.images.forEach((img) => {
        const filePath = `uploads/${img}`;
        fs.unlink(filePath, (error) => console.log(error));
      });

      // Delete the product
      const product = await Product.findByIdAndDelete(productId);

      // Send email to shop owner
      await sendMail({
        receiver: productData?.shop?.ownerEmail,
        subject: "Product Removed from Malawi Store Platform Malawi",
        htmlMessage: `
          <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px; background-color: #f9f9f9; border-radius: 8px;">
            <div style="background-color: #8B0000; color: #ffffff; padding: 15px; border-radius: 8px 8px 0 0; text-align: center;">
              <h2>Product Removed</h2>
            </div>
            <div style="padding: 20px; background-color: #ffffff; border-radius: 0 0 8px 8px;">
              <p style="font-size: 16px; color: #333;">Dear ${
                productData.shop.ownerName
              },</p>
              <p style="font-size: 16px; color: #555;">
                We would like to inform you that your product <strong>"${
                  productData.name
                }"</strong> has been removed from <strong>Malawi Store Platform Malawi</strong> by the admin team.
              </p>
              <p style="font-size: 16px; color: #555;">
                If you believe this was done in error or need more information, please reach out to us through the admin support panel.
              </p>
              <p style="font-size: 14px; color: #888;">Thank you for your understanding.</p>
            </div>
            <div style="margin-top: 20px; text-align: center; font-size: 12px; color: #999;">
              <p style="margin: 0;">This is an automated email. Please do not reply directly to it.</p>
              <p style="margin: 0;">© ${new Date().getFullYear()} Malawi Store Platform Malawi. All rights reserved.</p>
            </div>
          </div>
        `,
      });

      return res.status(201).json({
        success: true,
        product,
      });
    } catch (err) {
      return next(new ErrorHandler(err.message || err, 400));
    }
  })
);

module.exports = router;
