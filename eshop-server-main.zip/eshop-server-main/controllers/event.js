const express = require("express");
const router = express.Router();
const Event = require("../models/event");
const { isShopAuthenticated, isAdmin } = require("../middleware/auth");
const { upload } = require("../multer");
const asyncHandler = require("../middleware/asyncHandler");
const ErrorHandler = require("../utils/ErrorHandler");
const mongoose = require("mongoose");

const fs = require("fs");
const sendMail = require("../utils/sendMail");

//create event
router.post(
  "/create-event",
  isShopAuthenticated,
  upload.array("images"),
  asyncHandler(async (req, res, next) => {
    try {
      const shop = req.shop;

      if (!shop) {
        return next(new ErrorHandler("Shop not found", 400));
      }

      const files = req.files;
      const imgUrls = files.map((file) => `${file.filename}`);
      const eventData = req.body;
      eventData.images = imgUrls;
      eventData.shop = shop;

      const event = await Event.create(eventData);

      return res.status(201).json({ success: true, event });
    } catch (err) {
      return next(new ErrorHandler(err, 400));
    }
  })
);

router.get(
  "/get-events-shop/:shopId",
  asyncHandler(async (req, res, next) => {
    try {
      const { shopId } = req.params;
      // Validate ObjectId format before converting
      if (!mongoose.isValidObjectId(shopId)) {
        return next(new ErrorHandler("Invalid shopId format", 400));
      }

      const shopObjectId = new mongoose.Types.ObjectId(shopId);
      const events = await Event.find({ "shop._id": shopObjectId });

      return res.status(201).json({ success: true, events });
    } catch (error) {
      return next(new ErrorHandler(error, 400));
    }
  })
);

//get All events
router.get(
  "/get-events",
  asyncHandler(async (req, res, next) => {
    try {
      const events = await Event.find();

      return res.status(201).json({ success: true, events });
    } catch (error) {
      return next(new ErrorHandler(error, 400));
    }
  })
);

router.delete(
  "/delete-shop-event/:productId",
  isShopAuthenticated,
  asyncHandler(async (req, res, next) => {
    try {
      const productId = req.params.productId;
      const eventData = await Event.findById(productId);

      if (!eventData) {
        return next(new ErrorHandler("Event not found", 500));
      }

      eventData.images.forEach((img) => {
        const filePath = `uploads/${img}`;

        fs.unlink(filePath, (error) => console.log(error));
      });

      const event = await Event.findByIdAndDelete(productId);

      return res.status(201).json({
        success: true,
        event,
      });
    } catch (err) {
      return next(new ErrorHandler(err, 400));
    }
  })
);

router.delete(
  "/delete-product-event/:tag/:productId",
  asyncHandler(async (req, res, next) => {
    try {
      const tag = req.params.tag;

      if (!tag) {
        return next(new ErrorHandler("Unsecure deletion", 400));
      }

      const productId = req.params.productId;
      const eventData = await Event.findById(productId);

      if (!eventData) {
        return next(new ErrorHandler("Event not found", 500));
      }

      eventData.images.forEach((img) => {
        const filePath = `uploads/${img}`;

        fs.unlink(filePath, (error) => console.log(error));
      });

      const event = await Event.findByIdAndDelete(productId);

      return res.status(201).json({
        success: true,
        event,
      });
    } catch (err) {
      return next(new ErrorHandler(err, 400));
    }
  })
);

//delete event --- admin
router.delete(
  "/admin/:productId",
  isAdmin,
  asyncHandler(async (req, res, next) => {
    try {
      const productId = req.params.productId;
      const productData = await Event.findById(productId);

      if (!productData) {
        return next(new ErrorHandler("Event not found", 500));
      }

      productData.images.forEach((img) => {
        const filePath = `uploads/${img}`;

        fs.unlink(filePath, (error) => console.log(error));
      });

      const event = await Event.findByIdAndDelete(productId);

      // Send email to shop owner
      await sendMail({
        receiver: productData?.shop?.ownerEmail,
        subject: "Product Event Removed from Malawi Store Platform",
        htmlMessage: `
          <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px; background-color: #f9f9f9; border-radius: 8px;">
            <div style="background-color: #8B0000; color: #ffffff; padding: 15px; border-radius: 8px 8px 0 0; text-align: center;">
              <h2>Product Event Removed</h2>
            </div>
            <div style="padding: 20px; background-color: #ffffff; border-radius: 0 0 8px 8px;">
              <p style="font-size: 16px; color: #333;">Dear ${
                productData.shop.ownerName
              },</p>
              <p style="font-size: 16px; color: #555;">
                We would like to inform you that your product <strong>"${
                  productData.name
                }"</strong> has been removed from <strong>Malawi Store Platform Malawi</strong> by the admin team.
              </p>
              <p style="font-size: 16px; color: #555;">
                If you believe this was done in error or need more information, please reach out to us through the admin support panel.
              </p>
              <p style="font-size: 14px; color: #888;">Thank you for your understanding.</p>
            </div>
            <div style="margin-top: 20px; text-align: center; font-size: 12px; color: #999;">
              <p style="margin: 0;">This is an automated email. Please do not reply directly to it.</p>
              <p style="margin: 0;">© ${new Date().getFullYear()} Malawi Store Platform. All rights reserved.</p>
            </div>
          </div>
        `,
      });

      return res.status(201).json({
        success: true,
        event,
      });
    } catch (err) {
      return next(new ErrorHandler(err, 400));
    }
  })
);

module.exports = router;
