const express = require("express");
const router = express.Router();
const Coupon = require("../models/coupon");
const Product = require("../models/product");
const { isShopAuthenticated } = require("../middleware/auth");
const asyncHandler = require("../middleware/asyncHandler");
const ErrorHandler = require("../utils/ErrorHandler");
const mongoose = require("mongoose");

//create coupon
router.post(
  "/create-coupon",
  isShopAuthenticated,
  asyncHandler(async (req, res, next) => {
    console.log(req.body);
    try {
      const shop = req.shop;
      const bodyData = req.body;

      if (!shop) {
        return next(new ErrorHandler("Shop not found", 400));
      }

      const isExist = await Coupon.findOne({ name: req.body.name });

      if (isExist) {
        return next(
          new ErrorHandler(
            "Coupon already exist - use a unique coupon name",
            400
          )
        );
      }

      if (bodyData.productId) {
        const product = await Product.findById(bodyData.productId);

        if (product) {
          bodyData.product = product;
        }
      }

      bodyData.shop = shop;

      const coupon = await Coupon.create(bodyData);

      return res.status(201).json({ success: true, coupon });
    } catch (err) {
      return next(new ErrorHandler(err, 400));
    }
  })
);

router.get(
  "/get-coupons-shop/:shopId",
  asyncHandler(async (req, res, next) => {
    try {
      const { shopId } = req.params;
      // Validate ObjectId format before converting
      if (!mongoose.isValidObjectId(shopId)) {
        return next(new ErrorHandler("Invalid shopId format", 400));
      }

      const shopObjectId = new mongoose.Types.ObjectId(shopId);

      const coupons = await Coupon.find({ "shop._id": shopObjectId });

      return res.status(201).json({ success: true, coupons });
    } catch (error) {
      console.log(error);
      return next(new ErrorHandler(error, 400));
    }
  })
);

//get coupon code
router.get(
  "/get-discount-code/:name",
  asyncHandler(async (req, res, next) => {
    try {
      const name = req.params.name;

      const discountCode = await Coupon.findOne({ name });

      return res.status(201).json({ success: true, discountCode });
    } catch (error) {
      return next(new ErrorHandler(error, 400));
    }
  })
);

router.delete(
  "/delete-shop-coupon/:id",
  isShopAuthenticated,
  asyncHandler(async (req, res, next) => {
    try {
      const id = req.params.id;
      const couponData = await Coupon.findById(id);

      if (!couponData) {
        return next(new ErrorHandler("Coupon not found", 500));
      }

      const coupon = await Coupon.findByIdAndDelete(id);

      return res.status(201).json({
        success: true,
        coupon,
      });
    } catch (err) {
      return next(new ErrorHandler(err, 400));
    }
  })
);

module.exports = router;
