const express = require("express");
const asyncHandler = require("../middleware/asyncHandler");
const ErrorHandler = require("../utils/ErrorHandler");
const router = express.Router();

const STRIPEAPIKEY =
  "pk_test_51R1oAz01FgT8omeXBKislI8RaKzdsuiaPtEumYVBW5Xbrx6rJ7XJSvFPw70ZM2ffGOoSsspvQ2CMHeo8sMn7ZZJc00ulRYRWD9";

const SECRETKEY =
  "sk_test_51R1oAz01FgT8omeXPRKRD9hnN2T6V15UqtDJLNN83w43cLqNWWXJGoynDCyACIJ4GDETWsdx38AYb7ycoLzhxaQz00BEOhHGv0";

const stripe = require("stripe")(SECRETKEY);

router.post(
  "/process",
  asyncHandler(async (req, res, next) => {
    try {
      const myPayment = await stripe.paymentIntents.create({
        amount: req.body.amount,
        currency: "mwk",
        metadata: {
          company: "Anoymass",
        },
      });

      return res.status(201).json({
        success: true,
        clientSecret: myPayment.client_secret,
      });
    } catch (error) {
      console.log(error);
      return next(new ErrorHandler(error, 500));
    }
  })
);

router.get(
  "/stripeApiKey",
  asyncHandler(async (req, res, next) => {
    try {
      return res.status(201).json({ stripeApiKey: STRIPEAPIKEY });
    } catch (error) {
      return next(new ErrorHandler(error, 500));
    }
  })
);

module.exports = router;
