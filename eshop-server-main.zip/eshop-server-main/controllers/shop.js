const express = require("express");
const path = require("path");
const { upload } = require("../multer");
const Shop = require("../models/shop");
const ErrorHandler = require("../utils/ErrorHandler");
const fs = require("fs");
const jwt = require("jsonwebtoken");
const sendMail = require("../utils/sendMail");
const asyncHandler = require("../middleware/asyncHandler");
const {
  isShopAuthenticated,
  isAuthenticated,
  isAdmin,
} = require("../middleware/auth");
const sendShopTokenToCookie = require("../utils/shopToken");
const { default: mongoose } = require("mongoose");

const router = express.Router();

router.post(
  "/create-shop",
  upload.fields([
    { name: "logo", maxCount: 1 },
    { name: "tinCertificate", maxCount: 1 },
    { name: "registrationCertificate", maxCount: 1 },
    { name: "nationalID", maxCount: 1 },
  ]),
  asyncHandler(async (req, res, next) => {
    try {
      const { ownerEmail } = req.body;
      const shopExist = await Shop.findOne({ ownerEmail });

      if (shopExist) {
        // Delete uploaded files if shop already exists
        Object.values(req.files).forEach((fileArray) => {
          fileArray.forEach((file) => {
            fs.unlink(`uploads/${file.filename}`, (error) => {
              if (error) console.log(error);
            });
          });
        });
        return next(new ErrorHandler("Shop already exists", 400));
      }

      // Define required files (excluding optional logo)
      const requiredFiles = [
        "logo",
        "tinCertificate",
        "registrationCertificate",
        "nationalID",
      ];

      for (const field of requiredFiles) {
        if (!req.files[field] || req.files[field].length === 0) {
          return next(new ErrorHandler(`Missing file: ${field}`, 400));
        }
      }

      // Extract file names safely
      const shop = {
        ...req.body,
        logo: req.files["logo"][0].filename, // Optional
        tinCertificate: req.files["tinCertificate"][0].filename,
        registrationCertificate:
          req.files["registrationCertificate"][0].filename,
        nationalID: req.files["nationalID"][0].filename,
      };

      // Generate activation token
      const activationToken = generateActivationToken(shop);
      const activationLink = `${process.env.CLIENT_URL}/shop/activation/${activationToken}`;

      // Send activation email
      await sendMail({
        receiver: shop.ownerEmail,
        subject: "Shop Activation Link",
        htmlMessage: `
          <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px; background-color: #f4f4f4; border-radius: 8px; box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);">
            <div style="background-color: #36454F; color: #ffffff; padding: 15px; border-radius: 8px 8px 0 0; text-align: center;">
              <h2>Welcome to Malawi Store!</h2>
            </div>
            <div style="padding: 20px; background-color: #ffffff; border-radius: 0 0 8px 8px;">
              <p style="font-size: 16px; color: #333;">Hello <strong>${
                shop.name
              }</strong>,</p>
              <p style="font-size: 16px; color: #555;">
                We're excited to have you on board! Please activate your shop by clicking the button below:
              </p>
              <div style="text-align: center; margin: 20px 0;">
                <a href="${activationLink}" style="text-decoration: none;">
                  <button style="background-color: #DAA520; color: #ffffff; font-size: 16px; padding: 10px 20px; border: none; border-radius: 4px; cursor: pointer;">
                    Activate your shop
                  </button>
                </a>
              </div>
               <a href="${activationLink}" style="text-decoration: none;">
                  or Click here  
                </a>
              <p style="font-size: 14px; color: #666;">
                If you did not sign up for this shop, please ignore this email. The activation link will expire in 10 minutes.
              </p>
            </div>
            <div style="margin-top: 20px; text-align: center; font-size: 12px; color: #999;">
              <p style="margin: 0;">This is an auto-generated email. Please do not reply.</p>
              <p style="margin: 0;">© ${new Date().getFullYear()} Malawi's Store. All rights reserved.</p>
            </div>
          </div>
        `,
      });

      return res.status(201).json({
        success: true,
        message: `Please check your email inbox or spam folder: ${shop.ownerEmail} to activate your Shop.`,
      });
    } catch (error) {
      console.log(error);
      return next(new ErrorHandler(error.message, 500));
    }
  })
);

// Generate activation token
const generateActivationToken = (shop) => {
  return jwt.sign(shop, process.env.SHOP_ACTIVATION_SECRET, {
    expiresIn: "10m",
  });
};

//activate and insert shop account
router.post(
  "/activation",
  asyncHandler(async (req, res, next) => {
    try {
      const { activationToken } = req.body;

      const newShop = jwt.verify(
        activationToken,
        process.env.SHOP_ACTIVATION_SECRET
      );

      if (!newShop) {
        return next(new ErrorHandler("Invalid Token", 400));
      }

      const { ownerEmail } = newShop;

      let shop = await Shop.findOne({ ownerEmail });

      if (shop) {
        return next(new ErrorHandler("Shop already exist", 400));
      }

      const myShop = await Shop.create(newShop);

      await sendMail({
        receiver: process.env.ADMIN_EMAIL,
        subject: "New Shop Pending Approval on Malawi Store",
        htmlMessage: `
          <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px; background-color: #f0f2f5; border-radius: 8px; box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);">
            <div style="background-color: #36454F; color: #ffffff; padding: 15px; border-radius: 8px 8px 0 0; text-align: center;">
              <h2>Shop Approval Needed</h2>
            </div>
            <div style="padding: 20px; background-color: #ffffff; border-radius: 0 0 8px 8px;">
              <p style="font-size: 16px; color: #333;">Hello Admin,</p>
              <p style="font-size: 16px; color: #555;">
                A new shop has just been registered on <strong>Malawi Store</strong> and is now pending your review and approval.
              </p>
              <p style="font-size: 16px; color: #555;">
                <strong>Shop Name:</strong> ${myShop.name}<br/>
                <strong>Owner:</strong> ${myShop.ownerName}<br/>
                <strong>Email:</strong> ${myShop.ownerEmail}
              </p>
              <p style="font-size: 16px; color: #555;">
                Please log in to the admin dashboard to review the shop details and take the necessary action.
              </p>
              <div style="text-align: center; margin: 20px 0;">
                <a href="${process.env.CLIENT_URL}/seller/${
          myShop?._id
        }" style="text-decoration: none;">
                  <button style="background-color: #DAA520; color: #ffffff; font-size: 16px; padding: 10px 20px; border: none; border-radius: 4px; cursor: pointer;">
                    Review Shop Now
                  </button>
                </a>
              </div>
               <a href="${process.env.CLIENT_URL}/seller/${
          myShop?._id
        }" style="text-decoration: none;">
                Or Click here
                </a>
              <p style="font-size: 14px; color: #888;">Timely approval ensures a smooth seller onboarding experience. Thank you!</p>
            </div>
            <div style="margin-top: 20px; text-align: center; font-size: 12px; color: #999;">
              <p style="margin: 0;">This is an automated notification for administrative purposes.</p>
              <p style="margin: 0;">© ${new Date().getFullYear()} Malawi Store. All rights reserved.</p>
            </div>
          </div>
        `,
      });

      sendShopTokenToCookie(myShop, 201, res);
    } catch (error) {
      return next(new ErrorHandler(error.message, 500));
    }
  })
);

//login the shop
router.post(
  "/login-shop",
  asyncHandler(async (req, res, next) => {
    try {
      const { email, password } = req.body;

      if (!email || !password) {
        return next(new ErrorHandler("Please provide all credentials", 400));
      }

      const shop = await Shop.findOne({ ownerEmail: email }).select(
        "+password"
      );

      if (!shop) {
        return next(new ErrorHandler("Shop not found!", 400));
      }

      if (!shop.isApproved) {
        return next(new ErrorHandler("Shop is not approved yet", 400));
      }

      const isPasswordCorrect = await shop.comparePasswords(password);

      if (!isPasswordCorrect) {
        return next(
          new ErrorHandler(
            "Incorrect password\nPlease try again or reset your password",
            400
          )
        );
      }

      sendShopTokenToCookie(shop, 201, res);
    } catch (error) {
      return next(new ErrorHandler(error.message, 500));
    }
  })
);

//load shop
router.get(
  "/get-shop",
  isShopAuthenticated,
  asyncHandler(async (req, res, next) => {
    try {
      const shop = await Shop.findById(req.shop.id);

      if (!shop) {
        return next(new ErrorHandler("Shop does not exist", 400));
      }

      res.status(200).json({
        success: true,
        shop,
      });
    } catch (error) {
      return next(new ErrorHandler(error.message, 500));
    }
  })
);

//get shop for general  (preview)
router.get(
  "/get-shop-preview/:shopId",
  asyncHandler(async (req, res, next) => {
    try {
      const shopId = req.params.shopId;

      const shop = await Shop.findById(shopId);

      if (!shop) {
        return next(new ErrorHandler("Shop does not exist", 400));
      }

      res.status(200).json({
        success: true,
        shop,
      });
    } catch (error) {
      return next(new ErrorHandler(error.message, 500));
    }
  })
);

//update shop info
router.put(
  "/update-shop-info",
  isShopAuthenticated,
  asyncHandler(async (req, res, next) => {
    try {
      const {
        id,
        name,
        description,
        email,
        phone,
        physicalAddress,
        businessType,
        ownerName,
        ownerEmail,
        ownerPhoneNumber,
        dateOfBirth,
        gender,
        postalCode,
        country,
        city,
        password,
      } = req.body;

      // Validate ObjectId format before converting
      if (!mongoose.isValidObjectId(id)) {
        return next(new ErrorHandler("Invalid shopId format", 400));
      }

      const userObjectId = new mongoose.Types.ObjectId(id);
      const isOwner = userObjectId.equals(req.shop._id);

      if (!isOwner) {
        return next(new ErrorHandler("This is not your workspace", 400));
      }

      const user = await Shop.findById(id).select("+password");

      if (!user) {
        return next(new ErrorHandler("Shop not found", 400));
      }

      const isValidPwd = await user.comparePasswords(password);

      if (!isValidPwd) {
        return next(new ErrorHandler("Invalid password", 400));
      }

      user.name = name;
      user.email = email;
      user.description = description;
      user.phone = phone;
      user.physicalAddress = physicalAddress;
      user.businessType = businessType;
      user.ownerName = ownerName;
      user.ownerEmail = ownerEmail;
      user.ownerPhoneNumber = ownerPhoneNumber;
      user.gender = gender;
      user.dateOfBirth = dateOfBirth;
      user.postalCode = postalCode;
      user.country = country;
      user.city = city;

      await user.save();

      return res.status(201).json({
        success: true,
        shop: user,
      });
    } catch (error) {
      return next(new ErrorHandler(error.message, 500));
    }
  })
);

//update shop logo
router.put(
  "/update-shop-logo",
  isShopAuthenticated,
  upload.single("logo"),
  asyncHandler(async (req, res, next) => {
    try {
      const userExist = await Shop.findById(req.shop._id);

      if (!userExist) {
        return next(new ErrorHandler("Shop not found", 400));
      }

      const isAvatarExistPath = `uploads/${userExist.logo}`;

      fs.unlinkSync(isAvatarExistPath);

      const fileUrl = path.join(req.file.filename);

      const user = await Shop.findByIdAndUpdate(req.shop._id, {
        logo: fileUrl,
      });

      res.status(201).json({
        success: true,
        user,
      });
    } catch (error) {
      return next(new ErrorHandler(error.message, 500));
    }
  })
);

//get user info
router.get(
  "/get-shop-info/:id",
  isAuthenticated,
  asyncHandler(async (req, res, next) => {
    try {
      const shop = await Shop.findById(req.params.id);

      return res.status(201).json({
        success: true,
        shop,
      });
    } catch (error) {
      return next(new ErrorHandler(error, 500));
    }
  })
);

//get shops --- admin
router.get(
  "/get-all-shops",
  isAdmin,
  asyncHandler(async (req, res, next) => {
    try {
      const shops = await Shop.find().sort({
        createdAt: -1,
      });

      return res.status(201).json({
        success: true,
        shops,
      });
    } catch (error) {
      return next(new ErrorHandler(error, 500));
    }
  })
);

//approve shop --- admin
router.put(
  "/approve",
  isAdmin,
  asyncHandler(async (req, res, next) => {
    try {
      const { isApproved, comment, shopId, tag } = req.body;

      const shopObjectId = new mongoose.Types.ObjectId(shopId);

      const shop = await Shop.findById(shopObjectId);

      if (!shop) {
        return next(new ErrorHandler("Shop does not exist", 400));
      }

      shop.isApproved = isApproved;
      shop.comment = comment;

      await shop.save();

      if (isApproved) {
        await sendMail({
          receiver: shop.ownerEmail,
          subject: "Your Shop Has Been Approved – Start Selling Today!",
          htmlMessage: `
            <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px; background-color: #f4f4f4; border-radius: 8px; box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);">
              <div style="background-color: #36454F; color: #ffffff; padding: 15px; border-radius: 8px 8px 0 0; text-align: center;">
                <h2>Congratulations, Your Shop is Now Live!</h2>
              </div>
              <div style="padding: 20px; background-color: #ffffff; border-radius: 0 0 8px 8px;">
                <p style="font-size: 16px; color: #333;">Hello <strong>${
                  shop.name
                }</strong>,</p>
                <p style="font-size: 16px; color: #555;">
                  We're excited to let you know that your shop has been successfully approved on <strong>Malawi Store</strong>!
                </p>
                <p style="font-size: 16px; color: #555;">
                  You can now start listing and selling your products to customers across Malawi. We’re thrilled to have you as part of our growing marketplace.
                </p>
                <div style="text-align: center; margin: 20px 0;">
                <a href="${
                  process.env.CLIENT_URL
                }/login-shop" style="text-decoration: none;">
                  <button style="background-color: #DAA520; color: #ffffff; font-size: 16px; padding: 10px 20px; border: none; border-radius: 4px; cursor: pointer;">
                    Shop Login
                  </button>
                </a>
              </div>
               <a href="${
                  process.env.CLIENT_URL
                }/login-shop" style="text-decoration: none;">
                 Or click here
                </a>
                <p style="font-size: 16px; color: #555;">
                  If you need any help getting started or have questions, feel free to reach out to our support team.
                </p>
              </div>

              <div style="margin-top: 20px; text-align: center; font-size: 12px; color: #999;">
                <p style="margin: 0;">This is an automated email. Please do not reply.</p>
                <p style="margin: 0;">© ${new Date().getFullYear()} Malawi Store. All rights reserved.</p>
              </div>
            </div>
          `,
        });
      } else {
        await sendMail({
          receiver: shop.ownerEmail,
          subject: "Important Update About Your Shop on Malawi Store",
          htmlMessage: `
            <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px; background-color: #f8f8f8; border-radius: 8px; box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);">
              <div style="background-color: #B22222; color: #ffffff; padding: 15px; border-radius: 8px 8px 0 0; text-align: center;">
                <h2>Shop Status Notification</h2>
              </div>
              <div style="padding: 20px; background-color: #ffffff; border-radius: 0 0 8px 8px;">
                <p style="font-size: 16px; color: #333;">Dear <strong>${
                  shop.name
                }</strong>,</p>
                <p style="font-size: 16px; color: #555;">
                  We would like to inform you that your shop on <strong>Malawi Store</strong> has been <strong>rejected</strong> or <strong>deactivated</strong>.
                </p>
                <p style="font-size: 16px; color: #555;">
                  This may be due to "${comment}".
                </p>
                <p style="font-size: 16px; color: #555;">
                  If you believe this was an error or if you would like more details regarding this decision, please feel free to contact our support team for further clarification.
                </p>
                <p style="font-size: 16px; color: #555;">
                  Thank you for your interest in partnering with us.
                </p>
              </div>
              <div style="margin-top: 20px; text-align: center; font-size: 12px; color: #999;">
                <p style="margin: 0;">This is an automated message. Please do not reply directly.</p>
                <p style="margin: 0;">© ${new Date().getFullYear()} Malawi Store. All rights reserved.</p>
              </div>
            </div>
          `,
        });
      }

      return res.status(201).json({
        success: true,
        shop,
      });
    } catch (error) {
      next(new ErrorHandler(error, 500));
    }
  })
);

//delete shop --- admin
router.delete(
  "/:id",
  isAdmin,
  asyncHandler(async (req, res, next) => {
    try {
      const shopId = req.params.id;

      if (!shopId) {
        return next(new ErrorHandler("Shop Id is missing!", 400));
      }

      const shop = await Shop.findByIdAndDelete(shopId);

      return res.status(201).json({
        status: true,
        shop,
      });
    } catch (error) {
      next(new ErrorHandler(error, 500));
    }
  })
);

// reset password -- initial
router.post(
  "/reset-password",
  asyncHandler(async (req, res, next) => {
    try {
      const { email } = req.body;

      const shop = await Shop.findOne({ ownerEmail: email });

      if (!shop) {
        return next(new ErrorHandler("Shop not found!", 400));
      }

      const generatedInteger = generateRandomFourDigit();

      const token = jwt.sign({ token: generatedInteger, shop }, "XCCDKDKDOEO", {
        expiresIn: "10m",
      });

      const resetLink = `${process.env.CLIENT_URL}/shop/password/reset/${token}`;

      try {
        await sendMail({
          receiver: shop.email,
          subject: "Password Reset Link",
          htmlMessage: `
            <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px; background-color: #f4f4f4; border-radius: 8px; box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);">
              <div style="background-color: #36454F; color: #ffffff; padding: 15px; border-radius: 8px 8px 0 0; text-align: center;">
                <h2>Password Reset Request</h2>
              </div>
              <div style="padding: 20px; background-color: #ffffff; border-radius: 0 0 8px 8px;">
                <p style="font-size: 16px; color: #333;">Hello <strong>${
                  shop.name
                }</strong>,</p>
                <p style="font-size: 16px; color: #555;">
                  We received a request to reset your password. Click the button below to proceed:
                </p>
                <div style="text-align: center; margin: 20px 0;">
                  <a href="${resetLink}" style="text-decoration: none;">
                    <button style="background-color: #DAA520; color: #ffffff; font-size: 16px; padding: 10px 20px; border: none; border-radius: 4px; cursor: pointer;">
                      Reset Password
                    </button>
                  </a>
                </div>
                 <div style="text-align: center; margin: 20px 0;">
                  <a href="${resetLink}" style="text-decoration: none;">
                   Or Click here
                  </a>
                </div>
                <p style="font-size: 14px; color: #666;">
                  If you didn't request a password reset, you can safely ignore this email. The reset link will expire in 10 minutes.
                </p>
              </div>
              <div style="margin-top: 20px; text-align: center; font-size: 12px; color: #999;">
                <p style="margin: 0;">This is an auto-generated email. Please do not reply.</p>
                <p style="margin: 0;">© ${new Date().getFullYear()} Malawi's Store. All rights reserved.</p>
              </div>
            </div>
          `,
        });

        return res.status(201).json({
          success: true,
          message: `Password reset email sent to: ${shop.ownerEmail}. Please check your inbox or spam folder.`,
        });
      } catch (error) {
        return next(new ErrorHandler(error.message, 500));
      }
    } catch (error) {
      next(new ErrorHandler(error, 500));
    }
  })
);

// validate token
router.get(
  "/validateToken/:token",
  asyncHandler(async (req, res, next) => {
    try {
      const { token } = req.params; // Get the token from URL

      // Verify the token
      let decoded;
      try {
        decoded = jwt.verify(token, "XCCDKDKDOEO");
        return res.status(201).json({
          success: true,
          decoded,
        });
      } catch (err) {
        return next(
          new ErrorHandler("Reset link is invalid or has expired.", 400)
        );
      }
    } catch (error) {
      next(new ErrorHandler(error.message, 500));
    }
  })
);

// Reset password after clicking the reset link
router.post(
  "/reset/password/:token",
  asyncHandler(async (req, res, next) => {
    try {
      const { token } = req.params;
      const { newPassword } = req.body;

      if (!newPassword) {
        return next(new ErrorHandler("Please provide a new password.", 400));
      }

      // Verify token
      const decoded = jwt.verify(token, "XCCDKDKDOEO");

      if (!decoded || !decoded.shop || !decoded.shop.email) {
        return next(new ErrorHandler("Invalid or expired reset token.", 400));
      }

      const shop = await Shop.findOne({ ownerEmail: decoded.shop.ownerEmail });

      if (!shop) {
        return next(new ErrorHandler("Shop not found.", 404));
      }

      // Update shop's password
      shop.password = newPassword;
      await shop.save();

      // Send success email
      await sendMail({
        receiver: shop.ownerEmail,
        subject: "Password Reset Successful",
        htmlMessage: `
          <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px;">
            <h2 style="color: #4CAF50;">Password Reset Successful!</h2>
            <p>Hello <strong>${shop.name}</strong>,</p>
            <p>Your password has been successfully updated. If this wasn't you, please contact support immediately.</p>
            <p>Thank you,<br/>Malawi's Malawi Store Team</p>
          </div>
        `,
      });

      res.status(200).json({
        success: true,
        message:
          "Password reset successful. You can now login with your new password.",
      });
    } catch (error) {
      console.error("Password reset error:", error);
      return next(
        new ErrorHandler(
          "Reset token invalid or expired. Please try again.",
          400
        )
      );
    }
  })
);

function generateRandomFourDigit() {
  return Math.floor(1000 + Math.random() * 9000);
}

// log out shop
router.get(
  "/logout",
  asyncHandler(async (req, res, next) => {
    try {
      res.cookie("shopToken", null, {
        expires: new Date(Date.now()),
        httpOnly: true,
        sameSite: "None",
        secure: true,
      });
      res.status(201).json({
        success: true,
        message: "Log out successful!",
      });
    } catch (error) {
      return next(new ErrorHandler(error.message, 500));
    }
  })
);

module.exports = router;
