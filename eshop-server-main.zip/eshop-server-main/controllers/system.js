const express = require("express");
const path = require("path");
const { upload } = require("../multer");
const System = require("../models/system");
const ErrorHandler = require("../utils/ErrorHandler");
const fs = require("fs");
const jwt = require("jsonwebtoken");
const sendMail = require("../utils/sendMail");
const asyncHandler = require("../middleware/asyncHandler");
const { isAdmin } = require("../middleware/auth");
const { mongoose } = require("mongoose");
const sendAdminTokenToCookie = require("../utils/systemToken");

const router = express.Router();

router.post("/create-user", upload.single("file"), async (req, res, next) => {
  try {
    const { name, email, password, role } = req.body;
    const systemExist = await System.findOne({ email });

    if (systemExist) {
      const filename = req.file.filename;
      const filePath = `uploads/${filename}`;

      fs.unlink(filePath, (error) => {
        if (error) {
          console.log(err);
          res.status(500).json({ message: "Failed to delete the file" });
        }
      });

      return next(new ErrorHandler("User already exist", 400));
    }

    if (!req.file) {
      return next(new ErrorHandler("File is required", 500));
    }

    const filename = req.file.filename;
    const fileUrl = path.join(filename);

    const user = {
      name,
      email,
      password,
      role,
      avatar: fileUrl,
    };

    const activationToken = generateActivationToken(user);

    const activationLink = `${process.env.CLIENT_URL}/activation/admin/${activationToken}`;

    try {
      await sendMail({
        receiver: user.email,
        subject: "Account Activation Link",
        htmlMessage: `
          <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px; background-color: #f4f4f4; border-radius: 8px; box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);">
            <div style="background-color: #36454F; color: #ffffff; padding: 15px; border-radius: 8px 8px 0 0; text-align: center;">
              <h2>Welcome to Malawi Store!</h2>
            </div>
            <div style="padding: 20px; background-color: #ffffff; border-radius: 0 0 8px 8px;">
              <p style="font-size: 16px; color: #333;">Hello <strong>${
                user.name
              }</strong>,</p>
              <p style="font-size: 16px; color: #555;">
                We're excited to have you on board! Please activate your account by clicking the button below:
              </p>
              <div style="text-align: center; margin: 20px 0;">
                <a href="${activationLink}" style="text-decoration: none;">
                  <button style="background-color: #DAA520; color: #ffffff; font-size: 16px; padding: 10px 20px; border: none; border-radius: 4px; cursor: pointer;">
                    Activate Account
                  </button>
                </a>
              </div>
                <div style="text-align: center; margin: 20px 0;">
                <a href="${activationLink}" style="text-decoration: none;">
                 Or click here
                </a>
              </div>
              <p style="font-size: 14px; color: #666;">
                If you did not sign up for this account, please ignore this email. The activation link will expire in 10 minutes.
              </p>
            </div>
            <div style="margin-top: 20px; text-align: center; font-size: 12px; color: #999;">
              <p style="margin: 0;">This is an auto-generated email. Please do not reply.</p>
              <p style="margin: 0;">© ${new Date().getFullYear()} Malawi's Store. All rights reserved.</p>
            </div>
          </div>
        `,
      });

      return res.status(201).json({
        success: true,
        message: `Please check your email inbox or spam folder: ${user.email} to activate your account.`,
      });
    } catch (error) {
      return next(new ErrorHandler(error.message, 500));
    }

    // return res.status(201).json({
    //   success: true,
    //   newSystem,
    // });
  } catch (error) {
    console.log(error);
    return next(new ErrorHandler(error.message, 500));
  }
});

// Generate activation token
const generateActivationToken = (system) => {
  return jwt.sign(system, process.env.EMAIL_ACTIVATION_SECRET, {
    expiresIn: "10m",
  });
};

//activate and insert system account
router.post(
  "/activation",
  asyncHandler(async (req, res, next) => {
    try {
      const { activationToken } = req.body;

      const newUser = jwt.verify(
        activationToken,
        process.env.EMAIL_ACTIVATION_SECRET
      );

      if (!newUser) {
        return next(new ErrorHandler("Invalid Token", 400));
      }

      const { name, email, password, avatar, role } = newUser;

      let user = await System.findOne({ email });

      if (user) {
        return next(new ErrorHandler("User already exist", 400));
      }

      const createdUser = await System.create({
        name,
        email,
        password,
        avatar,
        role,
      });

      sendAdminTokenToCookie(createdUser, 201, res);
    } catch (error) {
      return next(new ErrorHandler(error.message, 500));
    }
  })
);

//login the system
router.post(
  "/login-user",
  asyncHandler(async (req, res, next) => {
    try {
      const { email, password } = req.body;

      if (!email || !password) {
        return next(new ErrorHandler("Please provide all credentials", 400));
      }

      const user = await System.findOne({ email }).select("+password");

      if (!user) {
        return next(new ErrorHandler("User not found!", 400));
      }

      const isPasswordCorrect = await user.comparePasswords(password);

      if (!isPasswordCorrect) {
        return next(
          new ErrorHandler(
            "Incorrect password\nPlease try again or reset your password",
            400
          )
        );
      }

      sendAdminTokenToCookie(user, 201, res);
    } catch (error) {
      return next(new ErrorHandler(error.message, 500));
    }
  })
);

//load user
router.get(
  "/get-user",
  isAdmin,
  asyncHandler(async (req, res, next) => {
    try {
      const user = await System.findById(req.admin._id);

      if (!user) {
        return next(new ErrorHandler("User does not exist", 400));
      }

      res.status(200).json({
        success: true,
        user,
      });
    } catch (error) {
      return next(new ErrorHandler(error.message, 500));
    }
  })
);

//getAdmins
router.get(
  "/admins/madison",
  asyncHandler(async (req, res, next) => {
    try {
      const users = await System.find();

      res.status(200).json({
        success: true,
        total: users.length,
      });
    } catch (error) {
      return next(new ErrorHandler(error.message, 500));
    }
  })
);

//update user info
router.put(
  "/update-user-info",
  isAdmin,
  asyncHandler(async (req, res, next) => {
    try {
      const { email, password, phoneNumber, name, id } = req.body;

      // Validate ObjectId format before converting
      if (!mongoose.isValidObjectId(id)) {
        return next(new ErrorHandler("Invalid systemId format", 400));
      }

      const userObjectId = new mongoose.Types.ObjectId(id);
      const isOwner = userObjectId.equals(req.admin._id);

      if (!isOwner) {
        return next(new ErrorHandler("This is not your workspace", 400));
      }

      const user = await System.findById(id).select("+password");

      if (!user) {
        return next(new ErrorHandler("User not found", 400));
      }

      const isValidPwd = await user.comparePasswords(password);

      if (!isValidPwd) {
        return next(new ErrorHandler("Invalid password", 400));
      }

      user.name = name;
      user.phoneNumber = phoneNumber;
      user.email = email;

      await user.save();

      return res.status(201).json({
        success: true,
        user,
      });
    } catch (error) {
      return next(new ErrorHandler(error.message, 500));
    }
  })
);

//update profile avatar
router.put(
  "/update-avatar",
  isAdmin,
  upload.single("image"),
  asyncHandler(async (req, res, next) => {
    try {
      const userExist = await System.findById(req.admin._id);

      if (!userExist) {
        return next(new ErrorHandler("User not found", 400));
      }

      const isAvatarExistPath = `uploads/${userExist.avatar}`;

      fs.unlinkSync(isAvatarExistPath);

      const fileUrl = path.join(req.file.filename);

      const user = await System.findByIdAndUpdate(req.admin._id, {
        avatar: fileUrl,
      });

      res.status(201).json({
        success: true,
        user,
      });
    } catch (error) {
      return next(new ErrorHandler(error.message, 500));
    }
  })
);

//update password
router.put(
  "/update-system-password",
  isAdmin,
  asyncHandler(async (req, res, next) => {
    try {
      const user = await System.findById(req.admin._id).select("+password");
      const { oldPassword, newPassword, confirmPassword } = req.body;

      if (!user) {
        return next(new ErrorHandler("User not found", 400));
      }

      const isCorrectPassword = await user.comparePasswords(oldPassword);

      if (!isCorrectPassword) {
        return next(
          new ErrorHandler(
            "Invalid old password. Please enter the correct password",
            400
          )
        );
      }

      if (newPassword !== confirmPassword) {
        return next(
          new ErrorHandler(
            "New password and confirm password do not match",
            400
          )
        );
      }

      user.password = newPassword;

      await user.save();

      return res
        .status(201)
        .json({ success: true, message: "Password updated successfully" });
    } catch (error) {
      return next(new ErrorHandler(error.message, 500));
    }
  })
);

//get user info
router.get(
  "/get-user-info/:id",
  isAdmin,
  asyncHandler(async (req, res, next) => {
    try {
      const user = await System.findById(req.params.id);

      return res.status(201).json({
        success: true,
        user,
      });
    } catch (error) {
      return next(new ErrorHandler(error, 500));
    }
  })
);

//update shop info
router.put(
  "/update-system-info",
  isAdmin,
  asyncHandler(async (req, res, next) => {
    try {
      const { id, name, role, password } = req.body;

      // Validate ObjectId format before converting
      if (!mongoose.isValidObjectId(id)) {
        return next(new ErrorHandler("Invalid shopId format", 400));
      }

      const userObjectId = new mongoose.Types.ObjectId(id);
      const isOwner = userObjectId.equals(req.admin._id);

      if (!isOwner) {
        return next(new ErrorHandler("This is not your workspace", 400));
      }

      const user = await System.findById(id).select("+password");

      if (!user) {
        return next(new ErrorHandler("User not found", 400));
      }

      const isValidPwd = await user.comparePasswords(password);

      if (!isValidPwd) {
        return next(new ErrorHandler("Invalid password", 400));
      }

      user.name = name;
      user.role = role;

      await user.save();

      return res.status(201).json({
        success: true,
        shop: user,
      });
    } catch (error) {
      return next(new ErrorHandler(error.message, 500));
    }
  })
);

//update shop logo
router.put(
  "/update-system-avatar",
  isAdmin,
  upload.single("avatar"),
  asyncHandler(async (req, res, next) => {
    try {
      const userExist = await System.findById(req.admin._id);

      if (!userExist) {
        return next(new ErrorHandler("User not found", 400));
      }

      const isAvatarExistPath = `uploads/${userExist.avatar}`;

      fs.unlinkSync(isAvatarExistPath);

      const fileUrl = path.join(req.file.filename);

      const user = await System.findByIdAndUpdate(req.admin._id, {
        avatar: fileUrl,
      });

      res.status(201).json({
        success: true,
        user,
      });
    } catch (error) {
      return next(new ErrorHandler(error.message, 500));
    }
  })
);

// reset password -- initial
router.post(
  "/reset-password",
  asyncHandler(async (req, res, next) => {
    try {
      const { email } = req.body;

      const user = await System.findOne({ email });

      if (!user) {
        return next(new ErrorHandler("User not found!", 400));
      }

      const generatedInteger = generateRandomFourDigit();

      const token = jwt.sign({ token: generatedInteger, user }, "XCCDKDKDOEO", {
        expiresIn: "10m",
      });

      const resetLink = `${process.env.CLIENT_URL}/admin/password/reset/${token}`;

      try {
        await sendMail({
          receiver: user.email,
          subject: "Password Reset Link",
          htmlMessage: `
            <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px; background-color: #f4f4f4; border-radius: 8px; box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);">
              <div style="background-color: #36454F; color: #ffffff; padding: 15px; border-radius: 8px 8px 0 0; text-align: center;">
                <h2>Password Reset Request</h2>
              </div>
              <div style="padding: 20px; background-color: #ffffff; border-radius: 0 0 8px 8px;">
                <p style="font-size: 16px; color: #333;">Hello <strong>${
                  user.name
                }</strong>,</p>
                <p style="font-size: 16px; color: #555;">
                  We received a request to reset your password. Click the button below to proceed:
                </p>
                <div style="text-align: center; margin: 20px 0;">
                  <a href="${resetLink}" style="text-decoration: none;">
                    <button style="background-color: #DAA520; color: #ffffff; font-size: 16px; padding: 10px 20px; border: none; border-radius: 4px; cursor: pointer;">
                      Reset Password
                    </button>
                  </a>
                </div>
                 <div style="text-align: center; margin: 20px 0;">
                  <a href="${resetLink}" style="text-decoration: none;">
                   Or Click here
                  </a>
                </div>
                <p style="font-size: 14px; color: #666;">
                  If you didn't request a password reset, you can safely ignore this email. The reset link will expire in 10 minutes.
                </p>
              </div>
              <div style="margin-top: 20px; text-align: center; font-size: 12px; color: #999;">
                <p style="margin: 0;">This is an auto-generated email. Please do not reply.</p>
                <p style="margin: 0;">© ${new Date().getFullYear()} Malawi's Malawi Store. All rights reserved.</p>
              </div>
            </div>
          `,
        });

        return res.status(201).json({
          success: true,
          message: `Password reset email sent to: ${user.email}. Please check your inbox or spam folder.`,
        });
      } catch (error) {
        return next(new ErrorHandler(error.message, 500));
      }
    } catch (error) {
      next(new ErrorHandler(error, 500));
    }
  })
);

// validate token
router.get(
  "/validateToken/:token",
  asyncHandler(async (req, res, next) => {
    try {
      const { token } = req.params; // Get the token from URL

      // Verify the token
      let decoded;
      try {
        decoded = jwt.verify(token, "XCCDKDKDOEO");
        return res.status(201).json({
          success: true,
          decoded,
        });
      } catch (err) {
        return next(
          new ErrorHandler("Reset link is invalid or has expired.", 400)
        );
      }
    } catch (error) {
      next(new ErrorHandler(error.message, 500));
    }
  })
);

// Reset password after clicking the reset link
router.post(
  "/reset/password/:token",
  asyncHandler(async (req, res, next) => {
    try {
      const { token } = req.params;
      const { newPassword } = req.body;

      if (!newPassword) {
        return next(new ErrorHandler("Please provide a new password.", 400));
      }

      // Verify token
      const decoded = jwt.verify(token, "XCCDKDKDOEO");

      console.log(decoded);

      if (!decoded || !decoded.user || !decoded.user.email) {
        return next(new ErrorHandler("Invalid or expired reset token.", 400));
      }

      const user = await System.findOne({ email: decoded.user.email });

      if (!user) {
        return next(new ErrorHandler("User not found.", 404));
      }

      // Update user's password
      user.password = newPassword;
      await user.save();

      // Send success email
      await sendMail({
        receiver: user.email,
        subject: "Password Reset Successful",
        htmlMessage: `
          <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px;">
            <h2 style="color: #4CAF50;">Password Reset Successful!</h2>
            <p>Hello <strong>${user.name}</strong>,</p>
            <p>Your password has been successfully updated. If this wasn't you, please contact support immediately.</p>
            <p>Thank you,<br/>Malawi's Malawi Store Team</p>
          </div>
        `,
      });

      res.status(200).json({
        success: true,
        message:
          "Password reset successful. You can now login with your new password.",
      });
    } catch (error) {
      console.error("Password reset error:", error);
      return next(
        new ErrorHandler(
          "Reset token invalid or expired. Please try again.",
          400
        )
      );
    }
  })
);

function generateRandomFourDigit() {
  return Math.floor(1000 + Math.random() * 9000);
}

// log out system
router.get(
  "/logout",
  asyncHandler(async (req, res, next) => {
    try {
      res.cookie("adminToken", null, {
        expires: new Date(Date.now()),
        httpOnly: true,
        sameSite: "none",
        secure: true,
      });
      res.status(201).json({
        success: true,
        message: "Log out successful!",
      });
    } catch (error) {
      return next(new ErrorHandler(error.message, 500));
    }
  })
);

module.exports = router;
