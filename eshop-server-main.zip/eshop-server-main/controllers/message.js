const express = require("express");
const router = express.Router();
const Message = require("../models/message");
const asyncHandler = require("../middleware/asyncHandler");
const ErrorHandler = require("../utils/ErrorHandler");

router.post(
  "/create-message",
  asyncHandler(async (req, res, next) => {
    try {
      const messageData = req.body;

      if (req.files) {
        const files = req.files;

        const imagUrls = files.map((file) => `${file.fileName}`);

        messageData.images;
      }

      messageData.conversationId = req.body.conversationId;
      messageData.sender = req.body.sender;
      messageData.text = req.body.text;

      const message = new Message({
        conversationId: messageData.conversationId,
        text: messageData.text,
        sender: messageData.sender,
        images: messageData.images ? messageData.images : undefined,
      });

      await message.save();



      return res.status(201).json({
        success: true,
        message,
      });
    } catch (error) {
      return next(new ErrorHandler(error.response.message, 500));
    }
  })
);

//get all messages
router.get("/get-all-messages/:id", asyncHandler(async(req, res, next) => {
  try {
    const messages = await Message.find({
      conversationId: req.params.id
    })

    return res.status(201).json({
      success: true,
      messages
    })
  } catch (error) {
    return next(new ErrorHandler(error, 500))
  }
}))

module.exports = router;
