const express = require("express");
const router = express.Router();
const Order = require("./../models/order");
const Product = require("./../models/product");
const Event = require("./../models/event");
const {
  isAuthenticated,
  isShopAuthenticated,
  isAdmin,
} = require("../middleware/auth");
const asyncHandler = require("../middleware/asyncHandler");
const ErrorHandler = require("../utils/ErrorHandler");
const sendMail = require("../utils/sendMail");

//create order
router.post(
  "/create-order",
  isAuthenticated,
  asyncHandler(async (req, res, next) => {
    try {
      const { cart, shippingAddress, user, totalPrice, paymentInfo } = req.body;

      //group cart items by shopId
      const shopItemsMap = new Map();

      for (const item of cart) {
        const shopId = item.shop._id;

        if (!shopItemsMap.has(shopId)) {
          shopItemsMap.set(shopId, []);
        }

        shopItemsMap.get(shopId).push(item);
      }

      //create an order for each shop
      const orders = [];

      // console.log(shopItemsMap)

      for (const [shopId, items] of shopItemsMap) {
        const order = await Order.create({
          cart: items,
          shippingAddress,
          user,
          totalPrice,
          paymentInfo,
        });

        const shop = order?.cart[0]?.shop;
        orders.push(order);

        await sendMail({
          receiver: shop?.ownerEmail,
          subject: "You Have a New Order!",
          htmlMessage: `
              <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px; background-color: #f9f9f9; border-radius: 8px; box-shadow: 0 2px 6px rgba(0, 0, 0, 0.1);">
                <div style="background-color: #36454F; color: #ffffff; padding: 15px; border-radius: 8px 8px 0 0; text-align: center;">
                  <h2>New Order Notification - Malawi Store</h2>
                </div>
                <div style="padding: 20px; background-color: #ffffff; border-radius: 0 0 8px 8px;">
                  <p style="font-size: 16px; color: #333;">Hello <strong>${
                    shop?.name
                  }</strong>,</p>
                  <p style="font-size: 16px; color: #555;">You have received a new order. Below are the details:</p>
                  
                  <h4 style="color: #36454F;">Order Summary:</h4>
                  <ul style="font-size: 15px; color: #444; padding-left: 20px;">
                    <li><strong>Customer:</strong> ${order?.user?.name}</li>
                    <li><strong>Total Price:</strong> ${order?.totalPrice}</li>
                    <li><strong>Payment Method:</strong> ${
                      order?.paymentInfo?.type
                    }</li>
                    <li><strong>Status:</strong> ${order?.status}</li>
                  </ul>
          
                  <h4 style="color: #36454F;">Shipping Details:</h4>
                  <ul style="font-size: 15px; color: #444; padding-left: 20px;">
                    <li><strong>Name:</strong> ${
                      order?.shippingAddress?.name
                    }</li>
                    <li><strong>Email:</strong> ${
                      order?.shippingAddress?.email
                    }</li>
                    <li><strong>Phone:</strong> ${
                      order?.shippingAddress?.phoneNumber
                    }</li>
                    <li><strong>Address:</strong> ${
                      order?.shippingAddress?.address1
                    }, ${order?.shippingAddress?.city}</li>
                  </ul>
          
                  <div style="text-align: center; margin: 20px 0;">
                    <a href=${
                      process.env.CLIENT_URL + "/order/" + order?._id
                    } style="text-decoration: none;">
                      <button style="background-color: #DAA520; color: #ffffff; font-size: 16px; padding: 10px 20px; border: none; border-radius: 4px; cursor: pointer;">
                        View Order
                      </button>
                    </a>
                  </div>

                   <div style="text-align: center; margin: 20px 0;">
                    <a href=${
                      process.env.CLIENT_URL + "/order/" + order?._id
                    } style="text-decoration: none;">
                      Or click here
                    </a>
                  </div>
          
                  <p style="font-size: 14px; color: #999;">Please prepare this order and contact the customer if needed.</p>
                </div>
                <div style="margin-top: 20px; text-align: center; font-size: 12px; color: #aaa;">
                  <p style="margin: 0;">This is an automated message. Please do not reply directly to this email.</p>
                  <p style="margin: 0;">© ${new Date().getFullYear()} Malawi Store. All rights reserved.</p>
                </div>
              </div>
            `,
        });

        await sendMail({
          receiver: order?.user?.email,
          subject: "Your Order is successful!",
          htmlMessage: `
              <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px; background-color: #f9f9f9; border-radius: 8px; box-shadow: 0 2px 6px rgba(0, 0, 0, 0.1);">
                <div style="background-color: #36454F; color: #ffffff; padding: 15px; border-radius: 8px 8px 0 0; text-align: center;">
                  <h2>New Order Notification - Malawi Store</h2>
                </div>
                <div style="padding: 20px; background-color: #ffffff; border-radius: 0 0 8px 8px;">
                  <p style="font-size: 16px; color: #333;">Hello <strong>${
                    order?.user?.name
                  }</strong>,</p>
                  <p style="font-size: 16px; color: #555;">You have received a new order. Below are the details:</p>
                  
                  <h4 style="color: #36454F;">Order Summary:</h4>
                  <ul style="font-size: 15px; color: #444; padding-left: 20px;">
                    <li><strong>Customer:</strong> ${order?.user?.name}</li>
                    <li><strong>Total Price:</strong> ${order?.totalPrice}</li>
                    <li><strong>Payment Method:</strong> ${
                      order?.paymentInfo?.type
                    }</li>
                    <li><strong>Status:</strong> ${order?.status}</li>
                  </ul>
          
                  <h4 style="color: #36454F;">Shipping Details:</h4>
                  <ul style="font-size: 15px; color: #444; padding-left: 20px;">
                    <li><strong>Name:</strong> ${
                      order?.shippingAddress?.name
                    }</li>
                    <li><strong>Email:</strong> ${
                      order?.shippingAddress?.email
                    }</li>
                    <li><strong>Phone:</strong> ${
                      order?.shippingAddress?.phoneNumber
                    }</li>
                    <li><strong>Address:</strong> ${
                      order?.shippingAddress?.address1
                    }, ${order?.shippingAddress?.city}</li>
                  </ul>
          
                  <div style="text-align: center; margin: 20px 0;">
                    <a href=${
                      process.env.CLIENT_URL + "/user/order/" + order?._id
                    } style="text-decoration: none;">
                      <button style="background-color: #DAA520; color: #ffffff; font-size: 16px; padding: 10px 20px; border: none; border-radius: 4px; cursor: pointer;">
                        View Order
                      </button>
                    </a>
                  </div>

                   <div style="text-align: center; margin: 20px 0;">
                    <a href=${
                      process.env.CLIENT_URL + "/user/order/" + order?._id
                    } style="text-decoration: none;">
                    Or click here
                    </a>
                  </div>
          
                  <p style="font-size: 14px; color: #999;">Please prepare this order and contact the customer if needed.</p>
                </div>
                <div style="margin-top: 20px; text-align: center; font-size: 12px; color: #aaa;">
                  <p style="margin: 0;">This is an automated message. Please do not reply directly to this email.</p>
                  <p style="margin: 0;">© ${new Date().getFullYear()} Malawi Store. All rights reserved.</p>
                </div>
              </div>
            `,
        });
      }

      return res.status(201).json({
        success: true,
        orders,
      });
    } catch (error) {
      console.log(error);
      return next(new ErrorHandler(error, 500));
    }
  })
);

//get all orders of user
router.get(
  "/get-all-orders/:userId",
  isAuthenticated,
  asyncHandler(async (req, res, next) => {
    try {
      const orders = await Order.find({ "user._id": req.params.userId }).sort({
        createdAt: -1,
      });

      return res.status(201).json({
        success: true,
        orders,
      });
    } catch (error) {
      return next(new ErrorHandler(error, 500));
    }
  })
);

//get all orders of shop
router.get(
  "/get-all-shop-orders/:shopId",
  isShopAuthenticated,
  asyncHandler(async (req, res, next) => {
    try {
      const orders = await Order.find({
        "cart.shop._id": req.params.shopId,
      }).sort({
        createdAt: -1,
      });

      return res.status(201).json({
        success: true,
        orders,
      });
    } catch (error) {
      return next(new ErrorHandler(error, 500));
    }
  })
);

//get all orders --- admin
router.get(
  "/get-all-orders",
  isAdmin,
  asyncHandler(async (req, res, next) => {
    try {
      const orders = await Order.find().sort({
        createdAt: -1,
      });

      return res.status(201).json({
        success: true,
        orders,
      });
    } catch (error) {
      return next(new ErrorHandler(error, 500));
    }
  })
);

//update order status
router.put(
  "/update-order-status/:orderId",
  isShopAuthenticated,
  asyncHandler(async (req, res, next) => {
    try {
      if (!req.body.status || req.body.status.length === 0) {
        return next(
          new ErrorHandler("Status is not supposed to be empty", 400)
        );
      }

      const order = await Order.findById(req.params.orderId);

      if (!order) {
        return next(new ErrorHandler("Order not found with this Id", 400));
      }

      if (req.body.status === "Transferred to delivery partner") {
        order.cart.forEach(async (myOrder) => {
          await updateProduct(myOrder._id, myOrder.quantity);
        });
      }

      order.status = req.body.status;

      if (req.body.status === "Delivered") {
        order.deliveredAt = Date.now();
        order.paymentInfo.status = "Succeeded";
      }

      order.save({ validateBeforeSave: false });

      const customer = order?.user;

      if (req.body.status === "Transferred to delivery partner") {
        await sendMail({
          receiver: process.env.ADMIN_EMAIL,
          subject: "Order Items Ready for Delivery",
          htmlMessage: `
            <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px; background-color: #f4f4f4; border-radius: 8px; box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);">
              <div style="background-color: #36454F; color: #ffffff; padding: 15px; border-radius: 8px 8px 0 0; text-align: center;">
                <h2>Items Transferred for Delivery</h2>
              </div>
              <div style="padding: 20px; background-color: #ffffff; border-radius: 0 0 8px 8px;">
                <p style="font-size: 16px; color: #333;">Dear Admin,</p>
                <p style="font-size: 16px; color: #555;">
                  This is to inform you that the items for order <strong>#${
                    order._id
                  }</strong> have been successfully transferred to the dispatch team and are ready for delivery.
                </p>
                <p style="font-size: 16px; color: #555;">
                  Please proceed with the necessary logistics arrangements to ensure a timely and smooth delivery process.
                </p>
                <p style="font-size: 16px; color: #555;">
                  <strong>Customer:</strong> ${customer?.name}<br />
                  <strong>Delivery Address:</strong> ${JSON.stringify(
                    order.shippingAddress
                  )}<br />
                  <strong>Items Count:</strong> ${order.cart.length}
                </p>
                <div style="text-align: center; margin: 20px 0;">
                  <a href="${process.env.CLIENT_URL}/admin/order/${
            order._id
          }" style="text-decoration: none;">
                    <button style="background-color: #DAA520; color: #ffffff; font-size: 16px; padding: 10px 20px; border: none; border-radius: 4px; cursor: pointer;">
                      View Order
                    </button>
                  </a>
                </div>
                <div style="text-align: center; margin: 20px 0;">
                  <a href="${process.env.CLIENT_URL}/admin/order/${
            order._id
          }" style="text-decoration: none;">
                  Or Click here
                  </a>
                </div>
                <p style="font-size: 16px; color: #555;">
                  If you need more details or support, please contact the support team immediately.
                </p>
              </div>
              <div style="margin-top: 20px; text-align: center; font-size: 12px; color: #999;">
                <p style="margin: 0;">This is an automated notification. Please do not reply.</p>
                <p style="margin: 0;">© ${new Date().getFullYear()} Malawi Store. All rights reserved.</p>
              </div>
            </div>
          `,
        });
      }

      await sendMail({
        receiver: customer?.email,
        subject: "Update on Your Order Status – Malawi Store",
        htmlMessage: `
          <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px; background-color: #f4f4f4; border-radius: 8px; box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);">
            <div style="background-color: #36454F; color: #ffffff; padding: 15px; border-radius: 8px 8px 0 0; text-align: center;">
              <h2>Your Order Status Has Been Updated</h2>
            </div>
            <div style="padding: 20px; background-color: #ffffff; border-radius: 0 0 8px 8px;">
              <p style="font-size: 16px; color: #333;">Hello <strong>${
                customer.name
              }</strong>,</p>
              <p style="font-size: 16px; color: #555;">
                We wanted to let you know that the status of your recent order <strong>#${
                  order._id
                }</strong> has been updated.
              </p>
              <p style="font-size: 16px; color: #555;">
                <strong>New Status:</strong> ${order.status}
              </p>
              <p style="font-size: 16px; color: #555;">
                You can view more details about your order by clicking the button below:
              </p>
              <div style="text-align: center; margin: 20px 0;">
                <a href="${process.env.CLIENT_URL}/user/order/${
          order._id
        }" style="text-decoration: none;">
                  <button style="background-color: #DAA520; color: #ffffff; font-size: 16px; padding: 10px 20px; border: none; border-radius: 4px; cursor: pointer;">
                    View Order Details
                  </button>
                </a>
              </div>
              <div style="text-align: center; margin: 20px 0;">
                <a href="${process.env.CLIENT_URL}/user/order/${
          order._id
        }" style="text-decoration: none;">
                 Or click here
                </a>
              </div>
              <p style="font-size: 16px; color: #555;">
                Thank you for shopping with us on <strong>Malawi Store</strong>. If you have any questions, feel free to reach out to our support team.
              </p>
            </div>
      
            <div style="margin-top: 20px; text-align: center; font-size: 12px; color: #999;">
              <p style="margin: 0;">This is an automated message. Please do not reply.</p>
              <p style="margin: 0;">© ${new Date().getFullYear()} Malawi Store. All rights reserved.</p>
            </div>
          </div>
        `,
      });

      res.status(201).json({
        success: true,
        order,
      });
    } catch (error) {
      return next(new ErrorHandler(error, 500));
    }
  })
);

//refund order
router.put(
  "/order-refund/:orderId",
  isAuthenticated,
  asyncHandler(async (req, res, next) => {
    try {
      if (!req.body.status || req.body.status.length === 0) {
        return next(
          new ErrorHandler("Status is not supposed to be empty", 400)
        );
      }

      const order = await Order.findById(req.params.orderId);

      if (!order) {
        return next(new ErrorHandler("Order not found with this Id", 400));
      }

      order.status = req.body.status;

      order.save({ validateBeforeSave: false });

      res.status(201).json({
        success: true,
        order,
        message: "Order Refund Request Successful",
      });
    } catch (error) {
      return next(new ErrorHandler(error, 500));
    }
  })
);

//refund success
router.put(
  "/order-refund-success/:orderId",
  isShopAuthenticated,
  asyncHandler(async (req, res, next) => {
    try {
      if (!req.body.status || req.body.status.length === 0) {
        return next(
          new ErrorHandler("Status is not supposed to be empty", 400)
        );
      }

      const order = await Order.findById(req.params.orderId);

      if (!order) {
        return next(new ErrorHandler("Order not found with this Id", 400));
      }

      order.status = req.body.status;

      order.save({ validateBeforeSave: false });

      res.status(201).json({
        success: true,
        order,
        message: "Order Refund Successful",
      });

      if (req.body.status === "Refund Successful") {
        order.cart.forEach(async (item) => {
          await updateProductStock(item._id, item.quantity);
        });

        const customer = order?.user;

        await sendMail({
          receiver: customer.email,
          subject: "Your Refund Has Been Successfully Processed",
          htmlMessage: `
            <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px; background-color: #f4f4f4; border-radius: 8px; box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);">
              <div style="background-color: #36454F; color: #ffffff; padding: 15px; border-radius: 8px 8px 0 0; text-align: center;">
                <h2>Refund Processed Successfully</h2>
              </div>
              <div style="padding: 20px; background-color: #ffffff; border-radius: 0 0 8px 8px;">
                <p style="font-size: 16px; color: #333;">Hello <strong>${
                  customer.name
                }</strong>,</p>
                <p style="font-size: 16px; color: #555;">
                  We wanted to let you know that your refund for order <strong>#${
                    order._id
                  }</strong> has been successfully processed.
                </p>
                <p style="font-size: 16px; color: #555;">
                  <strong>Refund Amount:</strong> MWK ${order.totalPrice}<br />
                  <strong>Refund Method:</strong> <br />
                  <strong>Processed On:</strong> ${new Date().toLocaleDateString()}
                </p>
                <p style="font-size: 16px; color: #555;">
                  Depending on your bank or payment provider, it may take a few business days for the refund to reflect in your account.
                </p>
                <p style="font-size: 16px; color: #555;">
                  If you have any questions or need further assistance, feel free to reach out to our support team.
                </p>
              </div>
              <div style="margin-top: 20px; text-align: center; font-size: 12px; color: #999;">
                <p style="margin: 0;">This is an automated message. Please do not reply.</p>
                <p style="margin: 0;">© ${new Date().getFullYear()} Malawi Store. All rights reserved.</p>
              </div>
            </div>
          `,
        });
      }
    } catch (error) {
      return next(new ErrorHandler(error, 500));
    }
  })
);

//update order status -- admin
router.put(
  "/admin/update-order-status/:orderId",
  isAdmin,
  asyncHandler(async (req, res, next) => {
    try {
      if (!req.body.status || req.body.status.length === 0) {
        return next(
          new ErrorHandler("Status is not supposed to be empty", 400)
        );
      }

      const order = await Order.findById(req.params.orderId);

      if (!order) {
        return next(new ErrorHandler("Order not found with this Id", 400));
      }

      if (req.body.status === "Transferred to delivery partner") {
        order.cart.forEach(async (myOrder) => {
          await updateProduct(myOrder._id, myOrder.quantity);
        });
      }

      order.status = req.body.status;

      if (req.body.status === "Delivered") {
        order.deliveredAt = Date.now();
        order.paymentInfo.status = "Succeeded";
      }

      order.save({ validateBeforeSave: false });

      const customer = order?.user;

      await sendMail({
        receiver: customer.email,
        subject: "Update on Your Order Status – Malawi Store",
        htmlMessage: `
          <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px; background-color: #f4f4f4; border-radius: 8px; box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);">
            <div style="background-color: #36454F; color: #ffffff; padding: 15px; border-radius: 8px 8px 0 0; text-align: center;">
              <h2>Your Order Status Has Been Updated</h2>
            </div>
            <div style="padding: 20px; background-color: #ffffff; border-radius: 0 0 8px 8px;">
              <p style="font-size: 16px; color: #333;">Hello <strong>${
                customer.name
              }</strong>,</p>
              <p style="font-size: 16px; color: #555;">
                We wanted to let you know that the status of your recent order <strong>#${
                  order._id
                }</strong> has been updated.
              </p>
              <p style="font-size: 16px; color: #555;">
                <strong>New Status:</strong> ${order.status}
              </p>
              <p style="font-size: 16px; color: #555;">
                You can view more details about your order by clicking the button below:
              </p>
              <div style="text-align: center; margin: 20px 0;">
                <a href="${process.env.CLIENT_URL}/user/order/${
          order._id
        }" style="text-decoration: none;">
                  <button style="background-color: #DAA520; color: #ffffff; font-size: 16px; padding: 10px 20px; border: none; border-radius: 4px; cursor: pointer;">
                    View Order Details
                  </button>
                </a>
              </div>

              <div style="text-align: center; margin: 20px 0;">
                <a href="${process.env.CLIENT_URL}/user/order/${
          order._id
        }" style="text-decoration: none;">
                 Or click here
                </a>
              </div>
              <p style="font-size: 16px; color: #555;">
                Thank you for shopping with us on <strong>Malawi Store</strong>. If you have any questions, feel free to reach out to our support team.
              </p>
            </div>
      
            <div style="margin-top: 20px; text-align: center; font-size: 12px; color: #999;">
              <p style="margin: 0;">This is an automated message. Please do not reply.</p>
              <p style="margin: 0;">© ${new Date().getFullYear()} Malawi Store. All rights reserved.</p>
            </div>
          </div>
        `,
      });

      const shop = order?.cart[0]?.shop;

      await sendMail({
        receiver: shop.email,
        subject: "Update on Order Status – Malawi Store",
        htmlMessage: `
          <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px; background-color: #f4f4f4; border-radius: 8px; box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);">
            <div style="background-color: #36454F; color: #ffffff; padding: 15px; border-radius: 8px 8px 0 0; text-align: center;">
              <h2>Your Order Status Has Been Updated</h2>
            </div>
            <div style="padding: 20px; background-color: #ffffff; border-radius: 0 0 8px 8px;">
              <p style="font-size: 16px; color: #333;">Hello <strong>${
                shop.name
              }</strong>,</p>
              <p style="font-size: 16px; color: #555;">
                We wanted to let you know that the status of your recent order <strong>#${
                  order._id
                }</strong> has been updated by administrators of the platform .
              </p>
              <p style="font-size: 16px; color: #555;">
                <strong>New Status:</strong> ${order.status}
              </p>
              <p style="font-size: 16px; color: #555;">
                You can view more details about your order by clicking the button below:
              </p>
              <div style="text-align: center; margin: 20px 0;">
                <a href="${process.env.CLIENT_URL}/order/${
          order._id
        }" style="text-decoration: none;">
                  <button style="background-color: #DAA520; color: #ffffff; font-size: 16px; padding: 10px 20px; border: none; border-radius: 4px; cursor: pointer;">
                    View Order Details
                  </button>
                </a>
              </div>

              <div style="text-align: center; margin: 20px 0;">
                <a href="${process.env.CLIENT_URL}/order/${
          order._id
        }" style="text-decoration: none;">
                 Or CLick here
                </a>
              </div>
              <p style="font-size: 16px; color: #555;">
                Thank you for shopping with us on <strong>Malawi Store</strong>. If you have any questions, feel free to reach out to our support team.
              </p>
            </div>
      
            <div style="margin-top: 20px; text-align: center; font-size: 12px; color: #999;">
              <p style="margin: 0;">This is an automated message. Please do not reply.</p>
              <p style="margin: 0;">© ${new Date().getFullYear()} Malawi Store. All rights reserved.</p>
            </div>
          </div>
        `,
      });

      res.status(201).json({
        success: true,
        order,
      });
    } catch (error) {
      return next(new ErrorHandler(error, 500));
    }
  })
);

//refund success --- admin
router.put(
  "/admin/order-refund-success/:orderId",
  isAdmin,
  asyncHandler(async (req, res, next) => {
    try {
      if (!req.body.status || req.body.status.length === 0) {
        return next(
          new ErrorHandler("Status is not supposed to be empty", 400)
        );
      }

      const order = await Order.findById(req.params.orderId);

      if (!order) {
        return next(new ErrorHandler("Order not found with this Id", 400));
      }

      order.status = req.body.status;

      order.save({ validateBeforeSave: false });

      res.status(201).json({
        success: true,
        order,
        message: "Order Refund Successful",
      });

      if (req.body.status === "Refund Successful") {
        order.cart.forEach(async (item) => {
          await updateProductStock(item._id, item.quantity);
        });

        const customer = order?.user;

        await sendMail({
          receiver: customer.email,
          subject: "Your Refund Has Been Successfully Processed",
          htmlMessage: `
            <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px; background-color: #f4f4f4; border-radius: 8px; box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);">
              <div style="background-color: #36454F; color: #ffffff; padding: 15px; border-radius: 8px 8px 0 0; text-align: center;">
                <h2>Refund Processed Successfully</h2>
              </div>
              <div style="padding: 20px; background-color: #ffffff; border-radius: 0 0 8px 8px;">
                <p style="font-size: 16px; color: #333;">Hello <strong>${
                  customer.name
                }</strong>,</p>
                <p style="font-size: 16px; color: #555;">
                  We wanted to let you know that your refund for order <strong>#${
                    order._id
                  }</strong> has been successfully processed.
                </p>
                <p style="font-size: 16px; color: #555;">
                  <strong>Refund Amount:</strong> MWK ${order.totalPrice}<br />
                  <strong>Refund Method:</strong> <br />
                  <strong>Processed On:</strong> ${new Date().toLocaleDateString()}
                </p>
                <p style="font-size: 16px; color: #555;">
                  Depending on your bank or payment provider, it may take a few business days for the refund to reflect in your account.
                </p>
                <p style="font-size: 16px; color: #555;">
                  If you have any questions or need further assistance, feel free to reach out to our support team.
                </p>
              </div>
              <div style="margin-top: 20px; text-align: center; font-size: 12px; color: #999;">
                <p style="margin: 0;">This is an automated message. Please do not reply.</p>
                <p style="margin: 0;">© ${new Date().getFullYear()} Malawi Store. All rights reserved.</p>
              </div>
            </div>
          `,
        });

        const shop = order?.cart[0]?.shop;

        await sendMail({
          receiver: shop?.email,
          subject: "Refund Has Been Successfully Processed",
          htmlMessage: `
            <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px; background-color: #f4f4f4; border-radius: 8px; box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);">
              <div style="background-color: #36454F; color: #ffffff; padding: 15px; border-radius: 8px 8px 0 0; text-align: center;">
                <h2>Refund Processed Successfully</h2>
              </div>
              <div style="padding: 20px; background-color: #ffffff; border-radius: 0 0 8px 8px;">
                <p style="font-size: 16px; color: #333;">Hello <strong>${
                  shop.name
                }</strong>,</p>
                <p style="font-size: 16px; color: #555;">
                  We wanted to let you know that your refund for order <strong>#${
                    order._id
                  }</strong> has been successfully processed.
                </p>
                <p style="font-size: 16px; color: #555;">
                  <strong>Refund Amount:</strong> MWK ${order.totalPrice}<br />
                  <strong>Refund Method:</strong> <br />
                  <strong>Processed On:</strong> ${new Date().toLocaleDateString()}
                </p>
                <p style="font-size: 16px; color: #555;">
                  Depending on bank or payment provider, it may take a few business days for the refund to reflect in customers account.
                </p>
                <p style="font-size: 16px; color: #555;">
                  If you have any questions or need further assistance, feel free to reach out to our support team.
                </p>
              </div>
              <div style="margin-top: 20px; text-align: center; font-size: 12px; color: #999;">
                <p style="margin: 0;">This is an automated message. Please do not reply.</p>
                <p style="margin: 0;">© ${new Date().getFullYear()} Malawi Store. All rights reserved.</p>
              </div>
            </div>
          `,
        });
      }
    } catch (error) {
      return next(new ErrorHandler(error, 500));
    }
  })
);

//delete order ---admin
router.delete(
  "/delete-order/:orderId",
  isAdmin,
  asyncHandler(async (req, res, next) => {
    try {
      const orderExist = await Order.findById(req.params.orderId);

      if (!orderExist) {
        return next(new ErrorHandler("Order not found with this Id", 400));
      }
      const order = await Order.findByIdAndDelete(req.params.orderId);

      res.status(201).json({
        success: true,
        order,
      });
    } catch (error) {
      return next(new ErrorHandler(error, 500));
    }
  })
);

const updateProduct = async (orderId, quantity) => {
  const product = await Product.findById(orderId);

  product.stock -= quantity;
  product.soldOut += quantity;

  await product.save({ validateBeforeSave: false });
};

const updateProductStock = async (productId, quantity) => {
  const product = await Product.findById(productId);

  if (!product) {
    const event = await Event.findById(productId);

    event.stock += quantity;
    event.soldOut -= quantity;

    await event.save({ validateBeforeSave: false });
  } else {
    product.stock += quantity;
    product.soldOut -= quantity;

    await product.save({ validateBeforeSave: false });
  }
};

module.exports = router;
