const path = require("path");
const multer = require("multer");

const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, "uploads/");
  },
  filename: (req, file, cb) => {
    const uniqueSuffix = Date.now() + "-" + Math.round(Math.random() * 1e9);
    const ext = path.extname(file.originalname); // get .pdf, .png, etc.
    const name = path.basename(file.originalname, ext); // get name without extension
    cb(null, name + "-" + uniqueSuffix + ext);
  },
});

exports.upload = multer({ storage: storage });
