const express = require("express");
const ErrorHandler = require("./middleware/error");
const cookieParser = require("cookie-parser");
const borderParser = require("body-parser");
const userRouter = require("./controllers/user");
const shopRouter = require("./controllers/shop");
const productRouter = require("./controllers/product");
const eventRouter = require("./controllers/event");
const couponRouter = require("./controllers/coupon");
const paymentRouter = require("./controllers/payment");
const conversationRouter = require("./controllers/conversation");
const messageRouter = require("./controllers/message");
const orderRouter = require("./controllers/order");
const systemRouter = require("./controllers/system");
const cors = require("cors");

const app = express();

app.use(express.json());
app.use(cookieParser());
app.use(borderParser.urlencoded({ extended: true, limit: "50mb" }));
app.use("/", express.static("uploads/"));
const allowedOrigins = [
  "http://localhost:3000",
  "https://eshop-client-six.vercel.app",
  "https://your-other-frontend.com",
  "https://www.in.malawistore.com",
  "https://in.malawistore.com",
];

app.use(
  cors({
    origin: function (origin, callback) {
      // Allow requests with no origin (like mobile apps or curl)
      if (!origin) return callback(null, true);
      if (allowedOrigins.includes(origin)) {
        return callback(null, true);
      } else {
        console.warn(`CORS error: Origin ${origin} not allowed.`);
        return callback(null, false); // This way, it doesn't throw an error but blocks the request
      }
    },
    credentials: true,
  })
);

require("dotenv").config({
  path: "config/.env",
});

// if (process.env.NODE_ENV !== "PRODUCTION") {
//   require("dotenv").config({
//     path: "config/.env",
//   });
// }

app.use("/api/user", userRouter);
app.use("/api/shop", shopRouter);
app.use("/api/product", productRouter);
app.use("/api/event", eventRouter);
app.use("/api/coupon", couponRouter);
app.use("/api/payment", paymentRouter);
app.use("/api/order", orderRouter);
app.use("/api/conversation", conversationRouter);
app.use("/api/message", messageRouter);
app.use("/api/system", systemRouter);

app.use(ErrorHandler);

module.exports = app;
